/*    */ package net.kyori.adventure.platform.fabric;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import net.kyori.adventure.audience.Audience;
/*    */ import net.kyori.adventure.audience.ForwardingAudience;
/*    */ import net.kyori.adventure.identity.Identified;
/*    */ import net.kyori.adventure.identity.Identity;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface AdventureCommandSourceStack
/*    */   extends ForwardingAudience.Single, Identified
/*    */ {
/*    */   @NotNull
/*    */   default Identity identity() {
/* 42 */     throw new UnsupportedOperationException("Must be overridden");
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   default Audience audience() {
/* 47 */     throw new UnsupportedOperationException("Must be overridden");
/*    */   }
/*    */   
/*    */   default void sendSuccess(@NotNull Component text, boolean sendToOps) {}
/*    */   
/*    */   default void sendLazySuccess(@NotNull Supplier<Component> text, boolean sendToOps) {}
/*    */   
/*    */   default void sendFailure(@NotNull Component text) {}
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\AdventureCommandSourceStack.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */