/*    */ package net.kyori.adventure.platform.fabric;
/*    */ 
/*    */ import net.fabricmc.fabric.api.event.Event;
/*    */ import net.fabricmc.fabric.api.event.EventFactory;
/*    */ import net.kyori.adventure.pointer.Pointered;
/*    */ import net.kyori.adventure.pointer.Pointers;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface CollectPointersCallback
/*    */ {
/* 43 */   public static final Event<CollectPointersCallback> EVENT = EventFactory.createArrayBacked(CollectPointersCallback.class, (pointered, consumer) -> {
/*    */       
/*    */       }listeners -> ());
/*    */   
/*    */   void registerPointers(@NotNull Pointered paramPointered, Pointers.Builder paramBuilder);
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\CollectPointersCallback.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */