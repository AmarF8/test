/*     */ package net.kyori.adventure.platform.fabric;
/*     */ 
/*     */ import com.google.gson.stream.JsonReader;
/*     */ import java.io.StringReader;
/*     */ import java.util.List;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.platform.fabric.impl.accessor.minecraft.commands.ParserUtilsAccess;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.minimessage.MiniMessage;
/*     */ import net.kyori.adventure.text.serializer.gson.GsonComponentSerializer;
/*     */ import net.kyori.adventure.util.Index;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Format
/*     */ {
/* 163 */   JSON(
/* 164 */     Key.key("adventure", "json"), new String[] { "\"Hello world!\"", "[\"Message\", {\"text\": \"example\", \"color\": \"#aabbcc\"}]" })
/*     */   {
/*     */ 
/*     */ 
/*     */     
/*     */     ComponentArgumentType.ReadResult parse(String allInput) throws Exception
/*     */     {
/* 171 */       JsonReader json = new JsonReader(new StringReader(allInput)); 
/* 172 */       try { Component ret = (Component)GsonComponentSerializer.gson().serializer().fromJson(json, Component.class);
/* 173 */         ComponentArgumentType.ReadResult readResult = new ComponentArgumentType.ReadResult(ret, ParserUtilsAccess.getPos(json));
/* 174 */         json.close(); return readResult; } catch (Throwable throwable) { try { json.close(); }
/*     */         catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */          throw throwable; }
/* 177 */        } }, MINIMESSAGE(
/* 178 */     Key.key("adventure", "minimessage/v1"), new String[] { "<rainbow>hello world!", "hello <bold>everyone</bold> here!", "hello <hover:show_text:'sneak sneak'>everyone</hover> who likes <blue>cats" })
/*     */   {
/*     */ 
/*     */ 
/*     */     
/*     */     ComponentArgumentType.ReadResult parse(String allInput) throws Exception
/*     */     {
/* 185 */       Component parsed = MiniMessage.miniMessage().deserialize(allInput);
/* 186 */       return new ComponentArgumentType.ReadResult(parsed, allInput.length());
/*     */     } };
/*     */   public static final Index<Key, Format> INDEX; private final Key id; private final List<String> examples;
/*     */   static {
/* 190 */     INDEX = Index.create(Format.class, Format::id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Format(Key id, String... examples) {
/* 196 */     this.id = id;
/* 197 */     this.examples = List.of(examples);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Key id() {
/* 209 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> examples() {
/* 219 */     return this.examples;
/*     */   }
/*     */   
/*     */   abstract ComponentArgumentType.ReadResult parse(String paramString) throws Exception;
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\ComponentArgumentType$Format.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */