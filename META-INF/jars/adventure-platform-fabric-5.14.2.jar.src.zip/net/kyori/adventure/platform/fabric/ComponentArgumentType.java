/*     */ package net.kyori.adventure.platform.fabric;
/*     */ 
/*     */ import com.google.gson.stream.JsonReader;
/*     */ import com.mojang.brigadier.StringReader;
/*     */ import com.mojang.brigadier.arguments.ArgumentType;
/*     */ import com.mojang.brigadier.context.CommandContext;
/*     */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*     */ import java.io.StringReader;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.platform.fabric.impl.accessor.minecraft.commands.ParserUtilsAccess;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.minimessage.MiniMessage;
/*     */ import net.kyori.adventure.text.serializer.gson.GsonComponentSerializer;
/*     */ import net.kyori.adventure.util.Index;
/*     */ import net.minecraft.class_2178;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ComponentArgumentType
/*     */   implements ArgumentType<Component>
/*     */ {
/*  54 */   private static final ComponentArgumentType JSON_INSTANCE = new ComponentArgumentType(Format.JSON);
/*  55 */   private static final ComponentArgumentType MINIMESSAGE_INSTANCE = new ComponentArgumentType(Format.MINIMESSAGE);
/*     */ 
/*     */ 
/*     */   
/*     */   private final Format format;
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "5.1.0")
/*     */   @NotNull
/*     */   public static ComponentArgumentType component() {
/*  66 */     return JSON_INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static Component component(@NotNull CommandContext<?> ctx, @NotNull String key) {
/*  78 */     return (Component)ctx.getArgument(key, Component.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static ComponentArgumentType json() {
/*  88 */     return JSON_INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static ComponentArgumentType miniMessage() {
/*  98 */     return MINIMESSAGE_INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static ComponentArgumentType component(@NotNull Format format) {
/* 109 */     switch (format.ordinal()) { default: throw new MatchException(null, null);case 0: case 1: break; }  return 
/*     */       
/* 111 */       MINIMESSAGE_INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ComponentArgumentType(Format format) {
/* 118 */     this.format = Objects.<Format>requireNonNull(format, "format");
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Component parse(@NotNull StringReader reader) throws CommandSyntaxException {
/* 123 */     String remaining = reader.getRemaining();
/*     */     try {
/* 125 */       ReadResult result = this.format.parse(remaining);
/* 126 */       reader.setCursor(reader.getCursor() + result.charsConsumed());
/* 127 */       return result.parsed();
/* 128 */     } catch (Exception ex) {
/* 129 */       String message = (ex.getCause() == null) ? ex.getMessage() : ex.getCause().getMessage();
/* 130 */       throw class_2178.field_9842.createWithContext(reader, message);
/*     */     } 
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Collection<String> getExamples() {
/* 136 */     return this.format.examples();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public Format format() {
/* 146 */     return this.format;
/*     */   } static final class ReadResult extends Record {
/*     */     private final Component parsed; private final int charsConsumed;
/*     */     public final String toString() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lnet/kyori/adventure/platform/fabric/ComponentArgumentType$ReadResult;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #155	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/ComponentArgumentType$ReadResult;
/*     */     }
/*     */     public final int hashCode() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lnet/kyori/adventure/platform/fabric/ComponentArgumentType$ReadResult;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #155	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/ComponentArgumentType$ReadResult;
/*     */     }
/* 155 */     ReadResult(Component parsed, int charsConsumed) { this.parsed = parsed; this.charsConsumed = charsConsumed; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lnet/kyori/adventure/platform/fabric/ComponentArgumentType$ReadResult;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #155	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/ComponentArgumentType$ReadResult;
/* 155 */       //   0	8	1	o	Ljava/lang/Object; } public Component parsed() { return this.parsed; } public int charsConsumed() { return this.charsConsumed; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Format
/*     */   {
/* 163 */     JSON(
/* 164 */       (String)Key.key("adventure", "json"), new String[] { "\"Hello world!\"", "[\"Message\", {\"text\": \"example\", \"color\": \"#aabbcc\"}]" })
/*     */     {
/*     */ 
/*     */ 
/*     */       
/*     */       ComponentArgumentType.ReadResult parse(String allInput) throws Exception
/*     */       {
/* 171 */         JsonReader json = new JsonReader(new StringReader(allInput)); 
/* 172 */         try { Component ret = (Component)GsonComponentSerializer.gson().serializer().fromJson(json, Component.class);
/* 173 */           ComponentArgumentType.ReadResult readResult = new ComponentArgumentType.ReadResult(ret, ParserUtilsAccess.getPos(json));
/* 174 */           json.close(); return readResult; } catch (Throwable throwable) { try { json.close(); }
/*     */           catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */            throw throwable; }
/* 177 */          } }, MINIMESSAGE(
/* 178 */       (String)Key.key("adventure", "minimessage/v1"), new String[] { "<rainbow>hello world!", "hello <bold>everyone</bold> here!", "hello <hover:show_text:'sneak sneak'>everyone</hover> who likes <blue>cats" })
/*     */     {
/*     */ 
/*     */ 
/*     */       
/*     */       ComponentArgumentType.ReadResult parse(String allInput) throws Exception
/*     */       {
/* 185 */         Component parsed = MiniMessage.miniMessage().deserialize(allInput);
/* 186 */         return new ComponentArgumentType.ReadResult(parsed, allInput.length());
/*     */       }
/*     */     };
/*     */     
/* 190 */     public static final Index<Key, Format> INDEX = Index.create(Format.class, Format::id); private final Key id; private final List<String> examples;
/*     */     static {
/*     */     
/*     */     }
/*     */     
/*     */     Format(Key id, String... examples) {
/* 196 */       this.id = id;
/* 197 */       this.examples = List.of(examples);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Key id() {
/* 209 */       return this.id;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<String> examples() {
/* 219 */       return this.examples;
/*     */     }
/*     */     
/*     */     abstract ComponentArgumentType.ReadResult parse(String param1String) throws Exception;
/*     */   }
/*     */   
/*     */   enum null {
/*     */     ComponentArgumentType.ReadResult parse(String allInput) throws Exception {
/*     */       JsonReader json = new JsonReader(new StringReader(allInput));
/*     */       try {
/*     */         Component ret = (Component)GsonComponentSerializer.gson().serializer().fromJson(json, Component.class);
/*     */         ComponentArgumentType.ReadResult readResult = new ComponentArgumentType.ReadResult(ret, ParserUtilsAccess.getPos(json));
/*     */         json.close();
/*     */         return readResult;
/*     */       } catch (Throwable throwable) {
/*     */         try {
/*     */           json.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         } 
/*     */         throw throwable;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     ComponentArgumentType.ReadResult parse(String allInput) throws Exception {
/*     */       Component parsed = MiniMessage.miniMessage().deserialize(allInput);
/*     */       return new ComponentArgumentType.ReadResult(parsed, allInput.length());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\ComponentArgumentType.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */