/*    */ package net.kyori.adventure.platform.fabric;
/*    */ 
/*    */ import java.util.function.UnaryOperator;
/*    */ import net.kyori.adventure.text.event.HoverEvent;
/*    */ import net.kyori.adventure.text.event.HoverEventSource;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface EntityHoverEventSource
/*    */   extends HoverEventSource<HoverEvent.ShowEntity>
/*    */ {
/*    */   @NotNull
/*    */   default HoverEvent<HoverEvent.ShowEntity> asHoverEvent(@NotNull UnaryOperator<HoverEvent.ShowEntity> op) {
/* 41 */     throw new UnsupportedOperationException("Method must be overridden by Mixin");
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\EntityHoverEventSource.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */