/*     */ package net.kyori.adventure.platform.fabric;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.UnaryOperator;
/*     */ import net.kyori.adventure.identity.Identified;
/*     */ import net.kyori.adventure.identity.Identity;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.platform.fabric.impl.AdventureCommon;
/*     */ import net.kyori.adventure.platform.fabric.impl.NonWrappingComponentSerializer;
/*     */ import net.kyori.adventure.platform.fabric.impl.WrappedComponent;
/*     */ import net.kyori.adventure.platform.fabric.impl.nbt.FabricDataComponentValue;
/*     */ import net.kyori.adventure.pointer.Pointered;
/*     */ import net.kyori.adventure.sound.Sound;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.event.DataComponentValue;
/*     */ import net.kyori.adventure.text.flattener.ComponentFlattener;
/*     */ import net.kyori.adventure.text.renderer.ComponentRenderer;
/*     */ import net.kyori.adventure.text.serializer.ComponentSerializer;
/*     */ import net.kyori.adventure.util.ComponentMessageThrowable;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_9331;
/*     */ import org.jetbrains.annotations.Contract;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface FabricAudiences
/*     */ {
/*     */   static class_2561 update(class_2561 input, UnaryOperator<Component> modifier) {
/*     */     Component modified;
/*     */     Function<Pointered, ?> partition;
/*     */     ComponentRenderer<Pointered> renderer;
/*  78 */     if (input instanceof WrappedComponent) {
/*  79 */       modified = ((UnaryOperator<Component>)Objects.<UnaryOperator<Component>>requireNonNull(modifier)).apply(((WrappedComponent)input).wrapped());
/*  80 */       partition = ((WrappedComponent)input).partition();
/*  81 */       renderer = ((WrappedComponent)input).renderer();
/*     */     } else {
/*  83 */       Component original = NonWrappingComponentSerializer.INSTANCE.deserialize(input);
/*  84 */       modified = modifier.apply(original);
/*  85 */       partition = null;
/*  86 */       renderer = null;
/*     */     } 
/*  88 */     return (class_2561)AdventureCommon.SIDE_PROXY.createWrappedComponent(modified, partition, renderer, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "5.3.0")
/*     */   @Contract("null -> null; !null -> !null")
/*     */   static Key toAdventure(class_2960 loc) {
/* 102 */     if (loc == null) {
/* 103 */       return null;
/*     */     }
/* 105 */     return (Key)loc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract("null -> null; !null -> !null")
/*     */   static class_2960 toNative(Key key) {
/* 121 */     if (key == null) {
/* 122 */       return null;
/*     */     }
/*     */     
/* 125 */     return (class_2960)key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "5.3.0")
/*     */   static Sound.Emitter asEmitter(@NotNull class_1297 entity) {
/* 138 */     return (Sound.Emitter)entity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   static ComponentMessageThrowable asComponentThrowable(@NotNull CommandSyntaxException ex) {
/* 149 */     return (ComponentMessageThrowable)ex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   static ComponentSerializer<Component, Component, class_2561> nonWrappingSerializer() {
/* 163 */     return (ComponentSerializer<Component, Component, class_2561>)NonWrappingComponentSerializer.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "5.3.0")
/*     */   @NotNull
/*     */   static Identified identified(@NotNull class_1657 player) {
/* 176 */     return (Identified)player;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   static Identity identity(@NotNull GameProfile profile) {
/* 187 */     return (Identity)profile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   static <T> DataComponentValue dataComponentValue(@NotNull class_9331<T> type, @NotNull T value) {
/* 202 */     return (DataComponentValue)new FabricDataComponentValue.Present(value, type.method_57876());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   ComponentFlattener flattener();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   ComponentRenderer<Pointered> renderer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class_2561 toNative(@NotNull Component paramComponent);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   default Component toAdventure(class_2561 vanilla) {
/* 242 */     return vanilla.asComponent();
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\FabricAudiences.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */