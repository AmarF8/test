/*     */ package net.kyori.adventure.platform.fabric;
/*     */ 
/*     */ import java.util.function.Function;
/*     */ import net.fabricmc.api.EnvType;
/*     */ import net.fabricmc.api.Environment;
/*     */ import net.kyori.adventure.audience.Audience;
/*     */ import net.kyori.adventure.platform.fabric.impl.client.FabricClientAudiencesImpl;
/*     */ import net.kyori.adventure.pointer.Pointered;
/*     */ import net.kyori.adventure.text.renderer.ComponentRenderer;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Environment(EnvType.CLIENT)
/*     */ public interface FabricClientAudiences
/*     */   extends FabricAudiences
/*     */ {
/*     */   @NotNull
/*     */   static FabricClientAudiences of() {
/*  47 */     return FabricClientAudiencesImpl.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Builder builder() {
/*  57 */     return (Builder)new FabricClientAudiencesImpl.Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   Audience audience();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Environment(EnvType.CLIENT)
/*     */   public static interface Builder
/*     */   {
/*     */     @NotNull
/*     */     Builder componentRenderer(@NotNull ComponentRenderer<Pointered> param1ComponentRenderer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @NotNull
/*     */     Builder partition(@NotNull Function<Pointered, ?> param1Function);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @NotNull
/*     */     default <T> Builder componentRenderer(@NotNull Function<Pointered, T> partition, @NotNull ComponentRenderer<T> componentRenderer) {
/* 122 */       return partition(partition)
/* 123 */         .componentRenderer(componentRenderer.mapContext(partition));
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     FabricClientAudiences build();
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\FabricClientAudiences.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */