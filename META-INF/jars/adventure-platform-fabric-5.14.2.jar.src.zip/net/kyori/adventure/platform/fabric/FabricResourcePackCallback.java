/*    */ package net.kyori.adventure.platform.fabric;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.UUID;
/*    */ import net.kyori.adventure.audience.Audience;
/*    */ import net.kyori.adventure.identity.Identity;
/*    */ import net.kyori.adventure.platform.fabric.impl.ControlledAudience;
/*    */ import net.kyori.adventure.platform.fabric.impl.FabricAudiencesInternal;
/*    */ import net.kyori.adventure.platform.fabric.impl.server.FabricServerAudiencesImpl;
/*    */ import net.kyori.adventure.resource.ResourcePackCallback;
/*    */ import net.kyori.adventure.resource.ResourcePackStatus;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.kyori.adventure.text.logger.slf4j.ComponentLogger;
/*    */ import net.minecraft.class_3222;
/*    */ import net.minecraft.class_3244;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FabricResourcePackCallback
/*    */ {
/* 47 */   private static final ComponentLogger LOGGER = ComponentLogger.logger();
/* 48 */   private static final Component DEFAULT_KICK_MESSAGE = (Component)Component.translatable("multiplayer.requiredTexturePrompt.disconnect");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public static ResourcePackCallback kickIfNotApplied() {
/* 60 */     return kickIfNotApplied(DEFAULT_KICK_MESSAGE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public static ResourcePackCallback kickIfNotApplied(@NotNull Component kickMessage) {
/* 71 */     Objects.requireNonNull(kickMessage, "kickMessage");
/*    */     
/* 73 */     return (uuid, status, audience) -> {
/*    */         if (!status.intermediate() && status != ResourcePackStatus.SUCCESSFULLY_LOADED) {
/*    */           ControlledAudience controlled;
/*    */           class_3244 class_3244;
/*    */           if (audience instanceof ControlledAudience) {
/*    */             controlled = (ControlledAudience)audience;
/*    */           } else {
/*    */             LOGGER.debug("Audience {} was not a ControlledAudience, we cannot kick them", audience);
/*    */             return;
/*    */           } 
/*    */           if (audience instanceof class_3222) {
/*    */             class_3222 player = (class_3222)audience;
/*    */             class_3244 = player.field_13987;
/*    */           } else {
/*    */             FabricServerAudiencesImpl server;
/*    */             UUID id = audience.get(Identity.UUID).orElse(null);
/*    */             if (id == null)
/*    */               return; 
/*    */             FabricAudiencesInternal patt0$temp = controlled.controller();
/*    */             if (patt0$temp instanceof FabricServerAudiencesImpl) {
/*    */               server = (FabricServerAudiencesImpl)patt0$temp;
/*    */             } else {
/*    */               return;
/*    */             } 
/*    */             class_3222 ply = server.server().method_3760().method_14602(id);
/*    */             if (ply == null)
/*    */               return; 
/*    */             class_3244 = ply.field_13987;
/*    */           } 
/*    */           LOGGER.debug("Audience {} did not successfully apply a resource pack with ID {}, kicking with message: {}", new Object[] { class_3244.method_52404(), uuid, kickMessage });
/*    */           class_3244.method_52396(controlled.controller().toNative(kickMessage));
/*    */         } 
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\FabricResourcePackCallback.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */