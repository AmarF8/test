/*    */ package net.kyori.adventure.platform.fabric;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import net.kyori.adventure.audience.Audience;
/*    */ import net.kyori.adventure.platform.AudienceProvider;
/*    */ import net.kyori.adventure.platform.fabric.impl.server.FabricServerAudiencesImpl;
/*    */ import net.kyori.adventure.platform.fabric.impl.server.MinecraftServerBridge;
/*    */ import net.minecraft.class_2165;
/*    */ import net.minecraft.class_2168;
/*    */ import net.minecraft.class_3222;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface FabricServerAudiences
/*    */   extends AudienceProvider, FabricAudiences
/*    */ {
/*    */   @NotNull
/*    */   static FabricServerAudiences of(@NotNull MinecraftServer server) {
/* 54 */     return ((MinecraftServerBridge)server).adventure$globalProvider();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static Builder builder(@NotNull MinecraftServer server) {
/* 65 */     return (Builder)new FabricServerAudiencesImpl.Builder(Objects.<MinecraftServer>requireNonNull(server, "server"));
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   AdventureCommandSourceStack audience(@NotNull class_2168 paramclass_2168);
/*    */   
/*    */   @NotNull
/*    */   Audience audience(@NotNull class_2165 paramclass_2165);
/*    */   
/*    */   @NotNull
/*    */   Audience audience(@NotNull Iterable<class_3222> paramIterable);
/*    */   
/*    */   public static interface Builder extends AudienceProvider.Builder<FabricServerAudiences, Builder> {}
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\FabricServerAudiences.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */