/*    */ package net.kyori.adventure.platform.fabric;
/*    */ 
/*    */ import net.kyori.adventure.identity.Identified;
/*    */ import net.kyori.adventure.identity.Identity;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IdentifiedAtRuntime
/*    */   extends Identified
/*    */ {
/*    */   @NotNull
/*    */   default Identity identity() {
/* 41 */     throw new UnsupportedOperationException("Must be overridden");
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\IdentifiedAtRuntime.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */