package net.kyori.adventure.platform.fabric;

import java.util.Locale;
import net.minecraft.class_3222;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface Changed {
  void onLocaleChanged(@NotNull class_3222 paramclass_3222, @Nullable Locale paramLocale);
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\PlayerLocales$Changed.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */