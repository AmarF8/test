/*    */ package net.kyori.adventure.platform.fabric;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import net.fabricmc.fabric.api.event.Event;
/*    */ import net.fabricmc.fabric.api.event.EventFactory;
/*    */ import net.kyori.adventure.platform.fabric.impl.LocaleHolderBridge;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_3222;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface PlayerLocales
/*    */ {
/*    */   @NotNull
/* 46 */   public static final Event<Changed> CHANGED_EVENT = EventFactory.createArrayBacked(Changed.class, listeners -> ());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(forRemoval = true, since = "5.3.0")
/*    */   @NotNull
/*    */   static Locale locale(@NotNull class_1657 player) {
/* 83 */     return (player instanceof LocaleHolderBridge) ? ((LocaleHolderBridge)player).adventure$locale() : Locale.getDefault();
/*    */   }
/*    */   
/*    */   public static interface Changed {
/*    */     void onLocaleChanged(@NotNull class_3222 param1class_3222, @Nullable Locale param1Locale);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\PlayerLocales.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */