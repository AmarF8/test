/*    */ package net.kyori.adventure.platform.fabric.impl;
/*    */ 
/*    */ import java.util.IdentityHashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import net.kyori.adventure.bossbar.BossBar;
/*    */ import net.kyori.adventure.platform.fabric.FabricAudiences;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.minecraft.class_1259;
/*    */ import net.minecraft.class_2561;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractBossBarListener<T extends class_1259>
/*    */   implements BossBar.Listener
/*    */ {
/*    */   private final FabricAudiences controller;
/* 38 */   protected final Map<BossBar, T> bars = new IdentityHashMap<>();
/*    */   
/*    */   protected AbstractBossBarListener(FabricAudiences controller) {
/* 41 */     this.controller = controller;
/*    */   }
/*    */ 
/*    */   
/*    */   public void bossBarNameChanged(@NotNull BossBar bar, @NotNull Component oldName, @NotNull Component newName) {
/* 46 */     if (!oldName.equals(newName)) {
/* 47 */       minecraft(bar).method_5413(this.controller.toNative(newName));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void bossBarProgressChanged(@NotNull BossBar bar, float oldPercent, float newPercent) {
/* 53 */     if (oldPercent != newPercent) {
/* 54 */       minecraft(bar).method_5408(newPercent);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void bossBarColorChanged(@NotNull BossBar bar, BossBar.Color oldColor, BossBar.Color newColor) {
/* 60 */     if (oldColor != newColor) {
/* 61 */       minecraft(bar).method_5416(GameEnums.BOSS_BAR_COLOR.toMinecraft(newColor));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void bossBarOverlayChanged(@NotNull BossBar bar, BossBar.Overlay oldOverlay, BossBar.Overlay newOverlay) {
/* 67 */     if (oldOverlay != newOverlay) {
/* 68 */       minecraft(bar).method_5409(GameEnums.BOSS_BAR_OVERLAY.toMinecraft(newOverlay));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void bossBarFlagsChanged(@NotNull BossBar bar, @NotNull Set<BossBar.Flag> flagsRemoved, @NotNull Set<BossBar.Flag> flagsAdded) {
/* 74 */     updateFlags((class_1259)minecraft(bar), bar.flags());
/*    */   }
/*    */   
/*    */   private static void updateFlags(@NotNull class_1259 bar, @NotNull Set<BossBar.Flag> flags) {
/* 78 */     bar.method_5411(flags.contains(BossBar.Flag.CREATE_WORLD_FOG));
/* 79 */     bar.method_5406(flags.contains(BossBar.Flag.DARKEN_SCREEN));
/* 80 */     bar.method_5410(flags.contains(BossBar.Flag.PLAY_BOSS_MUSIC));
/*    */   }
/*    */   
/*    */   private T minecraft(@NotNull BossBar bar) {
/* 84 */     class_1259 class_1259 = (class_1259)this.bars.get(bar);
/* 85 */     if (class_1259 == null) {
/* 86 */       throw new IllegalArgumentException("Unknown boss bar instance " + String.valueOf(bar));
/*    */     }
/* 88 */     return (T)class_1259;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract T newBar(class_2561 paramclass_2561, class_1259.class_1260 paramclass_1260, class_1259.class_1261 paramclass_1261, float paramFloat);
/*    */ 
/*    */   
/*    */   protected T minecraftCreating(@NotNull BossBar bar) {
/* 97 */     return this.bars.computeIfAbsent(bar, key -> {
/*    */           T ret = newBar(this.controller.toNative(key.name()), GameEnums.BOSS_BAR_COLOR.toMinecraft(key.color()), GameEnums.BOSS_BAR_OVERLAY.toMinecraft(key.overlay()), key.progress());
/*    */           updateFlags((class_1259)ret, key.flags());
/*    */           key.addListener(this);
/*    */           return (class_1259)ret;
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\AbstractBossBarListener.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */