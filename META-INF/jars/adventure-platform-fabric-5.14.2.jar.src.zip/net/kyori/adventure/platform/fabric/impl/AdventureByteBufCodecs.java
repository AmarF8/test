/*    */ package net.kyori.adventure.platform.fabric.impl;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import net.minecraft.class_9135;
/*    */ import net.minecraft.class_9139;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AdventureByteBufCodecs
/*    */ {
/* 35 */   public static final class_9139<ByteBuf, Key> KEY = class_9135.field_48554
/* 36 */     .method_56432(Key::key, Key::asString);
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\AdventureByteBufCodecs.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */