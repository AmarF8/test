package net.kyori.adventure.platform.fabric.impl;

import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.platform.fabric.AdventureCommandSourceStack;
import net.kyori.adventure.platform.fabric.impl.server.FabricServerAudiencesImpl;
import net.minecraft.class_2165;

public interface AdventureCommandSourceStackInternal extends AdventureCommandSourceStack {
  AdventureCommandSourceStack adventure$audience(Audience paramAudience, FabricServerAudiencesImpl paramFabricServerAudiencesImpl);
  
  class_2165 adventure$source();
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\AdventureCommandSourceStackInternal.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */