/*     */ package net.kyori.adventure.platform.fabric.impl;
/*     */ 
/*     */ import com.google.common.util.concurrent.ThreadFactoryBuilder;
/*     */ import com.mojang.brigadier.CommandDispatcher;
/*     */ import com.mojang.brigadier.arguments.ArgumentType;
/*     */ import com.mojang.brigadier.arguments.StringArgumentType;
/*     */ import com.mojang.logging.LogUtils;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.fabricmc.api.EnvType;
/*     */ import net.fabricmc.api.ModInitializer;
/*     */ import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
/*     */ import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
/*     */ import net.fabricmc.loader.api.FabricLoader;
/*     */ import net.fabricmc.loader.api.entrypoint.EntrypointContainer;
/*     */ import net.kyori.adventure.chat.ChatType;
/*     */ import net.kyori.adventure.identity.Identity;
/*     */ import net.kyori.adventure.platform.fabric.CollectPointersCallback;
/*     */ import net.kyori.adventure.platform.fabric.ComponentArgumentType;
/*     */ import net.kyori.adventure.platform.fabric.FabricAudiences;
/*     */ import net.kyori.adventure.platform.fabric.KeyArgumentType;
/*     */ import net.kyori.adventure.platform.fabric.PlayerLocales;
/*     */ import net.kyori.adventure.platform.fabric.impl.server.FabricServerAudiencesImpl;
/*     */ import net.kyori.adventure.pointer.Pointered;
/*     */ import net.kyori.adventure.pointer.Pointers;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.TranslatableComponent;
/*     */ import net.kyori.adventure.text.TranslationArgument;
/*     */ import net.kyori.adventure.text.flattener.ComponentFlattener;
/*     */ import net.kyori.adventure.translation.GlobalTranslator;
/*     */ import net.kyori.adventure.translation.TranslationRegistry;
/*     */ import net.kyori.adventure.translation.Translator;
/*     */ import net.minecraft.class_2168;
/*     */ import net.minecraft.class_2170;
/*     */ import net.minecraft.class_2232;
/*     */ import net.minecraft.class_2314;
/*     */ import net.minecraft.class_2319;
/*     */ import net.minecraft.class_2477;
/*     */ import net.minecraft.class_2556;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_3222;
/*     */ import net.minecraft.class_6880;
/*     */ import net.minecraft.class_7157;
/*     */ import net.minecraft.class_7924;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.slf4j.Logger;
/*     */ import org.spongepowered.asm.mixin.MixinEnvironment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdventureCommon
/*     */   implements ModInitializer
/*     */ {
/*  79 */   private static final Logger LOGGER = LogUtils.getLogger();
/*     */   
/*     */   public static final ScheduledExecutorService SCHEDULER;
/*     */   
/*     */   public static final SidedProxy SIDE_PROXY;
/*     */   public static final ComponentFlattener FLATTENER;
/*  85 */   private static final Pattern LOCALIZATION_PATTERN = Pattern.compile("%(?:(\\d+)\\$)?s");
/*     */   
/*     */   public static final String MOD_FAPI_NETWORKING = "fabric-networking-api-v1";
/*     */   
/*     */   static {
/*  90 */     SCHEDULER = Executors.newSingleThreadScheduledExecutor((new ThreadFactoryBuilder())
/*  91 */         .setNameFormat("adventure-platform-fabric-scheduler-%d")
/*  92 */         .setDaemon(true)
/*  93 */         .setUncaughtExceptionHandler((thread, ex) -> LOGGER.error("An uncaught exception occurred in scheduler thread '{}':", thread.getName(), ex))
/*  94 */         .build());
/*     */     
/*  96 */     SidedProxy sidedProxy = chooseSidedProxy();
/*  97 */     SIDE_PROXY = sidedProxy;
/*  98 */     FLATTENER = createFlattener(sidedProxy);
/*     */   }
/*     */   
/*     */   private static SidedProxy chooseSidedProxy() {
/* 102 */     EnvType environment = FabricLoader.getInstance().getEnvironmentType();
/* 103 */     List<EntrypointContainer<SidedProxy>> sidedProxyContainers = FabricLoader.getInstance().getEntrypointContainers("adventure-internal:sidedproxy/" + environment
/* 104 */         .name().toLowerCase(Locale.ROOT), SidedProxy.class);
/*     */ 
/*     */ 
/*     */     
/* 108 */     switch (sidedProxyContainers.size()) { case 0:
/* 109 */         throw new IllegalStateException("No sided proxies were available for adventure-platform-fabric in environment " + String.valueOf(environment));
/*     */       case 1:
/* 111 */         proxy = sidedProxyContainers.getFirst();
/* 112 */         LOGGER.debug("Selected sided proxy {} from {}", proxy.getEntrypoint(), proxy.getProvider().getMetadata().getId()); }
/*     */ 
/*     */ 
/*     */     
/* 116 */     EntrypointContainer<SidedProxy> proxy = sidedProxyContainers.getFirst();
/* 117 */     LOGGER.warn("Multiple applicable proxies were applicable, choosing first available: {} from {}", proxy.getEntrypoint(), proxy.getProvider().getMetadata().getId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ComponentFlattener createFlattener(SidedProxy proxy) {
/* 124 */     ComponentFlattener.Builder flattenerBuilder = (ComponentFlattener.Builder)ComponentFlattener.basic().toBuilder();
/*     */     
/* 126 */     proxy.contributeFlattenerElements(flattenerBuilder);
/*     */     
/* 128 */     flattenerBuilder.complexMapper(TranslatableComponent.class, (translatable, consumer) -> {
/*     */           String key = translatable.key();
/*     */           
/*     */           for (Translator registry : GlobalTranslator.translator().sources()) {
/*     */             if (registry instanceof TranslationRegistry) {
/*     */               TranslationRegistry tr = (TranslationRegistry)registry;
/*     */               
/*     */               if (tr.contains(key)) {
/*     */                 consumer.accept(GlobalTranslator.render((Component)translatable, Locale.getDefault()));
/*     */                 
/*     */                 return;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           String translated = Objects.<String>requireNonNullElse(class_2477.method_10517().method_4679(key, translatable.fallback()), key);
/*     */           Matcher matcher = LOCALIZATION_PATTERN.matcher(translated);
/*     */           List<TranslationArgument> args = translatable.arguments();
/*     */           int argPosition = 0;
/*     */           int lastIdx = 0;
/*     */           while (matcher.find()) {
/*     */             if (lastIdx < matcher.start()) {
/*     */               consumer.accept(Component.text(translated.substring(lastIdx, matcher.start())));
/*     */             }
/*     */             lastIdx = matcher.end();
/*     */             String argIdx = matcher.group(1);
/*     */             if (argIdx != null) {
/*     */               try {
/*     */                 int i = Integer.parseInt(argIdx) - 1;
/*     */                 if (i < args.size()) {
/*     */                   consumer.accept(((TranslationArgument)args.get(i)).asComponent());
/*     */                 }
/* 159 */               } catch (NumberFormatException numberFormatException) {}
/*     */               
/*     */               continue;
/*     */             } 
/*     */             
/*     */             int idx = argPosition++;
/*     */             
/*     */             if (idx < args.size()) {
/*     */               consumer.accept(((TranslationArgument)args.get(idx)).asComponent());
/*     */             }
/*     */           } 
/*     */           
/*     */           if (lastIdx < translated.length()) {
/*     */             consumer.accept(Component.text(translated.substring(lastIdx)));
/*     */           }
/*     */         });
/*     */     
/* 176 */     return (ComponentFlattener)flattenerBuilder.build();
/*     */   }
/*     */   
/*     */   public static class_2960 res(@NotNull String value) {
/* 180 */     return class_2960.method_60655("adventure", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onInitialize() {
/* 185 */     setupCustomArgumentTypes();
/*     */     
/* 187 */     PlayerLocales.CHANGED_EVENT.register((player, locale) -> FabricServerAudiencesImpl.forEachInstance(()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     CollectPointersCallback.EVENT.register((pointered, builder) -> {
/*     */           if (pointered instanceof LocaleHolderBridge) {
/*     */             LocaleHolderBridge holder = (LocaleHolderBridge)pointered; Objects.requireNonNull(holder);
/*     */             builder.withDynamic(Identity.LOCALE, holder::adventure$locale);
/*     */           } 
/*     */         });
/* 199 */     CommandRegistrationCallback.EVENT.register((dispatcher, registries, env) -> ClickCallbackRegistry.INSTANCE.registerToDispatcher(dispatcher));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 205 */     Objects.requireNonNull(ClickCallbackRegistry.INSTANCE); SCHEDULER.scheduleWithFixedDelay(ClickCallbackRegistry.INSTANCE::cleanUp, 30L, 30L, TimeUnit.SECONDS);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 212 */     if (Boolean.getBoolean("adventure.testMode") && 
/* 213 */       FabricLoader.getInstance().getEnvironmentType() == EnvType.SERVER) {
/* 214 */       ServerLifecycleEvents.SERVER_STARTED.register(server -> {
/*     */             MixinEnvironment.getCurrentEnvironment().audit();
/*     */             server.execute(());
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setupCustomArgumentTypes() {
/* 231 */     if (FabricLoader.getInstance().isModLoaded("fabric-networking-api-v1")) {
/* 232 */       ClientboundArgumentTypeMappingsPacket.register();
/* 233 */       ServerboundRegisteredArgumentTypesPacket.register();
/*     */     } 
/*     */     
/* 236 */     ServerArgumentTypes.register(new ServerArgumentType(
/*     */           
/* 238 */           res("component"), ComponentArgumentType.class, ComponentArgumentTypeSerializer.INSTANCE, (arg, ctx) -> { switch (arg.format()) { default: throw new MatchException(null, null);case JSON: case MINIMESSAGE: break; }  return (ArgumentType)StringArgumentType.greedyString(); }null));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     ServerArgumentTypes.register(new ServerArgumentType(
/*     */           
/* 250 */           res("key"), KeyArgumentType.class, 
/*     */           
/* 252 */           (class_2314<?, ? extends class_2314.class_7217<?>>)class_2319.method_41999(KeyArgumentType::key), (arg, ctx) -> class_2232.method_9441(), null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function<Pointered, Locale> localePartition() {
/* 260 */     return ptr -> (Locale)ptr.getOrDefault(Identity.LOCALE, Locale.US);
/*     */   }
/*     */   
/*     */   public static Pointered pointered(FPointered pointers) {
/* 264 */     return pointers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class_2556.class_7602 chatTypeToNative(ChatType.Bound bound, FabricAudiencesInternal audiences) {
/* 277 */     class_6880<class_2556> type = (class_6880<class_2556>)audiences.registryAccess().method_30530(class_7924.field_41237).method_55841(FabricAudiences.toNative(bound.type().key())).orElseThrow(() -> new IllegalArgumentException("Could not resolve chat type for key " + String.valueOf(bound.type().key())));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 282 */     Objects.requireNonNull(audiences); return new class_2556.class_7602(type, audiences.toNative(bound.name()), Optional.<Component>ofNullable(bound.target()).map(audiences::toNative));
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   static interface FPointered extends Pointered {
/*     */     @NotNull
/*     */     Pointers pointers();
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\AdventureCommon.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */