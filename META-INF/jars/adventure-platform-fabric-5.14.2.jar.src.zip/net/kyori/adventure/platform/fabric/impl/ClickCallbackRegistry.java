/*     */ package net.kyori.adventure.platform.fabric.impl;
/*     */ 
/*     */ import com.google.common.cache.Cache;
/*     */ import com.google.common.cache.CacheBuilder;
/*     */ import com.google.common.cache.RemovalNotification;
/*     */ import com.mojang.brigadier.CommandDispatcher;
/*     */ import com.mojang.brigadier.arguments.ArgumentType;
/*     */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*     */ import com.mojang.brigadier.context.CommandContext;
/*     */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*     */ import com.mojang.logging.LogUtils;
/*     */ import java.time.Instant;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import net.kyori.adventure.audience.Audience;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.event.ClickCallback;
/*     */ import net.kyori.adventure.text.format.NamedTextColor;
/*     */ import net.kyori.adventure.text.format.TextColor;
/*     */ import net.minecraft.class_2168;
/*     */ import net.minecraft.class_2170;
/*     */ import net.minecraft.class_5242;
/*     */ import org.slf4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClickCallbackRegistry
/*     */ {
/*  49 */   private static final Logger LOGGER = LogUtils.getLogger();
/*     */   
/*  51 */   public static final ClickCallbackRegistry INSTANCE = new ClickCallbackRegistry();
/*     */   
/*     */   public static final int CLEAN_UP_RATE = 30;
/*     */   
/*     */   private static final String UUID_ARG = "uuid";
/*     */   private static final String COMMAND_NAME = "adventure_callback";
/*  57 */   private static final Component FAILURE_MESSAGE = (Component)Component.text("No callback with that ID could be found! You may have used it too many times, or it may have expired.", (TextColor)NamedTextColor.RED); private final Cache<UUID, CallbackRegistration> registrations;
/*     */   private ClickCallbackRegistry() {
/*  59 */     this
/*     */ 
/*     */ 
/*     */       
/*  63 */       .registrations = CacheBuilder.newBuilder().expireAfterWrite(24L, TimeUnit.HOURS).maximumSize(1024L).removalListener(notification -> LOGGER.debug("Removing callback {} from cache for reason {}", notification.getKey(), notification.getCause())).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String register(ClickCallback<Audience> callback, ClickCallback.Options options) {
/*  77 */     UUID id = UUID.randomUUID();
/*     */ 
/*     */ 
/*     */     
/*  81 */     CallbackRegistration reg = new CallbackRegistration(options, callback, Instant.now().plus(options.lifetime()), new AtomicInteger());
/*     */ 
/*     */ 
/*     */     
/*  85 */     this.registrations.put(id, reg);
/*     */     
/*  87 */     return "/adventure_callback " + String.valueOf(id);
/*     */   }
/*     */   
/*     */   public void registerToDispatcher(CommandDispatcher<class_2168> dispatcher) {
/*  91 */     dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)class_2170.method_9247("adventure_callback")
/*  92 */         .requires(HiddenRequirement.alwaysAllowed()))
/*  93 */         .then(class_2170.method_9244("uuid", (ArgumentType)class_5242.method_27643())
/*  94 */           .executes(ctx -> {
/*     */               UUID callbackId = class_5242.method_27645(ctx, "uuid");
/*     */               CallbackRegistration reg = (CallbackRegistration)this.registrations.getIfPresent(callbackId);
/*     */               if (reg == null) {
/*     */                 ((class_2168)ctx.getSource()).sendFailure(FAILURE_MESSAGE);
/*     */                 return 0;
/*     */               } 
/*     */               boolean expire = false;
/*     */               boolean allowUse = true;
/*     */               int allowedUses = reg.options.uses();
/*     */               if (allowedUses != -1) {
/*     */                 int useCount = reg.useCount().incrementAndGet();
/*     */                 if (useCount >= allowedUses) {
/*     */                   expire = true;
/*     */                   allowUse = (useCount <= allowedUses);
/*     */                 } 
/*     */               } 
/*     */               Instant now = Instant.now();
/*     */               if (now.isAfter(reg.expiryTime())) {
/*     */                 expire = true;
/*     */                 allowUse = false;
/*     */               } 
/*     */               if (expire) {
/*     */                 this.registrations.invalidate(callbackId);
/*     */               }
/*     */               if (allowUse) {
/*     */                 reg.callback().accept((Audience)ctx.getSource());
/*     */               } else {
/*     */                 ((class_2168)ctx.getSource()).sendFailure(FAILURE_MESSAGE);
/*     */               } 
/*     */               return 1;
/*     */             })));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanUp() {
/* 139 */     Instant now = Instant.now();
/*     */     
/* 141 */     Set<UUID> uuidsToClean = new HashSet<>();
/* 142 */     for (Map.Entry<UUID, CallbackRegistration> entry : (Iterable<Map.Entry<UUID, CallbackRegistration>>)this.registrations.asMap().entrySet()) {
/* 143 */       CallbackRegistration reg = entry.getValue();
/* 144 */       int allowedUses = reg.options().uses();
/* 145 */       if (allowedUses != -1 && reg.useCount().get() >= allowedUses) {
/* 146 */         uuidsToClean.add(entry.getKey()); continue;
/* 147 */       }  if (now.isAfter(reg.expiryTime())) {
/* 148 */         uuidsToClean.add(entry.getKey());
/*     */       }
/*     */     } 
/*     */     
/* 152 */     for (UUID id : uuidsToClean)
/* 153 */       this.registrations.invalidate(id); 
/*     */   }
/*     */   private static final class CallbackRegistration extends Record { private final ClickCallback.Options options; private final ClickCallback<Audience> callback; private final Instant expiryTime; private final AtomicInteger useCount;
/*     */     
/* 157 */     private CallbackRegistration(ClickCallback.Options options, ClickCallback<Audience> callback, Instant expiryTime, AtomicInteger useCount) { this.options = options; this.callback = callback; this.expiryTime = expiryTime; this.useCount = useCount; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lnet/kyori/adventure/platform/fabric/impl/ClickCallbackRegistry$CallbackRegistration;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #157	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 157 */       //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/ClickCallbackRegistry$CallbackRegistration; } public ClickCallback.Options options() { return this.options; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lnet/kyori/adventure/platform/fabric/impl/ClickCallbackRegistry$CallbackRegistration;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #157	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/ClickCallbackRegistry$CallbackRegistration; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lnet/kyori/adventure/platform/fabric/impl/ClickCallbackRegistry$CallbackRegistration;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #157	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/ClickCallbackRegistry$CallbackRegistration;
/* 157 */       //   0	8	1	o	Ljava/lang/Object; } public ClickCallback<Audience> callback() { return this.callback; } public Instant expiryTime() { return this.expiryTime; } public AtomicInteger useCount() { return this.useCount; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\ClickCallbackRegistry.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */