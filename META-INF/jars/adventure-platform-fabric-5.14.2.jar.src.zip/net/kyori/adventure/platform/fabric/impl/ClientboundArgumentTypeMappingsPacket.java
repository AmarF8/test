/*    */ package net.kyori.adventure.platform.fabric.impl;
/*    */ 
/*    */ import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.IntFunction;
/*    */ import net.fabricmc.fabric.api.networking.v1.PacketSender;
/*    */ import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_8710;
/*    */ import net.minecraft.class_9129;
/*    */ import net.minecraft.class_9135;
/*    */ import net.minecraft.class_9139;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ClientboundArgumentTypeMappingsPacket
/*    */   extends Record
/*    */   implements class_8710
/*    */ {
/*    */   private final Int2ObjectMap<class_2960> mappings;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lnet/kyori/adventure/platform/fabric/impl/ClientboundArgumentTypeMappingsPacket;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #39	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/ClientboundArgumentTypeMappingsPacket;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lnet/kyori/adventure/platform/fabric/impl/ClientboundArgumentTypeMappingsPacket;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #39	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/ClientboundArgumentTypeMappingsPacket;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lnet/kyori/adventure/platform/fabric/impl/ClientboundArgumentTypeMappingsPacket;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #39	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/ClientboundArgumentTypeMappingsPacket;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   public ClientboundArgumentTypeMappingsPacket(Int2ObjectMap<class_2960> mappings) {
/* 39 */     this.mappings = mappings; } public Int2ObjectMap<class_2960> mappings() { return this.mappings; }
/* 40 */    public static final class_8710.class_9154<ClientboundArgumentTypeMappingsPacket> TYPE = new class_8710.class_9154(AdventureCommon.res("registered_arg_mappings"));
/* 41 */   private static final class_9139<class_9129, ClientboundArgumentTypeMappingsPacket> CODEC = class_9139.method_56434(
/* 42 */       class_9135.method_56377(it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap::new, class_9135.field_48550, class_2960.field_48267), ClientboundArgumentTypeMappingsPacket::mappings, ClientboundArgumentTypeMappingsPacket::new);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void register() {
/* 48 */     PayloadTypeRegistry.playS2C().register(TYPE, CODEC);
/*    */   }
/*    */   
/*    */   public void sendTo(PacketSender responder) {
/* 52 */     responder.sendPacket(this);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public class_8710.class_9154<? extends class_8710> method_56479() {
/* 57 */     return (class_8710.class_9154)TYPE;
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\ClientboundArgumentTypeMappingsPacket.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */