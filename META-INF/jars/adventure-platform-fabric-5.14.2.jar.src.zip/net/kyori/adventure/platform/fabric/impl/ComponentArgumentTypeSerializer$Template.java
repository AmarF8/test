/*    */ package net.kyori.adventure.platform.fabric.impl;
/*    */ 
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import net.kyori.adventure.platform.fabric.ComponentArgumentType;
/*    */ import net.minecraft.class_2314;
/*    */ import net.minecraft.class_7157;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Template
/*    */   extends Record
/*    */   implements class_2314.class_7217<ComponentArgumentType>
/*    */ {
/*    */   private final ComponentArgumentType.Format format;
/*    */   
/*    */   Template(ComponentArgumentType.Format format) {
/* 66 */     this.format = format; } public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lnet/kyori/adventure/platform/fabric/impl/ComponentArgumentTypeSerializer$Template;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #66	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/* 66 */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/ComponentArgumentTypeSerializer$Template; } public ComponentArgumentType.Format format() { return this.format; }
/*    */   public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lnet/kyori/adventure/platform/fabric/impl/ComponentArgumentTypeSerializer$Template;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #66	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/ComponentArgumentTypeSerializer$Template; }
/*    */   public final boolean equals(Object o) { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lnet/kyori/adventure/platform/fabric/impl/ComponentArgumentTypeSerializer$Template;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #66	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/ComponentArgumentTypeSerializer$Template;
/*    */     //   0	8	1	o	Ljava/lang/Object; } public ComponentArgumentType instantiate(class_7157 commandBuildContext) {
/* 69 */     return ComponentArgumentType.component(this.format);
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2314<ComponentArgumentType, ?> method_41728() {
/* 74 */     return ComponentArgumentTypeSerializer.INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\ComponentArgumentTypeSerializer$Template.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */