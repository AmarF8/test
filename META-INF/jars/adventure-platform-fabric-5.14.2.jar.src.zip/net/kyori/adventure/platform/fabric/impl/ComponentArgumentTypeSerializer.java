/*    */ package net.kyori.adventure.platform.fabric.impl;
/*    */ 
/*    */ import com.google.gson.JsonObject;
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import net.kyori.adventure.platform.fabric.ComponentArgumentType;
/*    */ import net.kyori.adventure.platform.fabric.FabricAudiences;
/*    */ import net.minecraft.class_2314;
/*    */ import net.minecraft.class_2540;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_7157;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ComponentArgumentTypeSerializer
/*    */   implements class_2314<ComponentArgumentType, ComponentArgumentTypeSerializer.Template>
/*    */ {
/* 36 */   public static ComponentArgumentTypeSerializer INSTANCE = new ComponentArgumentTypeSerializer();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serializeToNetwork(Template type, class_2540 buffer) {
/* 43 */     buffer.method_10812(FabricAudiences.toNative(type.format.id()));
/*    */   }
/*    */ 
/*    */   
/*    */   public Template deserializeFromNetwork(class_2540 buffer) {
/* 48 */     class_2960 id = buffer.method_10810();
/* 49 */     ComponentArgumentType.Format format = (ComponentArgumentType.Format)ComponentArgumentType.Format.INDEX.value(id);
/* 50 */     if (format == null) {
/* 51 */       throw new IllegalArgumentException("Unknown Adventure component format: " + String.valueOf(id));
/*    */     }
/* 53 */     return new Template(format);
/*    */   }
/*    */ 
/*    */   
/*    */   public void serializeToJson(Template type, JsonObject json) {
/* 58 */     json.addProperty("serializer", type.format.id().asString());
/*    */   }
/*    */ 
/*    */   
/*    */   public Template unpack(ComponentArgumentType argumentType) {
/* 63 */     return new Template(argumentType.format());
/*    */   }
/*    */   static final class Template extends Record implements class_2314.class_7217<ComponentArgumentType> { private final ComponentArgumentType.Format format;
/* 66 */     Template(ComponentArgumentType.Format format) { this.format = format; } public final String toString() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Lnet/kyori/adventure/platform/fabric/impl/ComponentArgumentTypeSerializer$Template;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #66	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/* 66 */       //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/ComponentArgumentTypeSerializer$Template; } public ComponentArgumentType.Format format() { return this.format; }
/*    */     public final int hashCode() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Lnet/kyori/adventure/platform/fabric/impl/ComponentArgumentTypeSerializer$Template;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #66	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/ComponentArgumentTypeSerializer$Template; }
/*    */     public final boolean equals(Object o) { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Lnet/kyori/adventure/platform/fabric/impl/ComponentArgumentTypeSerializer$Template;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #66	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/ComponentArgumentTypeSerializer$Template;
/*    */       //   0	8	1	o	Ljava/lang/Object; } public ComponentArgumentType instantiate(class_7157 commandBuildContext) {
/* 69 */       return ComponentArgumentType.component(this.format);
/*    */     }
/*    */ 
/*    */     
/*    */     public class_2314<ComponentArgumentType, ?> method_41728() {
/* 74 */       return ComponentArgumentTypeSerializer.INSTANCE;
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\ComponentArgumentTypeSerializer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */