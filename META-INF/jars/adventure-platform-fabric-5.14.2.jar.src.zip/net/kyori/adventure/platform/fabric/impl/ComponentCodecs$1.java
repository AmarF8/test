/*    */ package net.kyori.adventure.platform.fabric.impl;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.mojang.datafixers.util.Pair;
/*    */ import com.mojang.serialization.Codec;
/*    */ import com.mojang.serialization.DataResult;
/*    */ import com.mojang.serialization.DynamicOps;
/*    */ import com.mojang.serialization.JsonOps;
/*    */ import net.kyori.adventure.text.serializer.gson.GsonComponentSerializer;
/*    */ import net.minecraft.class_2561;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements Codec<class_2561>
/*    */ {
/*    */   public <T> DataResult<T> encode(class_2561 input, DynamicOps<T> ops, T prefix) {
/* 57 */     if (input instanceof WrappedComponent) { WrappedComponent w = (WrappedComponent)input;
/* 58 */       if (w.deepConvertedIfPresent() != null) {
/* 59 */         return original.encode(w.deepConvertedIfPresent(), ops, prefix);
/*    */       }
/*    */       
/* 62 */       JsonElement json = GsonComponentSerializer.gson().serializeToTree(w.wrapped());
/* 63 */       if (ops instanceof JsonOps)
/* 64 */         return DataResult.success(json); 
/* 65 */       if (ops instanceof net.minecraft.class_6903 && ops instanceof DelegatingOpsBridge) { DelegatingOpsBridge deleg = (DelegatingOpsBridge)ops; if (deleg.adventure$bridge$delegate() instanceof JsonOps)
/* 66 */           return DataResult.success(json);  }
/*    */       
/* 68 */       return DataResult.success(JsonOps.INSTANCE.convertTo(ops, json)); }
/*    */ 
/*    */ 
/*    */     
/* 72 */     return original.encode(input, ops, prefix);
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> DataResult<Pair<class_2561, T>> decode(DynamicOps<T> ops, T input) {
/* 77 */     return original.decode(ops, input);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\ComponentCodecs$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */