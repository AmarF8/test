/*    */ package net.kyori.adventure.platform.fabric.impl;
/*    */ 
/*    */ import net.kyori.adventure.platform.fabric.impl.server.FriendlyByteBufBridge;
/*    */ import net.kyori.adventure.pointer.Pointered;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_9139;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements class_9139<T, class_2561>
/*    */ {
/*    */   public class_2561 decode(T buf) {
/* 86 */     return (class_2561)original.decode(buf);
/*    */   }
/*    */ 
/*    */   
/*    */   public void encode(T buf, class_2561 component) {
/* 91 */     if (buf instanceof FriendlyByteBufBridge) {
/* 92 */       Pointered adventure$data = ((FriendlyByteBufBridge)buf).adventure$data();
/* 93 */       if (adventure$data != null && component instanceof WrappedComponent) { WrappedComponent input = (WrappedComponent)component;
/* 94 */         original.encode(buf, input.rendered(adventure$data));
/*    */         
/*    */         return; }
/*    */     
/*    */     } 
/* 99 */     original.encode(buf, component);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\ComponentCodecs$2.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */