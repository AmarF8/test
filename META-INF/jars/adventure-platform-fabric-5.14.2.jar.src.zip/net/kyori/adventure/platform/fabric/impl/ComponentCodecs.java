/*    */ package net.kyori.adventure.platform.fabric.impl;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.mojang.datafixers.util.Pair;
/*    */ import com.mojang.serialization.Codec;
/*    */ import com.mojang.serialization.DataResult;
/*    */ import com.mojang.serialization.DynamicOps;
/*    */ import com.mojang.serialization.JsonOps;
/*    */ import com.mojang.serialization.Lifecycle;
/*    */ import net.kyori.adventure.platform.fabric.impl.server.FriendlyByteBufBridge;
/*    */ import net.kyori.adventure.pointer.Pointered;
/*    */ import net.kyori.adventure.text.serializer.gson.GsonComponentSerializer;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_9139;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ComponentCodecs
/*    */ {
/*    */   public static Codec<class_2561> unwrappingToNative(final Codec<class_2561> original) {
/* 53 */     return (new Codec<class_2561>()
/*    */       {
/*    */         public <T> DataResult<T> encode(class_2561 input, DynamicOps<T> ops, T prefix)
/*    */         {
/* 57 */           if (input instanceof WrappedComponent) { WrappedComponent w = (WrappedComponent)input;
/* 58 */             if (w.deepConvertedIfPresent() != null) {
/* 59 */               return original.encode(w.deepConvertedIfPresent(), ops, prefix);
/*    */             }
/*    */             
/* 62 */             JsonElement json = GsonComponentSerializer.gson().serializeToTree(w.wrapped());
/* 63 */             if (ops instanceof JsonOps)
/* 64 */               return DataResult.success(json); 
/* 65 */             if (ops instanceof net.minecraft.class_6903 && ops instanceof DelegatingOpsBridge) { DelegatingOpsBridge deleg = (DelegatingOpsBridge)ops; if (deleg.adventure$bridge$delegate() instanceof JsonOps)
/* 66 */                 return DataResult.success(json);  }
/*    */             
/* 68 */             return DataResult.success(JsonOps.INSTANCE.convertTo(ops, json)); }
/*    */ 
/*    */ 
/*    */           
/* 72 */           return original.encode(input, ops, prefix);
/*    */         }
/*    */ 
/*    */         
/*    */         public <T> DataResult<Pair<class_2561, T>> decode(DynamicOps<T> ops, T input) {
/* 77 */           return original.decode(ops, input);
/*    */         }
/* 79 */       }).withLifecycle(Lifecycle.stable());
/*    */   }
/*    */   
/*    */   public static <T extends io.netty.buffer.ByteBuf> class_9139<T, class_2561> translatingStreamCodec(final class_9139<T, class_2561> original) {
/* 83 */     return new class_9139<T, class_2561>()
/*    */       {
/*    */         public class_2561 decode(T buf) {
/* 86 */           return (class_2561)original.decode(buf);
/*    */         }
/*    */ 
/*    */         
/*    */         public void encode(T buf, class_2561 component) {
/* 91 */           if (buf instanceof FriendlyByteBufBridge) {
/* 92 */             Pointered adventure$data = ((FriendlyByteBufBridge)buf).adventure$data();
/* 93 */             if (adventure$data != null && component instanceof WrappedComponent) { WrappedComponent input = (WrappedComponent)component;
/* 94 */               original.encode(buf, input.rendered(adventure$data));
/*    */               
/*    */               return; }
/*    */           
/*    */           } 
/* 99 */           original.encode(buf, component);
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\ComponentCodecs.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */