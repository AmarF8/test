package net.kyori.adventure.platform.fabric.impl;

import net.kyori.adventure.audience.Audience;
import org.jetbrains.annotations.NotNull;

public interface ControlledAudience extends Audience {
  @NotNull
  FabricAudiencesInternal controller();
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\ControlledAudience.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */