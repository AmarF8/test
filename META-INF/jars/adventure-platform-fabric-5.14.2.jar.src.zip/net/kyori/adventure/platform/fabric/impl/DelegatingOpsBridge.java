package net.kyori.adventure.platform.fabric.impl;

import com.mojang.serialization.DynamicOps;

public interface DelegatingOpsBridge {
  DynamicOps<?> adventure$bridge$delegate();
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\DelegatingOpsBridge.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */