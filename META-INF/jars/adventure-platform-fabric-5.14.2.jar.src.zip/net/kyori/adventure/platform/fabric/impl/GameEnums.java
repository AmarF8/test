/*    */ package net.kyori.adventure.platform.fabric.impl;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import net.kyori.adventure.bossbar.BossBar;
/*    */ import net.kyori.adventure.resource.ResourcePackStatus;
/*    */ import net.kyori.adventure.sound.Sound;
/*    */ import net.kyori.adventure.util.Index;
/*    */ import net.minecraft.class_1259;
/*    */ import net.minecraft.class_2856;
/*    */ import net.minecraft.class_3419;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GameEnums
/*    */ {
/* 39 */   public static final MappedRegistry<class_1259.class_1260, BossBar.Color> BOSS_BAR_COLOR = MappedRegistry.named(class_1259.class_1260.class, class_1259.class_1260::method_5422, BossBar.Color.class, BossBar.Color.NAMES);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   public static final MappedRegistry<class_1259.class_1261, BossBar.Overlay> BOSS_BAR_OVERLAY = MappedRegistry.named(class_1259.class_1261.class, class_1259.class_1261::method_5424, BossBar.Overlay.class, BossBar.Overlay.NAMES);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public static final MappedRegistry<class_3419, Sound.Source> SOUND_SOURCE = MappedRegistry.named(class_3419.class, 
/*    */       
/* 55 */       byNameProvider(class_3419.class, class_3419::method_14840), Sound.Source.class, Sound.Source.NAMES);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 60 */   public static final MappedRegistry<class_2856.class_2857, ResourcePackStatus> RESOURCE_PACK_STATUS = MappedRegistry.named(class_2856.class_2857.class, 
/*    */       
/* 62 */       byNameProvider(class_2856.class_2857.class, Enum::name), ResourcePackStatus.class, 
/*    */       
/* 64 */       Index.create(ResourcePackStatus.class, Enum::name));
/*    */ 
/*    */   
/*    */   private static <E extends Enum<E>> Function<String, E> byNameProvider(Class<E> clazz, Function<E, String> nameProvider) {
/* 68 */     Map<String, E> sources = new HashMap<>();
/* 69 */     for (Enum enum_ : (Enum[])clazz.getEnumConstants()) {
/* 70 */       sources.put(nameProvider.apply((E)enum_), (E)enum_);
/*    */     }
/*    */     
/* 73 */     Objects.requireNonNull(sources); return sources::get;
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\GameEnums.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */