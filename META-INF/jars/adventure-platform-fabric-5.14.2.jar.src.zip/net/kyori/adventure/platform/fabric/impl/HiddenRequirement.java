/*    */ package net.kyori.adventure.platform.fabric.impl;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Predicate;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HiddenRequirement<V>
/*    */   extends Record
/*    */   implements Predicate<V>
/*    */ {
/*    */   private final Predicate<V> base;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lnet/kyori/adventure/platform/fabric/impl/HiddenRequirement;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #38	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/HiddenRequirement;
/*    */     // Local variable type table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/HiddenRequirement<TV;>;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lnet/kyori/adventure/platform/fabric/impl/HiddenRequirement;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #38	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/HiddenRequirement;
/*    */     // Local variable type table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/HiddenRequirement<TV;>;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lnet/kyori/adventure/platform/fabric/impl/HiddenRequirement;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #38	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/HiddenRequirement;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */     // Local variable type table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/HiddenRequirement<TV;>;
/*    */   }
/*    */   
/*    */   public HiddenRequirement(Predicate<V> base) {
/* 38 */     this.base = base; } public Predicate<V> base() { return this.base; }
/*    */    public static <T> HiddenRequirement<T> alwaysAllowed() {
/* 40 */     return new HiddenRequirement<>(t -> true);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean test(V v) {
/* 45 */     return this.base.test(v);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Predicate<V> and(@NotNull Predicate<? super V> other) {
/* 50 */     return new HiddenRequirement(this.base.and(unwrap(Objects.<Predicate<? super V>>requireNonNull(other, "other"))));
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Predicate<V> negate() {
/* 55 */     return new HiddenRequirement(this.base.negate());
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Predicate<V> or(@NotNull Predicate<? super V> other) {
/* 60 */     return new HiddenRequirement(this.base.or(unwrap(Objects.<Predicate<? super V>>requireNonNull(other, "other"))));
/*    */   }
/*    */   @NotNull
/*    */   private static <T> Predicate<T> unwrap(@NotNull Predicate<T> pred) {
/* 64 */     if (pred instanceof HiddenRequirement) { HiddenRequirement hiddenRequirement = (HiddenRequirement)pred; try { Predicate<T> predicate1 = hiddenRequirement.base(), base = predicate1; } catch (Throwable throwable) { throw new MatchException(throwable.toString(), throwable); }  }  return pred;
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\HiddenRequirement.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */