/*    */ package net.kyori.adventure.platform.fabric.impl;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface LocaleHolderBridge
/*    */ {
/*    */   @Nullable
/*    */   static Locale toLocale(@Nullable String mcLocale) {
/* 39 */     if (mcLocale == null) return null;
/*    */     
/* 41 */     String[] parts = mcLocale.split("_", 3);
/* 42 */     switch (parts.length) { case 1: return 
/* 43 */           parts[0].isEmpty() ? null : Locale.of(parts[0]);
/*    */       case 2: 
/*    */       case 3:
/* 46 */        }  return null;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   Locale adventure$locale();
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\LocaleHolderBridge.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */