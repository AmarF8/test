/*     */ package net.kyori.adventure.platform.fabric.impl;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import net.kyori.adventure.util.Index;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MappedRegistry<Mc, Adv>
/*     */ {
/*     */   private final Map<Mc, Adv> mcToAdventure;
/*     */   private final Map<Adv, Mc> adventureToMc;
/*     */   
/*     */   static <Mc extends Enum<Mc>, Adv extends Enum<Adv>> MappedRegistry<Mc, Adv> named(Class<Mc> mcType, Function<String, Mc> mcByName, Class<Adv> advType, Index<String, Adv> names) {
/*  54 */     Objects.requireNonNull(names); return new OfEnum<>(mcType, mcByName, advType, names::key);
/*     */   }
/*     */   
/*     */   static <Mc, Adv> MappedRegistry<Mc, Adv> named(Function<String, Mc> mcByName, Supplier<Iterable<Mc>> mcValues, Index<String, Adv> names, Supplier<Iterable<Adv>> adventureValues) {
/*  58 */     Objects.requireNonNull(names); return new MappedRegistry<>(new HashMap<>(), new HashMap<>(), mcByName, mcValues, names::key, adventureValues);
/*     */   }
/*     */   
/*     */   MappedRegistry(Map<Mc, Adv> mcMap, Map<Adv, Mc> adventureMap, Function<String, Mc> mcByName, Supplier<Iterable<Mc>> mcValues, Function<Adv, String> advToName, Supplier<Iterable<Adv>> adventureValues) {
/*  62 */     this.mcToAdventure = mcMap;
/*  63 */     this.adventureToMc = adventureMap;
/*     */     
/*  65 */     for (Adv advElement : adventureValues.get()) {
/*  66 */       String mcName = advToName.apply(advElement);
/*  67 */       if (mcName == null) {
/*  68 */         throw new ExceptionInInitializerError("Unable to get name for enum-like element " + String.valueOf(advElement));
/*     */       }
/*  70 */       Mc mcElement = mcByName.apply(mcName);
/*  71 */       if (mcElement == null) {
/*  72 */         throw new ExceptionInInitializerError("Unknown MC element for Adventure " + mcName);
/*     */       }
/*  74 */       this.mcToAdventure.put(mcElement, advElement);
/*  75 */       this.adventureToMc.put(advElement, mcElement);
/*     */     } 
/*     */     
/*  78 */     checkCoverage(this.mcToAdventure, mcValues.get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> void checkCoverage(Map<T, ?> toCheck, Iterable<T> values) throws IllegalStateException {
/*  91 */     for (T value : values) {
/*  92 */       if (!toCheck.containsKey(value)) {
/*  93 */         throw new IllegalStateException("Unmapped " + value.getClass().getSimpleName() + " element '" + String.valueOf(value) + "!");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Adv toAdventure(Mc mcItem) {
/* 105 */     return Objects.requireNonNull(this.mcToAdventure.get(mcItem), "Invalid enum value presented: " + String.valueOf(mcItem));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mc toMinecraft(Adv advItem) {
/* 115 */     return this.adventureToMc.get(advItem);
/*     */   }
/*     */   
/*     */   static class OfEnum<Mc extends Enum<Mc>, Adv extends Enum<Adv>>
/*     */     extends MappedRegistry<Mc, Adv> {
/*     */     OfEnum(Class<Mc> mcType, Function<String, Mc> mcByName, Class<Adv> advType, Function<Adv, String> advToName) {
/* 121 */       super(new EnumMap<>(mcType), new EnumMap<>(advType), mcByName, () -> Arrays.asList(mcType.getEnumConstants()), advToName, () -> Arrays.asList(advType.getEnumConstants()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\MappedRegistry.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */