/*    */ package net.kyori.adventure.platform.fabric.impl;
/*    */ 
/*    */ import com.google.common.base.Suppliers;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.mojang.serialization.DynamicOps;
/*    */ import com.mojang.serialization.JsonOps;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.Supplier;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.kyori.adventure.text.serializer.ComponentSerializer;
/*    */ import net.kyori.adventure.text.serializer.gson.GsonComponentSerializer;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_5250;
/*    */ import net.minecraft.class_5455;
/*    */ import net.minecraft.class_7225;
/*    */ import net.minecraft.class_7923;
/*    */ import net.minecraft.class_8824;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NonWrappingComponentSerializer
/*    */   implements ComponentSerializer<Component, Component, class_2561>
/*    */ {
/* 41 */   public static final NonWrappingComponentSerializer INSTANCE = new NonWrappingComponentSerializer();
/*    */   
/* 43 */   private static final ThreadLocal<Boolean> BYPASS_IS_ALLOWED_FROM_SERVER = ThreadLocal.withInitial(() -> Boolean.valueOf(false));
/*    */   private final Supplier<class_7225.class_7874> holderProvider;
/*    */   
/*    */   private NonWrappingComponentSerializer() {
/* 47 */     this((Supplier<class_7225.class_7874>)Suppliers.ofInstance(class_5455.method_40302(class_7923.field_41167)));
/*    */   }
/*    */   
/*    */   public NonWrappingComponentSerializer(@NotNull Supplier<class_7225.class_7874> provider) {
/* 51 */     this.holderProvider = provider;
/*    */   }
/*    */   
/*    */   public static boolean bypassIsAllowedFromServer() {
/* 55 */     return ((Boolean)BYPASS_IS_ALLOWED_FROM_SERVER.get()).booleanValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public Component deserialize(class_2561 input) {
/* 60 */     if (input instanceof WrappedComponent) {
/* 61 */       return ((WrappedComponent)input).wrapped();
/*    */     }
/*    */     
/* 64 */     return GsonComponentSerializer.gson().deserializeFromTree((JsonElement)class_8824.field_46597
/* 65 */         .encodeStart((DynamicOps)((class_7225.class_7874)this.holderProvider.get()).method_57093((DynamicOps)JsonOps.INSTANCE), input)
/* 66 */         .getOrThrow(com.google.gson.JsonParseException::new));
/*    */   }
/*    */ 
/*    */   
/*    */   public class_5250 serialize(Component component) {
/*    */     class_5250 mutableComponent;
/* 72 */     BYPASS_IS_ALLOWED_FROM_SERVER.set(Boolean.valueOf(true));
/*    */     
/*    */     try {
/* 75 */       mutableComponent = class_2561.class_2562.method_10872(GsonComponentSerializer.gson().serializeToTree(component), this.holderProvider.get());
/*    */     } finally {
/* 77 */       BYPASS_IS_ALLOWED_FROM_SERVER.set(Boolean.valueOf(false));
/*    */     } 
/* 79 */     return mutableComponent;
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\NonWrappingComponentSerializer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */