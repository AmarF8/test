/*    */ package net.kyori.adventure.platform.fabric.impl;
/*    */ 
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.suggestion.SuggestionProvider;
/*    */ import java.util.function.BiFunction;
/*    */ import net.minecraft.class_2314;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_7157;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ServerArgumentType<T extends ArgumentType<?>>
/*    */   extends Record
/*    */ {
/*    */   private final class_2960 id;
/*    */   private final Class<? super T> type;
/*    */   private final class_2314<T, ? extends class_2314.class_7217<T>> argumentTypeInfo;
/*    */   private final BiFunction<T, class_7157, ArgumentType<?>> fallbackProvider;
/*    */   private final SuggestionProvider<?> fallbackSuggestions;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lnet/kyori/adventure/platform/fabric/impl/ServerArgumentType;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #43	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/ServerArgumentType;
/*    */     // Local variable type table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/ServerArgumentType<TT;>;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lnet/kyori/adventure/platform/fabric/impl/ServerArgumentType;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #43	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/ServerArgumentType;
/*    */     // Local variable type table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/ServerArgumentType<TT;>;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lnet/kyori/adventure/platform/fabric/impl/ServerArgumentType;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #43	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/ServerArgumentType;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */     // Local variable type table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/ServerArgumentType<TT;>;
/*    */   }
/*    */   
/*    */   public ServerArgumentType(class_2960 id, Class<? super T> type, class_2314<T, ? extends class_2314.class_7217<T>> argumentTypeInfo, BiFunction<T, class_7157, ArgumentType<?>> fallbackProvider, SuggestionProvider<?> fallbackSuggestions) {
/* 43 */     this.id = id; this.type = type; this.argumentTypeInfo = argumentTypeInfo; this.fallbackProvider = fallbackProvider; this.fallbackSuggestions = fallbackSuggestions; } public class_2960 id() { return this.id; } public Class<? super T> type() { return this.type; } public class_2314<T, ? extends class_2314.class_7217<T>> argumentTypeInfo() { return this.argumentTypeInfo; } public BiFunction<T, class_7157, ArgumentType<?>> fallbackProvider() { return this.fallbackProvider; } public SuggestionProvider<?> fallbackSuggestions() { return this.fallbackSuggestions; }
/*    */ 
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\ServerArgumentType.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */