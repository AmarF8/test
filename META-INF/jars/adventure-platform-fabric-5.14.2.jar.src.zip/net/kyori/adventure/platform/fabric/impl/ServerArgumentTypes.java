/*     */ package net.kyori.adventure.platform.fabric.impl;
/*     */ 
/*     */ import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
/*     */ import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
/*     */ import it.unimi.dsi.fastutil.objects.ObjectIterator;
/*     */ import it.unimi.dsi.fastutil.objects.Reference2IntMap;
/*     */ import it.unimi.dsi.fastutil.objects.Reference2IntOpenHashMap;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import net.fabricmc.fabric.api.networking.v1.PacketSender;
/*     */ import net.kyori.adventure.platform.fabric.impl.server.ServerPlayerBridge;
/*     */ import net.minecraft.class_2314;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_3222;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ServerArgumentTypes
/*     */ {
/*  48 */   private static final Map<Class<?>, ServerArgumentType<?>> BY_TYPE = new HashMap<>();
/*  49 */   private static final Map<class_2960, ServerArgumentType<?>> BY_LOCATION = new ConcurrentHashMap<>();
/*  50 */   private static final Map<class_2314<?, ?>, ServerArgumentType<?>> BY_INFO = new HashMap<>();
/*  51 */   private static final Int2ObjectMap<ServerArgumentType<?>> BY_ID = (Int2ObjectMap<ServerArgumentType<?>>)new Int2ObjectArrayMap();
/*  52 */   private static final Reference2IntMap<class_2314<?, ?>> IDS_BY_TYPE_INFO = (Reference2IntMap<class_2314<?, ?>>)new Reference2IntOpenHashMap();
/*  53 */   private static final AtomicInteger ID_COUNTER = new AtomicInteger(100000); @Nullable
/*  54 */   private static Int2ObjectMap<ServerArgumentType<?>> BY_ID_ACTIVE_SERVER = null;
/*     */ 
/*     */   
/*     */   public static <T extends com.mojang.brigadier.arguments.ArgumentType<?>> ServerArgumentType<T> byClass(Class<T> clazz) {
/*  58 */     return (ServerArgumentType<T>)BY_TYPE.get(Objects.requireNonNull(clazz, "clazz"));
/*     */   }
/*     */   
/*     */   static {
/*  62 */     IDS_BY_TYPE_INFO.defaultReturnValue(-1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void register(ServerArgumentType<?> type) {
/*  69 */     int id = ID_COUNTER.getAndIncrement();
/*  70 */     BY_ID.put(id, type);
/*  71 */     IDS_BY_TYPE_INFO.put(type.argumentTypeInfo(), id);
/*  72 */     BY_INFO.put(type.argumentTypeInfo(), type);
/*  73 */     BY_TYPE.put(type.type(), type);
/*  74 */     BY_LOCATION.put(type.id(), type);
/*     */   }
/*     */   
/*     */   public static Set<class_2960> ids() {
/*  78 */     return Collections.unmodifiableSet(BY_LOCATION.keySet());
/*     */   }
/*     */   
/*     */   public static boolean isServerType(class_2314<?, ?> argumentTypeInfo) {
/*  82 */     return IDS_BY_TYPE_INFO.containsKey(argumentTypeInfo);
/*     */   }
/*     */   
/*     */   public static boolean hasId(int id) {
/*  86 */     return BY_ID.containsKey(id);
/*     */   }
/*     */   
/*     */   public static ServerArgumentType<?> byId(int id) {
/*  90 */     return (ServerArgumentType)((Int2ObjectMap)Objects.<Int2ObjectMap>requireNonNullElse(BY_ID_ACTIVE_SERVER, BY_ID)).get(id);
/*     */   }
/*     */   
/*     */   public static ServerArgumentType<?> serverType(class_2314<?, ?> argumentTypeInfo) {
/*  94 */     return BY_INFO.get(argumentTypeInfo);
/*     */   }
/*     */   
/*     */   public static int id(class_2314<?, ?> argumentTypeInfo) {
/*  98 */     return IDS_BY_TYPE_INFO.getInt(argumentTypeInfo);
/*     */   }
/*     */   
/*     */   public static void knownArgumentTypes(class_3222 player, Set<class_2960> ids, PacketSender responder) {
/* 102 */     ((ServerPlayerBridge)player).bridge$knownArguments(ids);
/* 103 */     sendMappings(player, responder);
/* 104 */     if (!ids.isEmpty()) {
/* 105 */       player.field_13995.method_3734().method_9241(player);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Set<class_2960> knownArgumentTypes(class_3222 player) {
/* 110 */     return ((ServerPlayerBridge)player).bridge$knownArguments();
/*     */   }
/*     */   
/*     */   private static void sendMappings(class_3222 player, PacketSender responder) {
/* 114 */     Set<class_2960> known = knownArgumentTypes(player);
/* 115 */     Int2ObjectArrayMap int2ObjectArrayMap = new Int2ObjectArrayMap();
/* 116 */     for (class_2960 resourceLocation : known) {
/* 117 */       ServerArgumentType<?> type = BY_LOCATION.get(resourceLocation);
/* 118 */       if (type != null) {
/* 119 */         int2ObjectArrayMap.put(id(type.argumentTypeInfo()), type.id());
/*     */       }
/*     */     } 
/* 122 */     (new ClientboundArgumentTypeMappingsPacket((Int2ObjectMap<class_2960>)int2ObjectArrayMap)).sendTo(responder);
/*     */   }
/*     */   
/*     */   public static void receiveMappings(ClientboundArgumentTypeMappingsPacket packet) {
/* 126 */     Int2ObjectArrayMap int2ObjectArrayMap = new Int2ObjectArrayMap();
/* 127 */     for (ObjectIterator<Int2ObjectMap.Entry<class_2960>> objectIterator = packet.mappings().int2ObjectEntrySet().iterator(); objectIterator.hasNext(); ) { Int2ObjectMap.Entry<class_2960> entry = objectIterator.next();
/* 128 */       int2ObjectArrayMap.put(entry.getIntKey(), BY_LOCATION.get(entry.getValue())); }
/*     */     
/* 130 */     BY_ID_ACTIVE_SERVER = (Int2ObjectMap<ServerArgumentType<?>>)int2ObjectArrayMap;
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\ServerArgumentTypes.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */