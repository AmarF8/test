/*    */ package net.kyori.adventure.platform.fabric.impl;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.IntFunction;
/*    */ import net.fabricmc.fabric.api.networking.v1.PacketSender;
/*    */ import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
/*    */ import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_8710;
/*    */ import net.minecraft.class_9129;
/*    */ import net.minecraft.class_9135;
/*    */ import net.minecraft.class_9139;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ServerboundRegisteredArgumentTypesPacket
/*    */   extends Record
/*    */   implements class_8710
/*    */ {
/*    */   private final Set<class_2960> known;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lnet/kyori/adventure/platform/fabric/impl/ServerboundRegisteredArgumentTypesPacket;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #45	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/ServerboundRegisteredArgumentTypesPacket;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lnet/kyori/adventure/platform/fabric/impl/ServerboundRegisteredArgumentTypesPacket;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #45	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/ServerboundRegisteredArgumentTypesPacket;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lnet/kyori/adventure/platform/fabric/impl/ServerboundRegisteredArgumentTypesPacket;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #45	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/ServerboundRegisteredArgumentTypesPacket;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   public ServerboundRegisteredArgumentTypesPacket(Set<class_2960> known) {
/* 45 */     this.known = known; } public Set<class_2960> known() { return this.known; }
/* 46 */    public static final class_8710.class_9154<ServerboundRegisteredArgumentTypesPacket> TYPE = new class_8710.class_9154(AdventureCommon.res("registered_args"));
/* 47 */   private static final class_9139<class_9129, ServerboundRegisteredArgumentTypesPacket> CODEC = class_9139.method_56434(
/* 48 */       class_9135.method_56376(java.util.HashSet::new, class_2960.field_48267), ServerboundRegisteredArgumentTypesPacket::known, ServerboundRegisteredArgumentTypesPacket::new);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void register() {
/* 54 */     PayloadTypeRegistry.playC2S().register(TYPE, CODEC);
/* 55 */     ServerPlayNetworking.registerGlobalReceiver(TYPE, (pkt, ctx) -> ctx.player().method_5682().execute(()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ServerboundRegisteredArgumentTypesPacket of(Set<class_2960> idents) {
/* 63 */     return new ServerboundRegisteredArgumentTypesPacket(Set.copyOf(idents));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendTo(PacketSender sender) {
/* 72 */     sender.sendPacket(this);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public class_8710.class_9154<? extends class_8710> method_56479() {
/* 77 */     return (class_8710.class_9154)TYPE;
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\ServerboundRegisteredArgumentTypesPacket.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */