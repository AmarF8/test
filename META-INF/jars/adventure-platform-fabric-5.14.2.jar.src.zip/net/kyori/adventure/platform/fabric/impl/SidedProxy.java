package net.kyori.adventure.platform.fabric.impl;

import java.util.function.Function;
import net.kyori.adventure.pointer.Pointered;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.flattener.ComponentFlattener;
import net.kyori.adventure.text.renderer.ComponentRenderer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface SidedProxy {
  void contributeFlattenerElements(ComponentFlattener.Builder paramBuilder);
  
  @NotNull
  WrappedComponent createWrappedComponent(@NotNull Component paramComponent, @Nullable Function<Pointered, ?> paramFunction, @Nullable ComponentRenderer<Pointered> paramComponentRenderer, @Nullable NonWrappingComponentSerializer paramNonWrappingComponentSerializer);
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\SidedProxy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */