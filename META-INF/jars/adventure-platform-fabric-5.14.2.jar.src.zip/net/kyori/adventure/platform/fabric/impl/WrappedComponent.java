/*     */ package net.kyori.adventure.platform.fabric.impl;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import net.kyori.adventure.platform.fabric.FabricAudiences;
/*     */ import net.kyori.adventure.pointer.Pointered;
/*     */ import net.kyori.adventure.pointer.Pointers;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.TextComponent;
/*     */ import net.kyori.adventure.text.renderer.ComponentRenderer;
/*     */ import net.kyori.adventure.text.serializer.ComponentSerializer;
/*     */ import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2583;
/*     */ import net.minecraft.class_5250;
/*     */ import net.minecraft.class_5348;
/*     */ import net.minecraft.class_5481;
/*     */ import net.minecraft.class_7417;
/*     */ import net.minecraft.class_8828;
/*     */ import org.jetbrains.annotations.ApiStatus.OverrideOnly;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WrappedComponent
/*     */   implements class_2561
/*     */ {
/*     */   protected class_2561 converted;
/*     */   @Nullable
/*  49 */   protected Object deepConvertedLocalized = null;
/*     */   private final Component wrapped;
/*     */   @Nullable
/*     */   private final Function<Pointered, ?> partition;
/*     */   @Nullable
/*     */   private final ComponentRenderer<Pointered> renderer;
/*     */   @Nullable
/*     */   private final NonWrappingComponentSerializer nonWrappingSerializer;
/*     */   @Nullable
/*     */   private Object lastData;
/*     */   @Nullable
/*     */   private WrappedComponent lastRendered;
/*     */   
/*     */   public WrappedComponent(Component wrapped, @Nullable Function<Pointered, ?> partition, @Nullable ComponentRenderer<Pointered> renderer, @Nullable NonWrappingComponentSerializer nonWrappingComponentSerializer) {
/*  63 */     this.wrapped = wrapped;
/*  64 */     this.partition = partition;
/*  65 */     this.renderer = renderer;
/*  66 */     this.nonWrappingSerializer = nonWrappingComponentSerializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ComponentRenderer<Pointered> renderer() {
/*  75 */     return this.renderer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Function<Pointered, ?> partition() {
/*  84 */     return this.partition;
/*     */   }
/*     */   
/*     */   public Component wrapped() {
/*  88 */     return this.wrapped;
/*     */   }
/*     */   
/*     */   public synchronized WrappedComponent rendered(Pointered ptr) {
/*  92 */     Object data = (this.partition == null) ? null : this.partition.apply(ptr);
/*  93 */     if (this.lastData != null && Objects.equals(data, this.lastData)) {
/*  94 */       return this.lastRendered;
/*     */     }
/*  96 */     this.lastData = data;
/*  97 */     return this.lastRendered = (this.renderer == null) ? this : AdventureCommon.SIDE_PROXY.createWrappedComponent(this.renderer.render(this.wrapped, ptr), null, null, this.nonWrappingSerializer);
/*     */   }
/*     */   
/*     */   public class_2561 deepConverted() {
/* 101 */     class_2561 converted = this.converted;
/* 102 */     if (converted == null || this.deepConvertedLocalized != null) {
/* 103 */       ComponentSerializer<Component, Component, class_2561> serializer = this.nonWrappingSerializer;
/* 104 */       if (serializer == null) {
/* 105 */         serializer = FabricAudiences.nonWrappingSerializer();
/*     */       }
/* 107 */       converted = this.converted = (class_2561)serializer.serialize(this.wrapped);
/* 108 */       this.deepConvertedLocalized = null;
/*     */     } 
/* 110 */     return converted;
/*     */   }
/*     */   
/*     */   @OverrideOnly
/*     */   protected class_2561 deepConvertedLocalized() {
/* 115 */     return deepConverted();
/*     */   }
/*     */   @Nullable
/*     */   public class_2561 deepConvertedIfPresent() {
/* 119 */     return this.converted;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_2583 method_10866() {
/* 124 */     return deepConverted().method_10866();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString() {
/* 129 */     return PlainTextComponentSerializer.plainText().serialize((rendered(AdventureCommon.pointered(Pointers::empty))).wrapped);
/*     */   }
/*     */ 
/*     */   
/*     */   public String method_10858(int length) {
/* 134 */     return deepConverted().method_10858(length);
/*     */   }
/*     */ 
/*     */   
/*     */   public class_7417 method_10851() {
/* 139 */     Component component = this.wrapped; if (component instanceof TextComponent) { TextComponent text = (TextComponent)component;
/* 140 */       return (class_7417)new class_8828.class_2585(text.content()); }
/*     */     
/* 142 */     return deepConverted().method_10851();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<class_2561> method_10855() {
/* 148 */     return deepConverted().method_10855();
/*     */   }
/*     */ 
/*     */   
/*     */   public class_5250 method_27662() {
/* 153 */     return deepConverted().method_27662();
/*     */   }
/*     */ 
/*     */   
/*     */   public class_5250 method_27661() {
/* 158 */     return deepConverted().method_27661();
/*     */   }
/*     */ 
/*     */   
/*     */   public class_5481 method_30937() {
/* 163 */     return deepConvertedLocalized().method_30937();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Optional<T> method_27658(class_5348.class_5246<T> visitor, class_2583 style) {
/* 168 */     return deepConvertedLocalized().method_27658(visitor, style);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Optional<T> method_27657(class_5348.class_5245<T> visitor) {
/* 173 */     return deepConverted().method_27657(visitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public Component asComponent() {
/* 178 */     return this.wrapped;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 183 */     return deepConverted().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 188 */     if (obj instanceof WrappedComponent) { WrappedComponent wrappedComponent = (WrappedComponent)obj;
/* 189 */       return wrapped().equals(wrappedComponent.wrapped()); }
/*     */     
/* 191 */     return deepConverted().equals(obj);
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\WrappedComponent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */