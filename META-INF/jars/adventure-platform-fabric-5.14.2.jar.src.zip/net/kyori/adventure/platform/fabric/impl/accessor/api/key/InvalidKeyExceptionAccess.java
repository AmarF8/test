/*    */ package net.kyori.adventure.platform.fabric.impl.accessor.api.key;
/*    */ 
/*    */ import net.kyori.adventure.key.InvalidKeyException;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.gen.Invoker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({InvalidKeyException.class})
/*    */ public interface InvalidKeyExceptionAccess
/*    */ {
/*    */   @Invoker("<init>")
/*    */   static InvalidKeyException newInvalidKeyException(@NotNull String keyNamespace, @NotNull String keyValue, @Nullable String message) {
/* 36 */     throw new IncompatibleClassChangeError("mixin missing");
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\accessor\api\key\InvalidKeyExceptionAccess.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */