package net.kyori.adventure.platform.fabric.impl.accessor.brigadier.builder;

import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value = {RequiredArgumentBuilder.class}, remap = false)
public interface RequiredArgumentBuilderAccess {
  @Accessor("type")
  @Mutable
  void accessor$type(ArgumentType<?> paramArgumentType);
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\accessor\brigadier\builder\RequiredArgumentBuilderAccess.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */