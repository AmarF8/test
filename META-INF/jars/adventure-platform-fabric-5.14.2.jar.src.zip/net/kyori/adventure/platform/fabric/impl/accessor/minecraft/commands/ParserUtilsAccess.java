/*    */ package net.kyori.adventure.platform.fabric.impl.accessor.minecraft.commands;
/*    */ 
/*    */ import com.google.gson.stream.JsonReader;
/*    */ import net.minecraft.class_9010;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.gen.Invoker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_9010.class})
/*    */ public interface ParserUtilsAccess
/*    */ {
/*    */   @Invoker("getPos")
/*    */   static int getPos(JsonReader reader) {
/* 35 */     throw new AssertionError();
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\accessor\minecraft\commands\ParserUtilsAccess.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */