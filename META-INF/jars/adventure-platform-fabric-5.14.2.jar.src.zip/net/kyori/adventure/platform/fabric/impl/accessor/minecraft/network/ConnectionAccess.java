package net.kyori.adventure.platform.fabric.impl.accessor.minecraft.network;

import io.netty.channel.Channel;
import net.minecraft.class_2535;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_2535.class})
public interface ConnectionAccess {
  @Accessor("channel")
  Channel accessor$channel();
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\accessor\minecraft\network\ConnectionAccess.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */