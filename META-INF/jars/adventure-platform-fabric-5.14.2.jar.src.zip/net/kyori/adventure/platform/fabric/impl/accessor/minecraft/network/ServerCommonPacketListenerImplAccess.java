package net.kyori.adventure.platform.fabric.impl.accessor.minecraft.network;

import net.minecraft.class_2535;
import net.minecraft.class_8609;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_8609.class})
public interface ServerCommonPacketListenerImplAccess {
  @Accessor("connection")
  @Final
  class_2535 accessor$connection();
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\accessor\minecraft\network\ServerCommonPacketListenerImplAccess.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */