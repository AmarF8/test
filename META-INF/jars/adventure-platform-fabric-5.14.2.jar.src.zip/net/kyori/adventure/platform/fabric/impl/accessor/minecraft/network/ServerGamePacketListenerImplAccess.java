package net.kyori.adventure.platform.fabric.impl.accessor.minecraft.network;

import net.minecraft.class_3244;
import net.minecraft.class_7561;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_3244.class})
public interface ServerGamePacketListenerImplAccess {
  @Accessor("messageSignatureCache")
  @Final
  class_7561 accessor$messageSignatureCache();
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\accessor\minecraft\network\ServerGamePacketListenerImplAccess.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */