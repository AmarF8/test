package net.kyori.adventure.platform.fabric.impl.accessor.minecraft.world.level;

import net.minecraft.class_1937;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_1937.class})
public interface LevelAccess {
  @Accessor("threadSafeRandom")
  class_5819 accessor$threadSafeRandom();
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\accessor\minecraft\world\level\LevelAccess.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */