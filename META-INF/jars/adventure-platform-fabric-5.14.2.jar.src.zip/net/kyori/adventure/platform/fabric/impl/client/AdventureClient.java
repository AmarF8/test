/*    */ package net.kyori.adventure.platform.fabric.impl.client;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.fabricmc.api.ClientModInitializer;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.fabricmc.fabric.api.client.networking.v1.C2SPlayChannelEvents;
/*    */ import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
/*    */ import net.fabricmc.fabric.api.networking.v1.PacketSender;
/*    */ import net.fabricmc.loader.api.FabricLoader;
/*    */ import net.kyori.adventure.platform.fabric.impl.ClientboundArgumentTypeMappingsPacket;
/*    */ import net.kyori.adventure.platform.fabric.impl.ServerArgumentTypes;
/*    */ import net.kyori.adventure.platform.fabric.impl.ServerboundRegisteredArgumentTypesPacket;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_634;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ public final class AdventureClient
/*    */   implements ClientModInitializer
/*    */ {
/*    */   public void onInitializeClient() {
/* 38 */     setupCustomArgumentTypes();
/*    */   }
/*    */ 
/*    */   
/*    */   private void setupCustomArgumentTypes() {
/* 43 */     if (FabricLoader.getInstance().isModLoaded("fabric-networking-api-v1")) {
/* 44 */       C2SPlayChannelEvents.REGISTER.register((handler, sender, client, channels) -> {
/*    */             if (channels.contains(ServerboundRegisteredArgumentTypesPacket.TYPE.comp_2242())) {
/*    */               client.execute(());
/*    */             }
/*    */           });
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 53 */       ClientPlayNetworking.registerGlobalReceiver(ClientboundArgumentTypeMappingsPacket.TYPE, (pkt, ctx) -> ctx.client().execute(()));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\AdventureClient.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */