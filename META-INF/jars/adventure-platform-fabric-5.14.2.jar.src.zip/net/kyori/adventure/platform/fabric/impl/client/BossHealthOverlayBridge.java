/*    */ package net.kyori.adventure.platform.fabric.impl.client;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.minecraft.class_337;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ public interface BossHealthOverlayBridge
/*    */ {
/*    */   @NotNull
/*    */   ClientBossBarListener adventure$listener(@NotNull FabricClientAudiencesImpl paramFabricClientAudiencesImpl);
/*    */   
/*    */   @NotNull
/*    */   static ClientBossBarListener listener(@NotNull class_337 hud, @NotNull FabricClientAudiencesImpl controller) {
/* 38 */     return ((BossHealthOverlayBridge)Objects.requireNonNull(hud, "hud")).adventure$listener(controller);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\BossHealthOverlayBridge.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */