/*     */ package net.kyori.adventure.platform.fabric.impl.client;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.UUID;
/*     */ import net.fabricmc.api.EnvType;
/*     */ import net.fabricmc.api.Environment;
/*     */ import net.kyori.adventure.audience.Audience;
/*     */ import net.kyori.adventure.audience.MessageType;
/*     */ import net.kyori.adventure.bossbar.BossBar;
/*     */ import net.kyori.adventure.chat.ChatType;
/*     */ import net.kyori.adventure.chat.SignedMessage;
/*     */ import net.kyori.adventure.identity.Identity;
/*     */ import net.kyori.adventure.inventory.Book;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.platform.fabric.FabricAudiences;
/*     */ import net.kyori.adventure.platform.fabric.impl.AdventureCommon;
/*     */ import net.kyori.adventure.platform.fabric.impl.ControlledAudience;
/*     */ import net.kyori.adventure.platform.fabric.impl.FabricAudiencesInternal;
/*     */ import net.kyori.adventure.platform.fabric.impl.GameEnums;
/*     */ import net.kyori.adventure.platform.fabric.impl.PointerProviderBridge;
/*     */ import net.kyori.adventure.platform.fabric.impl.accessor.minecraft.world.level.LevelAccess;
/*     */ import net.kyori.adventure.platform.fabric.impl.client.mixin.minecraft.resources.sounds.AbstractSoundInstanceAccess;
/*     */ import net.kyori.adventure.pointer.Pointered;
/*     */ import net.kyori.adventure.pointer.Pointers;
/*     */ import net.kyori.adventure.resource.ResourcePackInfo;
/*     */ import net.kyori.adventure.resource.ResourcePackRequest;
/*     */ import net.kyori.adventure.resource.ResourcePackStatus;
/*     */ import net.kyori.adventure.sound.Sound;
/*     */ import net.kyori.adventure.sound.SoundStop;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.title.Title;
/*     */ import net.kyori.adventure.title.TitlePart;
/*     */ import net.minecraft.class_1106;
/*     */ import net.minecraft.class_1109;
/*     */ import net.minecraft.class_1113;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1659;
/*     */ import net.minecraft.class_2556;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_3417;
/*     */ import net.minecraft.class_3419;
/*     */ import net.minecraft.class_3872;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_5819;
/*     */ import net.minecraft.class_746;
/*     */ import net.minecraft.class_7469;
/*     */ import net.minecraft.class_7591;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Environment(EnvType.CLIENT)
/*     */ public class ClientAudience
/*     */   implements ControlledAudience
/*     */ {
/*     */   private final class_310 client;
/*     */   private final FabricClientAudiencesImpl controller;
/*     */   
/*     */   public ClientAudience(class_310 client, FabricClientAudiencesImpl renderer) {
/*  77 */     this.client = client;
/*  78 */     this.controller = renderer;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public FabricAudiencesInternal controller() {
/*  83 */     return this.controller;
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendMessage(@NotNull Component message) {
/*  88 */     this.client.field_1705.method_1743().method_1812(this.controller.toNative(message));
/*     */   }
/*     */   
/*     */   private class_2556.class_7602 toMc(ChatType.Bound bound) {
/*  92 */     return AdventureCommon.chatTypeToNative(bound, this.controller);
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendMessage(@NotNull Component message, ChatType.Bound boundChatType) {
/*  97 */     class_2556.class_7602 bound = toMc(boundChatType);
/*  98 */     this.client.field_1705.method_1743().method_44811(bound.method_44837(this.controller.toNative(message)), null, class_7591.method_44709());
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendMessage(@NotNull SignedMessage signedMessage, ChatType.Bound boundChatType) {
/* 103 */     class_2556.class_7602 bound = toMc(boundChatType);
/* 104 */     Component message = (Component)Objects.requireNonNullElse(signedMessage.unsignedContent(), Component.text(signedMessage.message()));
/*     */     
/* 106 */     this.client.field_1705.method_1743().method_44811(bound.method_44837(this.controller.toNative(message)), (class_7469)signedMessage.signature(), tag(signedMessage));
/*     */   }
/*     */   
/*     */   private class_7591 tag(SignedMessage message) {
/* 110 */     if (message == null)
/* 111 */       return null; 
/* 112 */     if (message.method_46293())
/* 113 */       return class_7591.method_44751(); 
/* 114 */     if (message.unsignedContent() != null && !message.unsignedContent().equals(Component.text(message.message())))
/* 115 */       return class_7591.method_44710(message.message()); 
/* 116 */     if (message.signature() == null) {
/* 117 */       return class_7591.method_44709();
/*     */     }
/*     */     
/* 120 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteMessage(SignedMessage.Signature signature) {
/* 125 */     this.client.field_1705.method_1743().method_44812((class_7469)signature);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void sendMessage(Identity source, @NotNull Component message, @NotNull MessageType type) {
/* 131 */     if (this.client.method_29042(source.uuid()))
/*     */       return; 
/* 133 */     class_1659 visibility = (class_1659)this.client.field_1690.method_42539().method_41753();
/* 134 */     if (type == MessageType.CHAT) {
/*     */       
/* 136 */       if (visibility == class_1659.field_7538) {
/* 137 */         this.client.field_1705.method_1743().method_44811(this.controller.toNative(message), null, null);
/*     */       
/*     */       }
/*     */     }
/* 141 */     else if (visibility == class_1659.field_7538 || visibility == class_1659.field_7539) {
/* 142 */       this.client.field_1705.method_1743().method_1812(this.controller.toNative(message));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendActionBar(@NotNull Component message) {
/* 149 */     this.client.field_1705.method_1758(this.controller.toNative(message), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void showTitle(@NotNull Title title) {
/* 154 */     class_2561 titleText = (title.title() == Component.empty()) ? null : this.controller.toNative(title.title());
/* 155 */     class_2561 subtitleText = (title.subtitle() == Component.empty()) ? null : this.controller.toNative(title.subtitle());
/* 156 */     Title.Times times = title.times();
/* 157 */     this.client.field_1705.method_34004(titleText);
/* 158 */     this.client.field_1705.method_34002(subtitleText);
/* 159 */     this.client.field_1705.method_34001(
/* 160 */         adventure$ticks((times == null) ? null : times.fadeIn()), 
/* 161 */         adventure$ticks((times == null) ? null : times.stay()), 
/* 162 */         adventure$ticks((times == null) ? null : times.fadeOut()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void sendTitlePart(@NotNull TitlePart<T> part, @NotNull T value) {
/* 168 */     Objects.requireNonNull(value, "value");
/* 169 */     if (part == TitlePart.TITLE) {
/* 170 */       this.client.field_1705.method_34004(this.controller.toNative((Component)value));
/* 171 */     } else if (part == TitlePart.SUBTITLE) {
/* 172 */       this.client.field_1705.method_34002(this.controller.toNative((Component)value));
/* 173 */     } else if (part == TitlePart.TIMES) {
/* 174 */       Title.Times times = (Title.Times)value;
/* 175 */       this.client.field_1705.method_34001(
/* 176 */           adventure$ticks(times.fadeIn()), 
/* 177 */           adventure$ticks(times.stay()), 
/* 178 */           adventure$ticks(times.fadeOut()));
/*     */     } else {
/*     */       
/* 181 */       throw new IllegalArgumentException("Unknown TitlePart '" + String.valueOf(part) + "'");
/*     */     } 
/*     */   }
/*     */   
/*     */   private int adventure$ticks(@Nullable Duration duration) {
/* 186 */     return (duration == null || duration.getSeconds() == -1L) ? -1 : (int)(duration.toMillis() / 50L);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearTitle() {
/* 191 */     this.client.field_1705.method_34004(null);
/* 192 */     this.client.field_1705.method_34002(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetTitle() {
/* 197 */     this.client.field_1705.method_1742();
/* 198 */     clearTitle();
/*     */   }
/*     */ 
/*     */   
/*     */   public void showBossBar(@NotNull BossBar bar) {
/* 203 */     BossHealthOverlayBridge.listener(this.client.field_1705.method_1740(), this.controller).add(bar);
/*     */   }
/*     */ 
/*     */   
/*     */   public void hideBossBar(@NotNull BossBar bar) {
/* 208 */     BossHealthOverlayBridge.listener(this.client.field_1705.method_1740(), this.controller).remove(bar);
/*     */   }
/*     */   
/*     */   private long seed(@NotNull Sound sound) {
/* 212 */     if (sound.seed().isPresent()) {
/* 213 */       return sound.seed().getAsLong();
/*     */     }
/* 215 */     class_746 player = this.client.field_1724;
/* 216 */     if (player != null) {
/* 217 */       return ((LevelAccess)player).accessor$threadSafeRandom().method_43055();
/*     */     }
/* 219 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void playSound(@NotNull Sound sound) {
/* 226 */     class_746 player = this.client.field_1724;
/* 227 */     if (player != null) {
/* 228 */       playSound(sound, player.method_23317(), player.method_23318(), player.method_23321());
/*     */     } else {
/*     */       
/* 231 */       this.client.method_1483().method_4873((class_1113)new class_1109(FabricAudiences.toNative(sound.name()), (class_3419)GameEnums.SOUND_SOURCE.toMinecraft(sound.source()), sound
/* 232 */             .volume(), sound.pitch(), class_5819.method_43049(seed(sound)), false, 0, class_1113.class_1114.field_5478, 0.0D, 0.0D, 0.0D, true));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void playSound(@NotNull Sound sound, Sound.Emitter emitter) {
/*     */     class_1297 targetEntity;
/* 239 */     if (emitter == Sound.Emitter.self())
/* 240 */     { class_746 class_746 = this.client.field_1724; }
/* 241 */     else if (emitter instanceof class_1297) { class_1297 entity = (class_1297)emitter;
/* 242 */       targetEntity = entity; }
/*     */     else
/* 244 */     { throw new IllegalArgumentException("Provided emitter '" + String.valueOf(emitter) + "' was not Sound.Emitter.self() or an Entity"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 254 */     class_1106 mcSound = new class_1106(class_3417.field_15197, (class_3419)GameEnums.SOUND_SOURCE.toMinecraft(sound.source()), sound.volume(), sound.pitch(), targetEntity, seed(sound));
/*     */ 
/*     */     
/* 257 */     ((AbstractSoundInstanceAccess)mcSound).setLocation(FabricAudiences.toNative(sound.name()));
/*     */     
/* 259 */     this.client.method_1483().method_4873((class_1113)mcSound);
/*     */   }
/*     */ 
/*     */   
/*     */   public void playSound(@NotNull Sound sound, double x, double y, double z) {
/* 264 */     this.client.method_1483().method_4873((class_1113)new class_1109(
/* 265 */           FabricAudiences.toNative(sound.name()), (class_3419)GameEnums.SOUND_SOURCE
/* 266 */           .toMinecraft(sound.source()), sound
/* 267 */           .volume(), sound
/* 268 */           .pitch(), 
/* 269 */           class_5819.method_43049(seed(sound)), false, 0, class_1113.class_1114.field_5476, x, y, z, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopSound(@NotNull SoundStop stop) {
/* 282 */     Key sound = stop.sound();
/* 283 */     class_2960 soundIdent = (sound == null) ? null : FabricAudiences.toNative(sound);
/* 284 */     Sound.Source source = stop.source();
/* 285 */     class_3419 category = (source == null) ? null : (class_3419)GameEnums.SOUND_SOURCE.toMinecraft(source);
/* 286 */     this.client.method_1483().method_4875(soundIdent, category);
/*     */   }
/*     */ 
/*     */   
/*     */   public void openBook(@NotNull Book book) {
/* 291 */     Objects.requireNonNull(this.controller); this.client.method_1507((class_437)new class_3872(new class_3872.class_3931(book.pages().stream().map(this.controller::toNative).toList())));
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendPlayerListHeader(@NotNull Component header) {
/* 296 */     this.client.field_1705.method_1750().method_1925((header == Component.empty()) ? null : this.controller.toNative(header));
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendPlayerListFooter(@NotNull Component footer) {
/* 301 */     this.client.field_1705.method_1750().method_1925((footer == Component.empty()) ? null : this.controller.toNative(footer));
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendPlayerListHeaderAndFooter(@NotNull Component header, @NotNull Component footer) {
/* 306 */     sendPlayerListHeader(header);
/* 307 */     sendPlayerListFooter(footer);
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendResourcePacks(@NotNull ResourcePackRequest request) {
/* 312 */     if (request.replace()) {
/* 313 */       this.client.method_1516().method_55537();
/*     */     }
/*     */     
/* 316 */     for (ResourcePackInfo info : request.packs()) {
/* 317 */       ListeningPackFeedbackWrapper.registerCallback(info.id(), request.callback(), this);
/*     */       
/*     */       try {
/* 320 */         this.client.method_1516().method_55523(info.id(), info.uri().toURL(), info.hash());
/* 321 */       } catch (MalformedURLException ex) {
/* 322 */         request.callback().packEventReceived(info.id(), ResourcePackStatus.INVALID_URL, (Audience)this);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeResourcePacks(@NotNull UUID id, @NotNull UUID... others) {
/* 330 */     this.client.method_1516().method_55520(id);
/* 331 */     for (UUID other : others) {
/* 332 */       this.client.method_1516().method_55520(other);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearResourcePacks() {
/* 338 */     this.client.method_1516().method_55537();
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Pointers pointers() {
/* 343 */     class_746 clientPlayer = this.client.field_1724;
/* 344 */     if (clientPlayer != null) {
/* 345 */       return ((PointerProviderBridge)clientPlayer).adventure$pointers();
/*     */     }
/* 347 */     return ((Pointered)this.client).pointers();
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\ClientAudience.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */