/*    */ package net.kyori.adventure.platform.fabric.impl.client;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.kyori.adventure.bossbar.BossBar;
/*    */ import net.kyori.adventure.platform.fabric.FabricAudiences;
/*    */ import net.kyori.adventure.platform.fabric.impl.AbstractBossBarListener;
/*    */ import net.minecraft.class_1259;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_345;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ public class ClientBossBarListener
/*    */   extends AbstractBossBarListener<class_345>
/*    */ {
/*    */   private final Map<UUID, class_345> hudBars;
/*    */   
/*    */   public ClientBossBarListener(FabricClientAudiencesImpl controller, Map<UUID, class_345> hudBars) {
/* 39 */     super((FabricAudiences)controller);
/* 40 */     this.hudBars = hudBars;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected class_345 newBar(@NotNull class_2561 title, class_1259.class_1260 color, class_1259.class_1261 style, float progress) {
/* 48 */     return new class_345(UUID.randomUUID(), title, progress, color, style, false, false, false);
/*    */   }
/*    */   
/*    */   public void add(BossBar bar) {
/* 52 */     class_345 mc = (class_345)minecraftCreating(bar);
/* 53 */     this.hudBars.put(mc.method_5407(), mc);
/*    */   }
/*    */   
/*    */   public void remove(BossBar bar) {
/* 57 */     class_345 mc = (class_345)this.bars.remove(bar);
/* 58 */     if (mc != null) {
/* 59 */       bar.removeListener((BossBar.Listener)this);
/* 60 */       this.hudBars.remove(mc.method_5407());
/*    */     } 
/*    */   }
/*    */   
/*    */   public void clear() {
/* 65 */     for (Map.Entry<BossBar, class_345> entry : (Iterable<Map.Entry<BossBar, class_345>>)this.bars.entrySet()) {
/* 66 */       ((BossBar)entry.getKey()).removeListener((BossBar.Listener)this);
/* 67 */       this.hudBars.remove(((class_345)entry.getValue()).method_5407());
/*    */     } 
/* 69 */     this.bars.clear();
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\ClientBossBarListener.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */