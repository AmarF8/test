/*    */ package net.kyori.adventure.platform.fabric.impl.client;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.kyori.adventure.platform.fabric.impl.NonWrappingComponentSerializer;
/*    */ import net.kyori.adventure.platform.fabric.impl.SidedProxy;
/*    */ import net.kyori.adventure.platform.fabric.impl.WrappedComponent;
/*    */ import net.kyori.adventure.pointer.Pointered;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.kyori.adventure.text.KeybindComponent;
/*    */ import net.kyori.adventure.text.flattener.ComponentFlattener;
/*    */ import net.kyori.adventure.text.renderer.ComponentRenderer;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_304;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ public class ClientProxy
/*    */   implements SidedProxy
/*    */ {
/*    */   public void contributeFlattenerElements(ComponentFlattener.Builder flattenerBuilder) {
/* 44 */     flattenerBuilder.mapper(KeybindComponent.class, keybind -> ((class_2561)class_304.method_1419(keybind.keybind()).get()).getString());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public WrappedComponent createWrappedComponent(@NotNull Component wrapped, @Nullable Function<Pointered, ?> partition, @Nullable ComponentRenderer<Pointered> renderer, @Nullable NonWrappingComponentSerializer nonWrappingSerializer) {
/* 54 */     return new ClientWrappedComponent(wrapped, partition, renderer);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\ClientProxy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */