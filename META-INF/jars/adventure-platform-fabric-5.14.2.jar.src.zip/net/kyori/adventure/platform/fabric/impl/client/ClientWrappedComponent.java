/*    */ package net.kyori.adventure.platform.fabric.impl.client;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.kyori.adventure.audience.Audience;
/*    */ import net.kyori.adventure.platform.fabric.FabricClientAudiences;
/*    */ import net.kyori.adventure.platform.fabric.impl.WrappedComponent;
/*    */ import net.kyori.adventure.pointer.Pointered;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.kyori.adventure.text.renderer.ComponentRenderer;
/*    */ import net.minecraft.class_2561;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ public final class ClientWrappedComponent
/*    */   extends WrappedComponent
/*    */ {
/*    */   public ClientWrappedComponent(Component wrapped, @Nullable Function<Pointered, ?> partition, @Nullable ComponentRenderer<Pointered> renderer) {
/* 36 */     super(wrapped, partition, renderer, null);
/*    */   }
/*    */ 
/*    */   
/*    */   protected class_2561 deepConvertedLocalized() {
/* 41 */     class_2561 converted = this.converted;
/* 42 */     Audience audience = FabricClientAudiences.of().audience();
/* 43 */     Object data = (partition() == null) ? null : partition().apply(audience);
/* 44 */     if (converted == null || this.deepConvertedLocalized != data) {
/* 45 */       converted = this.converted = rendered((Pointered)audience).deepConverted();
/* 46 */       this.deepConvertedLocalized = data;
/*    */     } 
/* 48 */     return converted;
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\ClientWrappedComponent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */