/*     */ package net.kyori.adventure.platform.fabric.impl.client;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import net.fabricmc.api.EnvType;
/*     */ import net.fabricmc.api.Environment;
/*     */ import net.kyori.adventure.platform.fabric.FabricClientAudiences;
/*     */ import net.kyori.adventure.platform.fabric.impl.AdventureCommon;
/*     */ import net.kyori.adventure.pointer.Pointered;
/*     */ import net.kyori.adventure.text.renderer.ComponentRenderer;
/*     */ import net.kyori.adventure.translation.GlobalTranslator;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Environment(EnvType.CLIENT)
/*     */ public final class Builder
/*     */   implements FabricClientAudiences.Builder
/*     */ {
/*     */   private Function<Pointered, ?> partition;
/*     */   private ComponentRenderer<Pointered> renderer;
/*     */   
/*     */   public Builder() {
/*  92 */     componentRenderer(AdventureCommon.localePartition(), (ComponentRenderer)GlobalTranslator.renderer());
/*     */   }
/*     */ 
/*     */   
/*     */   public FabricClientAudiences.Builder componentRenderer(@NotNull ComponentRenderer<Pointered> componentRenderer) {
/*  97 */     this.renderer = Objects.<ComponentRenderer<Pointered>>requireNonNull(componentRenderer, "componentRenderer");
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FabricClientAudiences.Builder partition(@NotNull Function<Pointered, ?> partitionFunction) {
/* 103 */     this.partition = Objects.<Function<Pointered, ?>>requireNonNull(partitionFunction, "partitionFunction");
/* 104 */     return this;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public FabricClientAudiences build() {
/* 109 */     return new FabricClientAudiencesImpl(this.partition, this.renderer);
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\FabricClientAudiencesImpl$Builder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */