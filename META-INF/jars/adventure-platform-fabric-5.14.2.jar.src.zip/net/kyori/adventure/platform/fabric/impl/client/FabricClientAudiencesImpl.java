/*     */ package net.kyori.adventure.platform.fabric.impl.client;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import net.fabricmc.api.EnvType;
/*     */ import net.fabricmc.api.Environment;
/*     */ import net.kyori.adventure.audience.Audience;
/*     */ import net.kyori.adventure.platform.fabric.FabricClientAudiences;
/*     */ import net.kyori.adventure.platform.fabric.impl.AdventureCommon;
/*     */ import net.kyori.adventure.platform.fabric.impl.FabricAudiencesInternal;
/*     */ import net.kyori.adventure.pointer.Pointered;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.flattener.ComponentFlattener;
/*     */ import net.kyori.adventure.text.renderer.ComponentRenderer;
/*     */ import net.kyori.adventure.translation.GlobalTranslator;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_5455;
/*     */ import net.minecraft.class_638;
/*     */ import net.minecraft.class_7659;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Environment(EnvType.CLIENT)
/*     */ public class FabricClientAudiencesImpl
/*     */   implements FabricClientAudiences, FabricAudiencesInternal
/*     */ {
/*  46 */   public static final FabricClientAudiences INSTANCE = (new Builder()).build();
/*     */   private final Function<Pointered, ?> partition;
/*     */   private final ComponentRenderer<Pointered> renderer;
/*     */   private final ClientAudience audience;
/*     */   
/*     */   public FabricClientAudiencesImpl(Function<Pointered, ?> partition, ComponentRenderer<Pointered> renderer) {
/*  52 */     this.partition = partition;
/*  53 */     this.renderer = renderer;
/*  54 */     this.audience = new ClientAudience(class_310.method_1551(), this);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Audience audience() {
/*  59 */     return (Audience)this.audience;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public ComponentFlattener flattener() {
/*  64 */     return AdventureCommon.FLATTENER;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public ComponentRenderer<Pointered> renderer() {
/*  69 */     return this.renderer;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public class_2561 toNative(Component adventure) {
/*  74 */     return (class_2561)new ClientWrappedComponent(Objects.<Component>requireNonNull(adventure, "adventure"), this.partition, this.renderer);
/*     */   }
/*     */   
/*     */   public Function<Pointered, ?> partition() {
/*  78 */     return this.partition;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public class_5455 registryAccess() {
/*  83 */     class_638 level = (class_310.method_1551()).field_1687;
/*  84 */     return (level == null) ? (class_5455)class_7659.method_45139().method_45926() : level.method_30349();
/*     */   }
/*     */   
/*     */   @Environment(EnvType.CLIENT)
/*     */   public static final class Builder implements FabricClientAudiences.Builder {
/*     */     private Function<Pointered, ?> partition;
/*     */     
/*     */     public Builder() {
/*  92 */       componentRenderer(AdventureCommon.localePartition(), (ComponentRenderer)GlobalTranslator.renderer());
/*     */     }
/*     */     private ComponentRenderer<Pointered> renderer;
/*     */     
/*     */     public FabricClientAudiences.Builder componentRenderer(@NotNull ComponentRenderer<Pointered> componentRenderer) {
/*  97 */       this.renderer = Objects.<ComponentRenderer<Pointered>>requireNonNull(componentRenderer, "componentRenderer");
/*  98 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public FabricClientAudiences.Builder partition(@NotNull Function<Pointered, ?> partitionFunction) {
/* 103 */       this.partition = Objects.<Function<Pointered, ?>>requireNonNull(partitionFunction, "partitionFunction");
/* 104 */       return this;
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public FabricClientAudiences build() {
/* 109 */       return new FabricClientAudiencesImpl(this.partition, this.renderer);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\FabricClientAudiencesImpl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */