/*    */ package net.kyori.adventure.platform.fabric.impl.client;
/*    */ 
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.kyori.adventure.resource.ResourcePackCallback;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ final class PackCallback
/*    */   extends Record
/*    */ {
/*    */   @NotNull
/*    */   private final ResourcePackCallback cb;
/*    */   @NotNull
/*    */   private final ClientAudience listener;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lnet/kyori/adventure/platform/fabric/impl/client/ListeningPackFeedbackWrapper$PackCallback;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #41	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/client/ListeningPackFeedbackWrapper$PackCallback;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lnet/kyori/adventure/platform/fabric/impl/client/ListeningPackFeedbackWrapper$PackCallback;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #41	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/client/ListeningPackFeedbackWrapper$PackCallback;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lnet/kyori/adventure/platform/fabric/impl/client/ListeningPackFeedbackWrapper$PackCallback;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #41	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/client/ListeningPackFeedbackWrapper$PackCallback;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   PackCallback(@NotNull ResourcePackCallback cb, @NotNull ClientAudience listener) {
/* 41 */     this.cb = cb; this.listener = listener; } @NotNull public ResourcePackCallback cb() { return this.cb; } @NotNull public ClientAudience listener() { return this.listener; }
/*    */ 
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\ListeningPackFeedbackWrapper$PackCallback.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */