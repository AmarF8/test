/*    */ package net.kyori.adventure.platform.fabric.impl.client;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.kyori.adventure.audience.Audience;
/*    */ import net.kyori.adventure.resource.ResourcePackCallback;
/*    */ import net.kyori.adventure.resource.ResourcePackStatus;
/*    */ import net.kyori.adventure.text.logger.slf4j.ComponentLogger;
/*    */ import net.minecraft.class_9039;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ public final class ListeningPackFeedbackWrapper
/*    */   implements class_9039
/*    */ {
/* 36 */   private static final ComponentLogger LOGGER = ComponentLogger.logger();
/* 37 */   private static final Map<UUID, PackCallback> CALLBACKS = new ConcurrentHashMap<>(); private final class_9039 delegate; @Environment(EnvType.CLIENT)
/*    */   static final class PackCallback extends Record { @NotNull
/*    */     private final ResourcePackCallback cb; @NotNull
/*    */     private final ClientAudience listener;
/* 41 */     PackCallback(@NotNull ResourcePackCallback cb, @NotNull ClientAudience listener) { this.cb = cb; this.listener = listener; } public final String toString() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Lnet/kyori/adventure/platform/fabric/impl/client/ListeningPackFeedbackWrapper$PackCallback;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #41	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/* 41 */       //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/client/ListeningPackFeedbackWrapper$PackCallback; } @NotNull public ResourcePackCallback cb() { return this.cb; } public final int hashCode() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Lnet/kyori/adventure/platform/fabric/impl/client/ListeningPackFeedbackWrapper$PackCallback;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #41	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/* 41 */       //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/client/ListeningPackFeedbackWrapper$PackCallback; } @NotNull public ClientAudience listener() { return this.listener; } public final boolean equals(Object o) {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Lnet/kyori/adventure/platform/fabric/impl/client/ListeningPackFeedbackWrapper$PackCallback;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #41	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/client/ListeningPackFeedbackWrapper$PackCallback;
/*    */       //   0	8	1	o	Ljava/lang/Object;
/*    */     } } public static void registerCallback(UUID pack, ResourcePackCallback cb, ClientAudience audience) {
/* 44 */     if (CALLBACKS.put(pack, new PackCallback(cb, audience)) != null) {
/* 45 */       LOGGER.warn("Duplicate client resource pack callbacks registered for pack {}", pack);
/*    */     }
/*    */   }
/*    */   
/*    */   public ListeningPackFeedbackWrapper(class_9039 delegate) {
/* 50 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   
/*    */   public void method_55620(UUID packId, class_9039.class_9060 status) {
/* 55 */     PackCallback cb = CALLBACKS.get(packId);
/* 56 */     if (cb != null) {
/* 57 */       switch (status) { default: throw new MatchException(null, null);
/*    */         case field_47623: 
/* 59 */         case field_47624: break; }  ResourcePackStatus advStatus = ResourcePackStatus.DOWNLOADED;
/*    */       
/* 61 */       cb.cb().packEventReceived(packId, advStatus, (Audience)cb.listener());
/*    */       return;
/*    */     } 
/* 64 */     this.delegate.method_55620(packId, status);
/*    */   }
/*    */ 
/*    */   
/*    */   public void method_55619(UUID packId, class_9039.class_9040 status) {
/* 69 */     PackCallback cb = CALLBACKS.remove(packId);
/* 70 */     if (cb != null) {
/* 71 */       switch (status) { default: throw new MatchException(null, null);
/*    */         case field_47623: 
/*    */         case field_47624: 
/*    */         case field_47625: 
/*    */         case field_47626: 
/* 76 */         case field_47627: break; }  ResourcePackStatus advStatus = ResourcePackStatus.FAILED_RELOAD;
/*    */ 
/*    */       
/* 79 */       cb.cb().packEventReceived(packId, advStatus, (Audience)cb.listener());
/*    */       return;
/*    */     } 
/* 82 */     this.delegate.method_55619(packId, status);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\ListeningPackFeedbackWrapper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */