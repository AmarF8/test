/*    */ package net.kyori.adventure.platform.fabric.impl.client.mixin.minecraft;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import java.util.Locale;
/*    */ import java.util.UUID;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.kyori.adventure.identity.Identity;
/*    */ import net.kyori.adventure.platform.fabric.CollectPointersCallback;
/*    */ import net.kyori.adventure.platform.fabric.impl.LocaleHolderBridge;
/*    */ import net.kyori.adventure.pointer.Pointered;
/*    */ import net.kyori.adventure.pointer.Pointers;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_315;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ @Mixin({class_310.class})
/*    */ public abstract class MinecraftMixin
/*    */   implements Pointered
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   public class_315 field_1690;
/*    */   @Unique
/* 49 */   private final Pointers pointers = makePointers();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Unique
/*    */   private Pointers makePointers() {
/* 56 */     Pointers.Builder builder = Pointers.builder().withDynamic(Identity.LOCALE, () -> ((LocaleHolderBridge)this.field_1690).adventure$locale()).withDynamic(Identity.NAME, () -> method_53462().getName()).withDynamic(Identity.UUID, () -> method_53462().getId());
/*    */     
/* 58 */     ((CollectPointersCallback)CollectPointersCallback.EVENT.invoker()).registerPointers(this, builder);
/*    */     
/* 60 */     return (Pointers)builder.build();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Pointers pointers() {
/* 65 */     return this.pointers;
/*    */   }
/*    */   
/*    */   @Shadow
/*    */   public abstract GameProfile method_53462();
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\mixin\minecraft\MinecraftMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */