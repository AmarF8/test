/*    */ package net.kyori.adventure.platform.fabric.impl.client.mixin.minecraft;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.Objects;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.kyori.adventure.platform.fabric.impl.LocaleHolderBridge;
/*    */ import net.minecraft.class_315;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ @Mixin({class_315.class})
/*    */ public class OptionsMixin
/*    */   implements LocaleHolderBridge
/*    */ {
/*    */   @Shadow
/*    */   public String field_1883;
/*    */   private String adventure$cachedLanguage;
/*    */   private Locale adventure$cachedLocale;
/*    */   
/*    */   public Locale adventure$locale() {
/* 44 */     String language = this.field_1883;
/* 45 */     if (Objects.equals(this.adventure$cachedLanguage, language)) {
/* 46 */       return this.adventure$cachedLocale;
/*    */     }
/* 48 */     this.adventure$cachedLanguage = language;
/* 49 */     return this.adventure$cachedLocale = LocaleHolderBridge.toLocale(language);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\mixin\minecraft\OptionsMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */