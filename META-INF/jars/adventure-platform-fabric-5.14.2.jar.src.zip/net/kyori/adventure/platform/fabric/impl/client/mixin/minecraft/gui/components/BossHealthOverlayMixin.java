/*    */ package net.kyori.adventure.platform.fabric.impl.client.mixin.minecraft.gui.components;
/*    */ 
/*    */ import com.google.common.collect.MapMaker;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.kyori.adventure.platform.fabric.impl.client.BossHealthOverlayBridge;
/*    */ import net.kyori.adventure.platform.fabric.impl.client.ClientBossBarListener;
/*    */ import net.kyori.adventure.platform.fabric.impl.client.FabricClientAudiencesImpl;
/*    */ import net.minecraft.class_337;
/*    */ import net.minecraft.class_345;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ @Mixin({class_337.class})
/*    */ public class BossHealthOverlayMixin
/*    */   implements BossHealthOverlayBridge
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   Map<UUID, class_345> field_2060;
/* 48 */   private final Map<FabricClientAudiencesImpl, ClientBossBarListener> adventure$listener = (new MapMaker()).weakKeys().makeMap();
/*    */   
/*    */   @NotNull
/*    */   public ClientBossBarListener adventure$listener(@NotNull FabricClientAudiencesImpl controller) {
/* 52 */     return this.adventure$listener.computeIfAbsent(controller, ctrl -> new ClientBossBarListener(ctrl, this.field_2060));
/*    */   }
/*    */   
/*    */   @Inject(method = {"reset"}, at = {@At("HEAD")})
/*    */   private void adventure$resetListener(CallbackInfo ci) {
/* 57 */     if (this.adventure$listener != null)
/* 58 */       this.adventure$listener.clear(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\mixin\minecraft\gui\components\BossHealthOverlayMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */