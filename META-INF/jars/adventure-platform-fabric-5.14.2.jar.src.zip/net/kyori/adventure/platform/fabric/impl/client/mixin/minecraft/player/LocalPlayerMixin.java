/*    */ package net.kyori.adventure.platform.fabric.impl.client.mixin.minecraft.player;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import java.util.Locale;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.kyori.adventure.audience.Audience;
/*    */ import net.kyori.adventure.audience.ForwardingAudience;
/*    */ import net.kyori.adventure.platform.fabric.FabricClientAudiences;
/*    */ import net.kyori.adventure.platform.fabric.impl.ControlledAudience;
/*    */ import net.kyori.adventure.platform.fabric.impl.FabricAudiencesInternal;
/*    */ import net.kyori.adventure.platform.fabric.impl.LocaleHolderBridge;
/*    */ import net.kyori.adventure.pointer.Pointers;
/*    */ import net.kyori.adventure.sound.Sound;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_746;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ @Mixin({class_746.class})
/*    */ public abstract class LocalPlayerMixin
/*    */   extends class_1657
/*    */   implements ForwardingAudience.Single, ControlledAudience, LocaleHolderBridge
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   protected class_310 field_3937;
/* 54 */   private final Audience adventure$default = FabricClientAudiences.of().audience();
/*    */   
/*    */   private LocalPlayerMixin(class_1937 level, class_2338 blockPos, float f, GameProfile gameProfile) {
/* 57 */     super(level, blockPos, f, gameProfile);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Audience audience() {
/* 62 */     return this.adventure$default;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Pointers pointers() {
/* 67 */     return audience().pointers();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public FabricAudiencesInternal controller() {
/* 72 */     return (FabricAudiencesInternal)FabricClientAudiences.of();
/*    */   }
/*    */ 
/*    */   
/*    */   public void playSound(@NotNull Sound sound) {
/* 77 */     audience().playSound(sound, method_23317(), method_23318(), method_23321());
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Locale adventure$locale() {
/* 82 */     return ((LocaleHolderBridge)this.field_3937.field_1690).adventure$locale();
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\mixin\minecraft\player\LocalPlayerMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */