/*    */ package net.kyori.adventure.platform.fabric.impl.client.mixin.minecraft.resources.server;
/*    */ 
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.kyori.adventure.platform.fabric.impl.client.ListeningPackFeedbackWrapper;
/*    */ import net.minecraft.class_1066;
/*    */ import net.minecraft.class_2535;
/*    */ import net.minecraft.class_9039;
/*    */ import net.minecraft.class_9044;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ @Mixin({class_1066.class})
/*    */ public class DownloadedPackSourceMixin
/*    */ {
/*    */   @Shadow
/*    */   class_9039 field_47601;
/*    */   
/*    */   @Inject(method = {"configureForServerControl"}, at = {@At(value = "FIELD", opcode = 181, target = "Lnet/minecraft/client/resources/server/DownloadedPackSource;packFeedback:Lnet/minecraft/client/resources/server/PackLoadFeedback;", shift = At.Shift.AFTER)})
/*    */   private void adventure$addPackListener(class_2535 conn, class_9044.class_9047 status, CallbackInfo ci) {
/* 46 */     this.field_47601 = (class_9039)new ListeningPackFeedbackWrapper(this.field_47601);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\mixin\minecraft\resources\server\DownloadedPackSourceMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */