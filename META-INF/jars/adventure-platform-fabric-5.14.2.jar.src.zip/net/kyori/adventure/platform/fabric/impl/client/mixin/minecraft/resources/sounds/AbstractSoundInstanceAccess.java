package net.kyori.adventure.platform.fabric.impl.client.mixin.minecraft.resources.sounds;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1102;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({class_1102.class})
public interface AbstractSoundInstanceAccess {
  @Accessor
  void setLocation(class_2960 paramclass_2960);
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\client\mixin\minecraft\resources\sounds\AbstractSoundInstanceAccess.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */