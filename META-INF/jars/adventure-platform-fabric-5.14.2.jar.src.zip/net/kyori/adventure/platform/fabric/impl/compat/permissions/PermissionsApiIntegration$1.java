/*    */ package net.kyori.adventure.platform.fabric.impl.compat.permissions;
/*    */ 
/*    */ import net.fabricmc.fabric.api.util.TriState;
/*    */ 


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\compat\permissions\PermissionsApiIntegration$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */