/*    */ package net.kyori.adventure.platform.fabric.impl.compat.permissions;
/*    */ 
/*    */ import me.lucko.fabric.api.permissions.v0.Permissions;
/*    */ import net.fabricmc.api.ModInitializer;
/*    */ import net.fabricmc.fabric.api.util.TriState;
/*    */ import net.fabricmc.loader.api.FabricLoader;
/*    */ import net.kyori.adventure.permission.PermissionChecker;
/*    */ import net.kyori.adventure.platform.fabric.CollectPointersCallback;
/*    */ import net.kyori.adventure.pointer.Pointered;
/*    */ import net.kyori.adventure.pointer.Pointers;
/*    */ import net.kyori.adventure.text.logger.slf4j.ComponentLogger;
/*    */ import net.kyori.adventure.util.TriState;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_2172;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PermissionsApiIntegration
/*    */   implements ModInitializer
/*    */ {
/* 37 */   private static final ComponentLogger LOGGER = ComponentLogger.logger();
/*    */   
/*    */   private static final String PERMISSIONS_API_MOD_NAME = "fabric-permissions-api-v0";
/*    */   
/*    */   public void onInitialize() {
/* 42 */     if (FabricLoader.getInstance().isModLoaded("fabric-permissions-api-v0")) {
/* 43 */       registerPermissionHook();
/* 44 */       LOGGER.debug("Registered fabric-permissions-api hook");
/*    */     } else {
/* 46 */       LOGGER.debug("fabric-permissions-api not detected, the PermissionChecker pointer will not be present");
/*    */     } 
/*    */   }
/*    */   
/*    */   private void registerPermissionHook() {
/* 51 */     CollectPointersCallback.EVENT.register((pointered, consumer) -> {
/*    */           if (pointered instanceof class_1297) {
/*    */             class_1297 e = (class_1297)pointered;
/*    */             consumer.withStatic(PermissionChecker.POINTER, ());
/*    */           } else if (pointered instanceof class_2172) {
/*    */             class_2172 sourceStack = (class_2172)pointered;
/*    */             consumer.withStatic(PermissionChecker.POINTER, ());
/*    */           } 
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static TriState adaptTristate(TriState fabricState) {
/* 67 */     switch (fabricState) { default: throw new MatchException(null, null);case FALSE: case DEFAULT: case TRUE: break; }  return 
/*    */ 
/*    */       
/* 70 */       TriState.TRUE;
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\compat\permissions\PermissionsApiIntegration.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */