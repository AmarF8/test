/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.api;
/*    */ 
/*    */ import net.kyori.adventure.key.Key;
/*    */ import net.kyori.adventure.platform.fabric.impl.accessor.api.key.InvalidKeyExceptionAccess;
/*    */ import net.minecraft.class_151;
/*    */ import net.minecraft.class_2960;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Overwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin(value = {Key.class}, remap = false)
/*    */ public interface KeyMixin
/*    */ {
/*    */   @Overwrite
/*    */   @NotNull
/*    */   static Key key(String namespace, String value) {
/*    */     try {
/* 50 */       return (Key)class_2960.method_60655(namespace, value);
/* 51 */     } catch (class_151 ex) {
/* 52 */       throw InvalidKeyExceptionAccess.newInvalidKeyException(namespace, value, ex.getMessage());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\api\KeyMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */