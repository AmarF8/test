/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.api;
/*    */ 
/*    */ import net.kyori.adventure.chat.SignedMessage;
/*    */ import net.minecraft.class_7469;
/*    */ import org.jetbrains.annotations.Contract;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Overwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin(value = {SignedMessage.class}, remap = false)
/*    */ public interface SignedMessageMixin
/*    */ {
/*    */   @Overwrite
/*    */   @Contract(value = "_ -> new", pure = true)
/*    */   static SignedMessage.Signature signature(byte[] bytes) {
/* 47 */     return (SignedMessage.Signature)new class_7469(bytes);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\api\SignedMessageMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */