/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.authlib;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import java.util.UUID;
/*    */ import net.kyori.adventure.identity.Identity;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin(value = {GameProfile.class}, remap = false)
/*    */ public abstract class GameProfileMixin
/*    */   implements Identity
/*    */ {
/*    */   @Shadow
/*    */   public abstract UUID shadow$getId();
/*    */   
/*    */   @NotNull
/*    */   public UUID uuid() {
/* 41 */     return shadow$getId();
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\authlib\GameProfileMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */