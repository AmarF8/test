/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.brigadier.exceptions;
/*    */ 
/*    */ import com.mojang.brigadier.Message;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import net.kyori.adventure.platform.fabric.FabricAudiences;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.kyori.adventure.util.ComponentMessageThrowable;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_2564;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin(value = {CommandSyntaxException.class}, remap = false)
/*    */ abstract class CommandSyntaxExceptionMixin
/*    */   implements ComponentMessageThrowable
/*    */ {
/*    */   @Shadow
/*    */   public abstract Message shadow$getRawMessage();
/*    */   
/*    */   @NotNull
/*    */   public Component componentMessage() {
/* 44 */     class_2561 minecraft = class_2564.method_10883(shadow$getRawMessage());
/*    */     
/* 46 */     return FabricAudiences.nonWrappingSerializer().deserialize(minecraft);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\brigadier\exceptions\CommandSyntaxExceptionMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */