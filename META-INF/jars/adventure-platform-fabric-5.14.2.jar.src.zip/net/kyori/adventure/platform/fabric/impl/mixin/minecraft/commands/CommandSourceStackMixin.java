/*     */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.commands;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import net.kyori.adventure.audience.Audience;
/*     */ import net.kyori.adventure.identity.Identified;
/*     */ import net.kyori.adventure.identity.Identity;
/*     */ import net.kyori.adventure.platform.fabric.AdventureCommandSourceStack;
/*     */ import net.kyori.adventure.platform.fabric.FabricServerAudiences;
/*     */ import net.kyori.adventure.platform.fabric.impl.AdventureCommandSourceStackInternal;
/*     */ import net.kyori.adventure.platform.fabric.impl.server.FabricServerAudiencesImpl;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.format.NamedTextColor;
/*     */ import net.kyori.adventure.text.format.TextColor;
/*     */ import net.minecraft.class_2165;
/*     */ import net.minecraft.class_2168;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({class_2168.class})
/*     */ public abstract class CommandSourceStackMixin
/*     */   implements AdventureCommandSourceStackInternal
/*     */ {
/*     */   @Shadow
/*     */   @Final
/*     */   private class_2165 field_9819;
/*     */   @Shadow
/*     */   @Final
/*     */   private boolean field_9823;
/*     */   @Shadow
/*     */   @Final
/*     */   private MinecraftServer field_9818;
/*     */   private boolean adventure$assigned = false;
/*     */   private Audience adventure$out;
/*     */   private FabricServerAudiences adventure$controller;
/*     */   
/*     */   public void sendSuccess(@NotNull Component text, boolean sendToOps) {
/*  67 */     shadow$method_9226(() -> this.adventure$controller.toNative(text), sendToOps);
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendLazySuccess(@NotNull Supplier<Component> text, boolean sendToOps) {
/*  72 */     Objects.requireNonNull(text, "text");
/*  73 */     shadow$method_9226(() -> this.adventure$controller.toNative(text.get()), sendToOps);
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendFailure(@NotNull Component text) {
/*  78 */     if (this.field_9819.method_9202() && !this.field_9823) {
/*  79 */       sendMessage(text.color((TextColor)NamedTextColor.RED));
/*     */     }
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Audience audience() {
/*  85 */     if (this.adventure$out == null) {
/*  86 */       if (this.field_9818 == null) {
/*  87 */         throw new IllegalStateException("Cannot use adventure operations without an available server!");
/*     */       }
/*  89 */       this.adventure$controller = FabricServerAudiences.of(this.field_9818);
/*  90 */       this.adventure$out = this.adventure$controller.audience(this.field_9819);
/*     */     } 
/*  92 */     return this.adventure$out;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Identity identity() {
/*  97 */     if (this.field_9819 instanceof Identified) {
/*  98 */       return ((Identified)this.field_9819).identity();
/*     */     }
/* 100 */     return Identity.nil();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AdventureCommandSourceStack adventure$audience(Audience wrapped, FabricServerAudiencesImpl controller) {
/* 106 */     if (this.adventure$assigned && !Objects.equals(controller, this.adventure$controller)) {
/* 107 */       throw new IllegalStateException("This command source has been attached to a specific renderer already!");
/*     */     }
/*     */     
/* 110 */     this.adventure$assigned = true;
/* 111 */     this.adventure$out = wrapped;
/* 112 */     this.adventure$controller = (FabricServerAudiences)controller;
/* 113 */     return (AdventureCommandSourceStack)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_2165 adventure$source() {
/* 118 */     return this.field_9819;
/*     */   }
/*     */   
/*     */   @Shadow
/*     */   protected abstract void shadow$method_9212(class_2561 paramclass_2561);
/*     */   
/*     */   @Shadow
/*     */   public abstract void shadow$method_9226(Supplier<class_2561> paramSupplier, boolean paramBoolean);
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\commands\CommandSourceStackMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */