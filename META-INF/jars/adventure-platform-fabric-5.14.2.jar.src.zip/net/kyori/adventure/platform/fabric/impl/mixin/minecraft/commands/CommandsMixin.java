/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.commands;
/*    */ 
/*    */ import com.google.common.collect.Iterators;
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.builder.ArgumentBuilder;
/*    */ import com.mojang.brigadier.builder.RequiredArgumentBuilder;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import com.mojang.brigadier.tree.CommandNode;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import net.kyori.adventure.platform.fabric.impl.ServerArgumentType;
/*    */ import net.kyori.adventure.platform.fabric.impl.ServerArgumentTypes;
/*    */ import net.kyori.adventure.platform.fabric.impl.accessor.brigadier.builder.RequiredArgumentBuilderAccess;
/*    */ import net.minecraft.class_2168;
/*    */ import net.minecraft.class_2170;
/*    */ import net.minecraft.class_2172;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_7157;
/*    */ import net.minecraft.class_7225;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyVariable;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_2170.class})
/*    */ public abstract class CommandsMixin
/*    */ {
/*    */   @Inject(method = {"fillUsableCommands"}, locals = LocalCapture.CAPTURE_FAILEXCEPTION, at = {@At(value = "INVOKE", target = "com.mojang.brigadier.builder.RequiredArgumentBuilder.getSuggestionsProvider()Lcom/mojang/brigadier/suggestion/SuggestionProvider;", remap = false, ordinal = 0)})
/*    */   public <T> void adventure$replaceArgumentType(CommandNode<class_2168> tree, CommandNode<class_2172> result, class_2168 source, Map<CommandNode<class_2168>, CommandNode<class_2172>> nodes, CallbackInfo ci, Iterator<?> it, CommandNode<class_2168> current, ArgumentBuilder<?, ?> unused, RequiredArgumentBuilder<?, T> builder) throws CommandSyntaxException {
/* 73 */     ServerArgumentType<ArgumentType<T>> type = ServerArgumentTypes.byClass(builder.getType().getClass());
/* 74 */     Set<class_2960> knownExtraCommands = ServerArgumentTypes.knownArgumentTypes(source.method_44023());
/*    */ 
/*    */ 
/*    */     
/* 78 */     while (type != null && !knownExtraCommands.contains(type.id())) {
/* 79 */       class_7157 ctx = class_7157.method_46722((class_7225.class_7874)source.method_30497(), source.method_45549());
/* 80 */       ((RequiredArgumentBuilderAccess)builder).accessor$type(type.fallbackProvider().apply(builder.getType(), ctx));
/* 81 */       if (type.fallbackSuggestions() != null) {
/* 82 */         builder.suggests(type.fallbackSuggestions());
/*    */       }
/* 84 */       type = ServerArgumentTypes.byClass(builder.getType().getClass());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @ModifyVariable(method = {"fillUsableCommands"}, at = @At("STORE"), ordinal = 0, require = 0)
/*    */   private Iterator<CommandNode<class_2168>> adventure$filterHiddenCommands(Iterator<CommandNode<class_2168>> itr) {
/* 99 */     return (Iterator<CommandNode<class_2168>>)Iterators.filter(itr, node -> !(node.getRequirement() instanceof net.kyori.adventure.platform.fabric.impl.HiddenRequirement));
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\commands\CommandsMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */