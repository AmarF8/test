/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.commands.synchronization;
/*    */ 
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import net.kyori.adventure.platform.fabric.impl.ServerArgumentType;
/*    */ import net.kyori.adventure.platform.fabric.impl.ServerArgumentTypes;
/*    */ import net.minecraft.class_2314;
/*    */ import net.minecraft.class_2316;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_2316.class})
/*    */ public abstract class ArgumentTypeInfosMixin
/*    */ {
/*    */   @Inject(method = {"unpack(Lcom/mojang/brigadier/arguments/ArgumentType;)Lnet/minecraft/commands/synchronization/ArgumentTypeInfo$Template;"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private static <A extends ArgumentType<?>> void unpackServerArgument(A argumentType, CallbackInfoReturnable<class_2314.class_7217<?>> cir) {
/* 48 */     ServerArgumentType<A> serverType = ServerArgumentTypes.byClass(argumentType.getClass());
/* 49 */     if (serverType != null)
/* 50 */       cir.setReturnValue(serverType.argumentTypeInfo().method_41726((ArgumentType)argumentType)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\commands\synchronization\ArgumentTypeInfosMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */