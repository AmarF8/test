/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.commands.synchronization;
/*    */ 
/*    */ import net.kyori.adventure.platform.fabric.impl.ServerArgumentTypes;
/*    */ import net.minecraft.class_2314;
/*    */ import net.minecraft.class_2378;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_7218;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_7218.class})
/*    */ public abstract class ArgumentUtilsMixin
/*    */ {
/*    */   @Redirect(method = {"serializeArgumentToJson(Lcom/google/gson/JsonObject;Lcom/mojang/brigadier/arguments/ArgumentType;)V"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/core/Registry;getKey(Ljava/lang/Object;)Lnet/minecraft/resources/ResourceLocation;"))
/*    */   @Nullable
/*    */   private static class_2960 redirectArgumentName(class_2378 registry, Object argumentTypeInfo) {
/* 44 */     if (ServerArgumentTypes.isServerType((class_2314)argumentTypeInfo)) {
/* 45 */       return ServerArgumentTypes.serverType((class_2314)argumentTypeInfo).id();
/*    */     }
/* 47 */     return registry.method_10221(argumentTypeInfo);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\commands\synchronization\ArgumentUtilsMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */