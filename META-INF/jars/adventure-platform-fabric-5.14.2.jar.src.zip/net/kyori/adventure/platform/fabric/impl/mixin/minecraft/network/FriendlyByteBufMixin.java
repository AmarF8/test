/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.network;
/*    */ 
/*    */ import net.kyori.adventure.platform.fabric.impl.server.FriendlyByteBufBridge;
/*    */ import net.kyori.adventure.pointer.Pointered;
/*    */ import net.minecraft.class_2540;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_2540.class})
/*    */ public abstract class FriendlyByteBufMixin
/*    */   implements FriendlyByteBufBridge
/*    */ {
/*    */   @Nullable
/*    */   private Pointered adventure$data;
/*    */   
/*    */   public void adventure$data(@Nullable Pointered data) {
/* 38 */     this.adventure$data = data;
/*    */   }
/*    */ 
/*    */   
/*    */   public Pointered adventure$data() {
/* 43 */     return this.adventure$data;
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\network\FriendlyByteBufMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */