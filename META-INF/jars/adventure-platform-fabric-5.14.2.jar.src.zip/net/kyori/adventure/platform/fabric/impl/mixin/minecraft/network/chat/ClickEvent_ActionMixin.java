/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.network.chat;
/*    */ 
/*    */ import net.kyori.adventure.platform.fabric.impl.NonWrappingComponentSerializer;
/*    */ import net.minecraft.class_2558;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_2558.class_2559.class})
/*    */ abstract class ClickEvent_ActionMixin
/*    */ {
/*    */   @Redirect(method = {"filterForSerialization"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/network/chat/ClickEvent$Action;isAllowedFromServer()Z"))
/*    */   private static boolean adventure$redirectIsAllowedFromServer(class_2558.class_2559 action) {
/* 37 */     if (NonWrappingComponentSerializer.bypassIsAllowedFromServer()) {
/* 38 */       return true;
/*    */     }
/* 40 */     return action.method_10847();
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\network\chat\ClickEvent_ActionMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */