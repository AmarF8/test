/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.network.chat;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import net.kyori.adventure.platform.fabric.impl.WrappedComponent;
/*    */ import net.kyori.adventure.text.serializer.gson.GsonComponentSerializer;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_7225;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_2561.class_2562.class})
/*    */ public abstract class SerializerMixin
/*    */ {
/*    */   @Inject(method = {"serialize"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private static void adventure$writeComponentBase(class_2561 text, class_7225.class_7874 prov, CallbackInfoReturnable<JsonElement> cir) {
/* 54 */     if (text instanceof WrappedComponent) { WrappedComponent w = (WrappedComponent)text;
/* 55 */       class_2561 converted = w.deepConvertedIfPresent();
/* 56 */       if (converted == null)
/* 57 */         cir.setReturnValue(GsonComponentSerializer.gson().serializeToTree(w.wrapped()));  }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\network\chat\ComponentMixin$SerializerMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */