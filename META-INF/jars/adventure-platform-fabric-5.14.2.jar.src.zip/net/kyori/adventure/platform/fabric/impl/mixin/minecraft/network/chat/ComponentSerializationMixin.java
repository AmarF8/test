/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.network.chat;
/*    */ 
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import com.mojang.serialization.Codec;
/*    */ import net.kyori.adventure.platform.fabric.impl.ComponentCodecs;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_8824;
/*    */ import net.minecraft.class_9139;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_8824.class})
/*    */ public abstract class ComponentSerializationMixin
/*    */ {
/*    */   @Inject(method = {"createCodec"}, at = {@At("RETURN")}, cancellable = true)
/*    */   private static void adventure$wrapCodec(Codec<class_2561> recursive, CallbackInfoReturnable<Codec<class_2561>> cir) {
/* 45 */     Codec<class_2561> original = (Codec<class_2561>)cir.getReturnValue();
/* 46 */     cir.setReturnValue(ComponentCodecs.unwrappingToNative(original));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @WrapOperation(method = {"<clinit>()V"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/network/codec/ByteBufCodecs;fromCodecWithRegistries(Lcom/mojang/serialization/Codec;)Lnet/minecraft/network/codec/StreamCodec;"), @At(value = "INVOKE", target = "Lnet/minecraft/network/codec/ByteBufCodecs;fromCodecWithRegistriesTrusted(Lcom/mojang/serialization/Codec;)Lnet/minecraft/network/codec/StreamCodec;"), @At(value = "INVOKE", target = "Lnet/minecraft/network/codec/ByteBufCodecs;fromCodecTrusted(Lcom/mojang/serialization/Codec;)Lnet/minecraft/network/codec/StreamCodec;")})
/*    */   private static <T extends io.netty.buffer.ByteBuf> class_9139<T, class_2561> adventure$wrapStreamCodec(Codec<class_2561> codec, Operation<class_9139<T, class_2561>> op) {
/* 56 */     return ComponentCodecs.translatingStreamCodec((class_9139)op.call(new Object[] { codec }));
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\network\chat\ComponentSerializationMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */