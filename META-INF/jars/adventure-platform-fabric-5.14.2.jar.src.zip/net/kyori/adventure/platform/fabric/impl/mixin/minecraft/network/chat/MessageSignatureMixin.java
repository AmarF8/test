/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.network.chat;
/*    */ 
/*    */ import net.kyori.adventure.chat.SignedMessage;
/*    */ import net.minecraft.class_7469;
/*    */ import org.spongepowered.asm.mixin.Implements;
/*    */ import org.spongepowered.asm.mixin.Interface;
/*    */ import org.spongepowered.asm.mixin.Intrinsic;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Implements({@Interface(iface = SignedMessage.Signature.class, prefix = "signature$")})
/*    */ @Mixin({class_7469.class})
/*    */ public abstract class MessageSignatureMixin
/*    */ {
/*    */   @Shadow
/*    */   public abstract byte[] shadow$comp_925();
/*    */   
/*    */   @Intrinsic
/*    */   public byte[] signature$bytes() {
/* 44 */     return shadow$comp_925();
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\network\chat\MessageSignatureMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */