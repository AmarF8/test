/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.network.chat;
/*    */ 
/*    */ import net.kyori.adventure.platform.fabric.impl.WrappedComponent;
/*    */ import net.minecraft.class_5250;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_5250.class})
/*    */ abstract class MutableComponentMixin
/*    */ {
/*    */   @Inject(method = {"equals"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void hookEquals(Object other, CallbackInfoReturnable<Boolean> cir) {
/* 37 */     if (other instanceof WrappedComponent) { WrappedComponent wrapped = (WrappedComponent)other;
/* 38 */       cir.setReturnValue(Boolean.valueOf(wrapped.equals(this))); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\network\chat\MutableComponentMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */