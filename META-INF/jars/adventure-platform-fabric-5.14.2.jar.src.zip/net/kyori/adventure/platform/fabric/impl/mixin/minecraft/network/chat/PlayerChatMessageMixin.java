/*     */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.network.chat;
/*     */ 
/*     */ import java.time.Instant;
/*     */ import java.util.stream.Stream;
/*     */ import net.kyori.adventure.chat.SignedMessage;
/*     */ import net.kyori.adventure.identity.Identity;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.ComponentLike;
/*     */ import net.kyori.examination.ExaminableProperty;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_7469;
/*     */ import net.minecraft.class_7471;
/*     */ import net.minecraft.class_7608;
/*     */ import net.minecraft.class_7649;
/*     */ import net.minecraft.class_7826;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Implements;
/*     */ import org.spongepowered.asm.mixin.Interface;
/*     */ import org.spongepowered.asm.mixin.Intrinsic;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Implements({@Interface(iface = SignedMessage.class, prefix = "signedMessage$")})
/*     */ @Mixin({class_7471.class})
/*     */ public abstract class PlayerChatMessageMixin
/*     */   implements SignedMessage
/*     */ {
/*     */   @Shadow
/*     */   @Final
/*     */   private class_7826 comp_1083;
/*     */   @Shadow
/*     */   @Final
/*     */   private class_7469 comp_1084;
/*     */   @Shadow
/*     */   @Final
/*     */   private class_7608 comp_928;
/*     */   @Shadow
/*     */   @Final
/*     */   private class_2561 comp_830;
/*     */   @Shadow
/*     */   @Final
/*     */   private class_7649 comp_981;
/*     */   
/*     */   @Shadow
/*     */   public abstract class_7469 shadow$comp_1084();
/*     */   
/*     */   @Shadow
/*     */   public abstract class_2561 shadow$comp_830();
/*     */   
/*     */   @Shadow
/*     */   public abstract class_7608 shadow$comp_928();
/*     */   
/*     */   @Shadow
/*     */   public abstract class_7826 shadow$comp_1083();
/*     */   
/*     */   @Shadow
/*     */   public abstract boolean shadow$method_46293();
/*     */   
/*     */   @NotNull
/*     */   public Identity identity() {
/*  67 */     return shadow$method_46293() ? Identity.nil() : Identity.identity(shadow$comp_1083().comp_1095());
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Instant timestamp() {
/*  72 */     return shadow$comp_928().comp_930();
/*     */   }
/*     */ 
/*     */   
/*     */   public long method_44865() {
/*  77 */     return shadow$comp_928().comp_931();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public SignedMessage.Signature signature() {
/*  82 */     return (SignedMessage.Signature)shadow$comp_1084();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Component unsignedContent() {
/*  87 */     return ComponentLike.unbox((ComponentLike)shadow$comp_830());
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public String message() {
/*  92 */     return shadow$comp_928().comp_929();
/*     */   }
/*     */   
/*     */   @Intrinsic
/*     */   public boolean signedMessage$isSystem() {
/*  97 */     return shadow$method_46293();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canDelete() {
/* 102 */     return (shadow$comp_1084() != null);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Stream<? extends ExaminableProperty> examinableProperties() {
/* 107 */     return Stream.of(new ExaminableProperty[] {
/* 108 */           ExaminableProperty.of("link", this.comp_1083), 
/* 109 */           ExaminableProperty.of("signature", this.comp_1084), 
/* 110 */           ExaminableProperty.of("signedBody", this.comp_928), 
/* 111 */           ExaminableProperty.of("unsignedContent", this.comp_830), 
/* 112 */           ExaminableProperty.of("filterMask", this.comp_981)
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\network\chat\PlayerChatMessageMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */