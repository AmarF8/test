/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.network.protocol.game;
/*    */ 
/*    */ import net.kyori.adventure.platform.fabric.impl.ServerArgumentTypes;
/*    */ import net.minecraft.class_2314;
/*    */ import net.minecraft.class_2378;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin(targets = {"net.minecraft.network.protocol.game.ClientboundCommandsPacket$ArgumentNodeStub"})
/*    */ public abstract class ArgumentNodeStubMixin
/*    */ {
/*    */   @Redirect(method = {"serializeCap(Lnet/minecraft/network/FriendlyByteBuf;Lnet/minecraft/commands/synchronization/ArgumentTypeInfo;Lnet/minecraft/commands/synchronization/ArgumentTypeInfo$Template;)V"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/core/Registry;getId(Ljava/lang/Object;)I"))
/*    */   private static int redirectGetId(class_2378 registry, @Nullable Object argumentTypeInfo) {
/* 56 */     if (ServerArgumentTypes.isServerType((class_2314)argumentTypeInfo)) {
/* 57 */       return ServerArgumentTypes.id((class_2314)argumentTypeInfo);
/*    */     }
/* 59 */     return registry.method_10206(argumentTypeInfo);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\network\protocol\game\ClientboundCommandsPacketMixin$ArgumentNodeStubMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */