/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.resources;
/*    */ 
/*    */ import com.mojang.serialization.DynamicOps;
/*    */ import net.kyori.adventure.platform.fabric.impl.DelegatingOpsBridge;
/*    */ import net.minecraft.class_5379;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_5379.class})
/*    */ public abstract class DelegatingOpsMixin
/*    */   implements DelegatingOpsBridge
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   protected DynamicOps<?> field_25503;
/*    */   
/*    */   public DynamicOps<?> adventure$bridge$delegate() {
/* 41 */     return this.field_25503;
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\resources\DelegatingOpsMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */