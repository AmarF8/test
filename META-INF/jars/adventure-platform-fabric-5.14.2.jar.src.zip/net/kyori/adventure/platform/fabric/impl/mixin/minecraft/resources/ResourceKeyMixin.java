/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.resources;
/*    */ 
/*    */ import net.kyori.adventure.key.Key;
/*    */ import net.kyori.adventure.key.Keyed;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_5321;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_5321.class})
/*    */ public abstract class ResourceKeyMixin
/*    */   implements Keyed
/*    */ {
/*    */   @Shadow
/*    */   public abstract class_2960 shadow$method_29177();
/*    */   
/*    */   @NotNull
/*    */   public Key key() {
/* 42 */     return (Key)shadow$method_29177();
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\resources\ResourceKeyMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */