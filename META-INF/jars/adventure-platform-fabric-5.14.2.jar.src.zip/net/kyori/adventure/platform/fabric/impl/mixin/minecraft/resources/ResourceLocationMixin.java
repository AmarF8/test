/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.resources;
/*    */ 
/*    */ import net.kyori.adventure.key.Key;
/*    */ import net.minecraft.class_2960;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Implements;
/*    */ import org.spongepowered.asm.mixin.Interface;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_2960.class})
/*    */ @Implements({@Interface(iface = Key.class, prefix = "key$")})
/*    */ public abstract class ResourceLocationMixin
/*    */ {
/*    */   @Shadow
/*    */   public abstract String shadow$method_12836();
/*    */   
/*    */   @Shadow
/*    */   public abstract String shadow$method_12832();
/*    */   
/*    */   @NotNull
/*    */   public String key$namespace() {
/* 43 */     return shadow$method_12836();
/*    */   }
/*    */   @NotNull
/*    */   public String key$value() {
/* 47 */     return shadow$method_12832();
/*    */   }
/*    */   @NotNull
/*    */   public String key$asString() {
/* 51 */     return toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\resources\ResourceLocationMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */