/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.server;
/*    */ 
/*    */ import com.google.common.collect.MapMaker;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ import net.kyori.adventure.audience.Audience;
/*    */ import net.kyori.adventure.audience.ForwardingAudience;
/*    */ import net.kyori.adventure.identity.Identity;
/*    */ import net.kyori.adventure.permission.PermissionChecker;
/*    */ import net.kyori.adventure.platform.fabric.FabricServerAudiences;
/*    */ import net.kyori.adventure.platform.fabric.impl.ControlledAudience;
/*    */ import net.kyori.adventure.platform.fabric.impl.FabricAudiencesInternal;
/*    */ import net.kyori.adventure.platform.fabric.impl.server.FabricServerAudiencesImpl;
/*    */ import net.kyori.adventure.platform.fabric.impl.server.MinecraftServerBridge;
/*    */ import net.kyori.adventure.platform.fabric.impl.server.PlainAudience;
/*    */ import net.kyori.adventure.platform.fabric.impl.server.RenderableAudience;
/*    */ import net.kyori.adventure.pointer.Pointered;
/*    */ import net.kyori.adventure.pointer.Pointers;
/*    */ import net.kyori.adventure.util.TriState;
/*    */ import net.minecraft.class_7659;
/*    */ import net.minecraft.class_7780;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.slf4j.Logger;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({MinecraftServer.class})
/*    */ public abstract class MinecraftServerMixin
/*    */   implements MinecraftServerBridge, RenderableAudience, ForwardingAudience.Single, ControlledAudience
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private static Logger field_4546;
/* 62 */   private final FabricServerAudiencesImpl adventure$globalProvider = (new FabricServerAudiencesImpl.Builder((MinecraftServer)this)).build();
/* 63 */   private final Map<FabricAudiencesInternal, Audience> adventure$renderers = (new MapMaker()).weakKeys().makeMap();
/* 64 */   private final Audience adventure$backing = renderUsing(this.adventure$globalProvider);
/*    */   
/*    */   private volatile Pointers adventure$pointers;
/*    */   
/*    */   public FabricServerAudiences adventure$globalProvider() {
/* 69 */     return (FabricServerAudiences)this.adventure$globalProvider;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Audience audience() {
/* 74 */     return this.adventure$backing;
/*    */   }
/*    */ 
/*    */   
/*    */   public Audience renderUsing(FabricServerAudiencesImpl controller) {
/* 79 */     return this.adventure$renderers.computeIfAbsent(controller, ctrl -> {
/*    */           Objects.requireNonNull(field_4546);
/*    */           return (Audience)new PlainAudience(ctrl, (Pointered)this, field_4546::info);
/*    */         }); } @NotNull
/*    */   public Pointers pointers() {
/* 84 */     if (this.adventure$pointers == null) {
/* 85 */       synchronized (this) {
/* 86 */         if (this.adventure$pointers == null) {
/* 87 */           return this
/*    */ 
/*    */             
/* 90 */             .adventure$pointers = (Pointers)Pointers.builder().withStatic(Identity.NAME, "Server").withStatic(PermissionChecker.POINTER, perm -> TriState.TRUE).build();
/*    */         }
/*    */       } 
/*    */     }
/* 94 */     return this.adventure$pointers;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public FabricAudiencesInternal controller() {
/* 99 */     return (FabricAudiencesInternal)this.adventure$globalProvider;
/*    */   }
/*    */   
/*    */   public void refresh() {}
/*    */   
/*    */   @Shadow
/*    */   public abstract class_7780<class_7659> method_46221();
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\server\MinecraftServerMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */