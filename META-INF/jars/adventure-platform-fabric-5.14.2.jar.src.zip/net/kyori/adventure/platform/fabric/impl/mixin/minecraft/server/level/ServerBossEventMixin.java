/*     */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.server.level;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import net.kyori.adventure.platform.fabric.impl.server.ServerBossEventBridge;
/*     */ import net.minecraft.class_1259;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2629;
/*     */ import net.minecraft.class_3213;
/*     */ import net.minecraft.class_3222;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.Redirect;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({class_3213.class})
/*     */ public abstract class ServerBossEventMixin
/*     */   extends class_1259
/*     */   implements ServerBossEventBridge
/*     */ {
/*     */   private static final float MINIMUM_PERCENT_CHANGE = 5.0E-4F;
/*     */   @Shadow
/*     */   @Final
/*     */   private Set<class_3222> field_13913;
/*     */   private float adventure$lastSentPercent;
/*     */   
/*     */   @Shadow
/*     */   public abstract boolean shadow$method_14093();
/*     */   
/*     */   public ServerBossEventMixin(UUID uuid, class_2561 name, class_1259.class_1260 color, class_1259.class_1261 style) {
/*  57 */     super(uuid, name, color, style);
/*  58 */     this.adventure$lastSentPercent = this.field_5774;
/*     */   }
/*     */ 
/*     */   
/*     */   @Redirect(method = {"removePlayer"}, at = @At(value = "INVOKE", target = "Ljava/util/Set;remove(Ljava/lang/Object;)Z"))
/*     */   private boolean adventure$removeByUuid(Set<?> instance, Object player) {
/*  64 */     if (instance.remove(player)) {
/*  65 */       return true;
/*     */     }
/*  67 */     if (!(player instanceof class_3222)) {
/*  68 */       return false;
/*     */     }
/*     */     
/*  71 */     UUID testId = ((class_3222)player).method_5667();
/*  72 */     for (Iterator<?> it = instance.iterator(); it.hasNext();) {
/*  73 */       if (((class_3222)it.next()).method_5667().equals(testId)) {
/*  74 */         it.remove();
/*  75 */         return true;
/*     */       } 
/*     */     } 
/*  78 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void adventure$addAll(Collection<class_3222> players) {
/*  83 */     class_2629 pkt = class_2629.method_34089(this);
/*  84 */     for (class_3222 player : players) {
/*  85 */       if (this.field_13913.add(player) && shadow$method_14093()) {
/*  86 */         player.field_13987.method_14364((class_2596)pkt);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void adventure$removeAll(Collection<class_3222> players) {
/*  93 */     class_2629 pkt = class_2629.method_34090(method_5407());
/*  94 */     for (class_3222 player : players) {
/*  95 */       if (this.field_13913.remove(player) && shadow$method_14093()) {
/*  96 */         player.field_13987.method_14364((class_2596)pkt);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void adventure$replaceSubscriber(class_3222 oldSub, class_3222 newSub) {
/* 103 */     if (this.field_13913.remove(oldSub)) {
/* 104 */       this.field_13913.add(newSub);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"setProgress"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/world/BossEvent;setProgress(F)V")}, cancellable = true, require = 0)
/*     */   private void adventure$onlySetPercentIfBigEnough(float newPercent, CallbackInfo ci) {
/* 112 */     if (Math.abs(newPercent - this.adventure$lastSentPercent) < 5.0E-4F) {
/* 113 */       this.field_5774 = newPercent;
/* 114 */       ci.cancel();
/*     */     } else {
/* 116 */       this.adventure$lastSentPercent = newPercent;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\server\level\ServerBossEventMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */