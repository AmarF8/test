/*     */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.server.level;
/*     */ 
/*     */ import com.google.common.collect.MapMaker;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import net.kyori.adventure.audience.Audience;
/*     */ import net.kyori.adventure.audience.ForwardingAudience;
/*     */ import net.kyori.adventure.platform.fabric.FabricServerAudiences;
/*     */ import net.kyori.adventure.platform.fabric.PlayerLocales;
/*     */ import net.kyori.adventure.platform.fabric.impl.ControlledAudience;
/*     */ import net.kyori.adventure.platform.fabric.impl.FabricAudiencesInternal;
/*     */ import net.kyori.adventure.platform.fabric.impl.LocaleHolderBridge;
/*     */ import net.kyori.adventure.platform.fabric.impl.mixin.minecraft.world.entity.player.PlayerMixin;
/*     */ import net.kyori.adventure.platform.fabric.impl.server.FabricServerAudiencesImpl;
/*     */ import net.kyori.adventure.platform.fabric.impl.server.RenderableAudience;
/*     */ import net.kyori.adventure.platform.fabric.impl.server.ServerPlayerAudience;
/*     */ import net.kyori.adventure.platform.fabric.impl.server.ServerPlayerBridge;
/*     */ import net.minecraft.class_1299;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2165;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2772;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_3222;
/*     */ import net.minecraft.class_3244;
/*     */ import net.minecraft.class_8791;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({class_3222.class})
/*     */ public abstract class ServerPlayerMixin
/*     */   extends PlayerMixin
/*     */   implements ForwardingAudience.Single, LocaleHolderBridge, RenderableAudience, ServerPlayerBridge, ControlledAudience
/*     */ {
/*     */   @Shadow
/*     */   @Final
/*     */   public MinecraftServer field_13995;
/*     */   @Shadow
/*     */   public class_3244 field_13987;
/*     */   private Audience adventure$backing;
/*     */   private Locale adventure$locale;
/*  71 */   private final Map<FabricServerAudiencesImpl, Audience> adventure$renderers = (new MapMaker()).weakKeys().makeMap();
/*  72 */   private class_2561 adventure$tabListHeader = (class_2561)class_2561.method_43473();
/*  73 */   private class_2561 adventure$tabListFooter = (class_2561)class_2561.method_43473();
/*  74 */   private Set<class_2960> adventure$arguments = Set.of();
/*     */   
/*     */   protected ServerPlayerMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
/*  77 */     super(entityType, level);
/*     */   }
/*     */   
/*     */   @Inject(method = {"<init>"}, at = {@At("TAIL")})
/*     */   private void adventure$init(CallbackInfo ci) {
/*  82 */     this.adventure$backing = FabricServerAudiences.of(this.field_13995).audience((class_2165)this);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Audience audience() {
/*  87 */     return this.adventure$backing;
/*     */   }
/*     */ 
/*     */   
/*     */   public Audience renderUsing(FabricServerAudiencesImpl controller) {
/*  92 */     return this.adventure$renderers.computeIfAbsent(controller, ctrl -> new ServerPlayerAudience((class_3222)this, ctrl));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Locale adventure$locale() {
/*  97 */     return this.adventure$locale;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public FabricAudiencesInternal controller() {
/* 102 */     return (FabricAudiencesInternal)FabricServerAudiences.of(this.field_13995);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bridge$updateTabList(@Nullable class_2561 header, @Nullable class_2561 footer) {
/* 109 */     if (header != null) {
/* 110 */       this.adventure$tabListHeader = header;
/*     */     }
/* 112 */     if (footer != null) {
/* 113 */       this.adventure$tabListFooter = footer;
/*     */     }
/* 115 */     class_2772 packet = new class_2772(this.adventure$tabListHeader, this.adventure$tabListFooter);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     this.field_13987.method_14364((class_2596)packet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"updateOptions"}, at = {@At("HEAD")})
/*     */   private void adventure$handleLocaleUpdate(class_8791 information, CallbackInfo ci) {
/* 128 */     String language = information.comp_1951();
/* 129 */     Locale locale = LocaleHolderBridge.toLocale(language);
/* 130 */     if (!Objects.equals(this.adventure$locale, locale)) {
/* 131 */       this.adventure$locale = locale;
/* 132 */       ((PlayerLocales.Changed)PlayerLocales.CHANGED_EVENT.invoker()).onLocaleChanged((class_3222)this, locale);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"restoreFrom"}, at = {@At("RETURN")})
/*     */   private void copyData(class_3222 old, boolean alive, CallbackInfo ci) {
/* 140 */     FabricServerAudiencesImpl.forEachInstance(controller -> controller.bossBars().replacePlayer(old, (class_3222)this));
/*     */   }
/*     */   
/*     */   @Inject(method = {"disconnect"}, at = {@At("RETURN")})
/*     */   private void adventure$removeBossBarsOnDisconnect(CallbackInfo ci) {
/* 145 */     FabricServerAudiencesImpl.forEachInstance(controller -> controller.bossBars().unsubscribeFromAll((class_3222)this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<class_2960> bridge$knownArguments() {
/* 152 */     return this.adventure$arguments;
/*     */   }
/*     */ 
/*     */   
/*     */   public void bridge$knownArguments(Set<class_2960> arguments) {
/* 157 */     this.adventure$arguments = Set.copyOf(arguments);
/*     */   }
/*     */   
/*     */   @Inject(method = {"restoreFrom"}, at = {@At("RETURN")})
/*     */   public void adventure$copyData(class_3222 from, boolean keepEverything, CallbackInfo ci) {
/* 162 */     bridge$knownArguments(((ServerPlayerBridge)from).bridge$knownArguments());
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\server\level\ServerPlayerMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */