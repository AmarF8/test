/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.server.network;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import net.kyori.adventure.platform.fabric.impl.GameEnums;
/*    */ import net.kyori.adventure.platform.fabric.impl.server.FabricServerAudiencesImpl;
/*    */ import net.kyori.adventure.platform.fabric.impl.server.ServerCommonPacketListenerImplBridge;
/*    */ import net.kyori.adventure.resource.ResourcePackCallback;
/*    */ import net.kyori.adventure.resource.ResourcePackStatus;
/*    */ import net.kyori.adventure.text.logger.slf4j.ComponentLogger;
/*    */ import net.minecraft.class_2535;
/*    */ import net.minecraft.class_2856;
/*    */ import net.minecraft.class_8609;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_8609.class})
/*    */ public abstract class ServerCommonPacketListenerImplMixin
/*    */   implements ServerCommonPacketListenerImplBridge
/*    */ {
/* 48 */   private static final ComponentLogger ADVENTURE$LOGGER = ComponentLogger.logger();
/* 49 */   private final Map<UUID, ServerCommonPacketListenerImplBridge.PackCallbackState> adventure$activeCallbacks = new ConcurrentHashMap<>();
/*    */   @Shadow
/*    */   @Final
/*    */   protected class_2535 field_45013;
/*    */   
/*    */   @Shadow
/*    */   protected abstract GameProfile shadow$method_52403();
/*    */   
/*    */   public class_2535 adventure$connection() {
/* 58 */     return this.field_45013;
/*    */   }
/*    */ 
/*    */   
/*    */   public void adventure$bridge$registerPackCallback(@NotNull UUID id, @NotNull FabricServerAudiencesImpl controller, @NotNull ResourcePackCallback cb) {
/* 63 */     if (this.adventure$activeCallbacks.put(id, new ServerCommonPacketListenerImplBridge.PackCallbackState(controller, cb)) != null) {
/* 64 */       ADVENTURE$LOGGER.warn("Duplicate in-flight callbacks detected for pack {} on player {}", id, shadow$method_52403());
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"handleResourcePackResponse(Lnet/minecraft/network/protocol/common/ServerboundResourcePackPacket;)V"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/network/protocol/common/ServerboundResourcePackPacket;action()Lnet/minecraft/network/protocol/common/ServerboundResourcePackPacket$Action;")}, cancellable = true)
/*    */   private void adventure$handleResourcePackCallback(class_2856 pkt, CallbackInfo ci) {
/*    */     ServerCommonPacketListenerImplBridge.PackCallbackState state;
/* 75 */     if (pkt.comp_2164().method_55627()) {
/* 76 */       state = this.adventure$activeCallbacks.remove(pkt.comp_2163());
/*    */     } else {
/* 78 */       state = this.adventure$activeCallbacks.get(pkt.comp_2163());
/*    */     } 
/*    */     
/* 81 */     if (state != null) {
/* 82 */       state.cb().packEventReceived(pkt
/* 83 */           .comp_2163(), (ResourcePackStatus)GameEnums.RESOURCE_PACK_STATUS
/* 84 */           .toAdventure(pkt.comp_2164()), state
/* 85 */           .controller().player(shadow$method_52403().getId()));
/*    */       
/* 87 */       ci.cancel();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\server\network\ServerCommonPacketListenerImplMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */