/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.server.network;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import java.util.function.Function;
/*    */ import net.kyori.adventure.platform.fabric.impl.server.FriendlyByteBufBridge;
/*    */ import net.kyori.adventure.pointer.Pointered;
/*    */ import net.minecraft.class_2547;
/*    */ import net.minecraft.class_3244;
/*    */ import net.minecraft.class_8610;
/*    */ import net.minecraft.class_9129;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyArg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_8610.class})
/*    */ public abstract class ServerConfigurationPacketListenerImplMixin
/*    */   extends ServerCommonPacketListenerImplMixin
/*    */ {
/*    */   @ModifyArg(method = {"handleConfigurationFinished"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/network/ProtocolInfo$Unbound;bind(Ljava/util/function/Function;)Lnet/minecraft/network/ProtocolInfo;"))
/*    */   private Function<ByteBuf, class_9129> adventure$injectPointers(Function<ByteBuf, class_9129> original) {
/* 40 */     return buf -> {
/*    */         class_9129 wrapped = original.apply(buf);
/*    */         class_2547 patt0$temp = adventure$connection().method_10744();
/*    */         if (patt0$temp instanceof class_3244) {
/*    */           class_3244 game = (class_3244)patt0$temp;
/*    */           ((FriendlyByteBufBridge)wrapped).adventure$data((Pointered)game.field_14140);
/*    */         } 
/*    */         return wrapped;
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\server\network\ServerConfigurationPacketListenerImplMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */