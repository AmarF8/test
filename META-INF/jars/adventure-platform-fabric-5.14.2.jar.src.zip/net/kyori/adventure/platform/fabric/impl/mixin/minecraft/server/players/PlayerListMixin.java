/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.server.players;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.CopyOnWriteArrayList;
/*    */ import net.minecraft.class_29;
/*    */ import net.minecraft.class_3222;
/*    */ import net.minecraft.class_3324;
/*    */ import net.minecraft.class_5455;
/*    */ import net.minecraft.class_7780;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Mutable;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_3324.class})
/*    */ public class PlayerListMixin
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   @Mutable
/*    */   private List<class_3222> field_14351;
/*    */   @Shadow
/*    */   @Final
/*    */   @Mutable
/*    */   private Map<UUID, class_3222> field_14354;
/*    */   
/*    */   @Inject(method = {"<init>"}, at = {@At("RETURN")}, require = 0)
/*    */   private void adventure$replacePlayerLists(MinecraftServer server, class_7780<class_5455> tracker, class_29 handler, int i, CallbackInfo ci) {
/* 58 */     this.field_14351 = new CopyOnWriteArrayList<>();
/* 59 */     this.field_14354 = new ConcurrentHashMap<>();
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\server\players\PlayerListMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */