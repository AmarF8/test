/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.server.rcon;
/*    */ 
/*    */ import com.google.common.collect.MapMaker;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ import net.kyori.adventure.audience.Audience;
/*    */ import net.kyori.adventure.audience.ForwardingAudience;
/*    */ import net.kyori.adventure.identity.Identity;
/*    */ import net.kyori.adventure.permission.PermissionChecker;
/*    */ import net.kyori.adventure.platform.fabric.FabricServerAudiences;
/*    */ import net.kyori.adventure.platform.fabric.impl.ControlledAudience;
/*    */ import net.kyori.adventure.platform.fabric.impl.FabricAudiencesInternal;
/*    */ import net.kyori.adventure.platform.fabric.impl.server.FabricServerAudiencesImpl;
/*    */ import net.kyori.adventure.platform.fabric.impl.server.PlainAudience;
/*    */ import net.kyori.adventure.platform.fabric.impl.server.RenderableAudience;
/*    */ import net.kyori.adventure.pointer.Pointered;
/*    */ import net.kyori.adventure.pointer.Pointers;
/*    */ import net.kyori.adventure.util.TriState;
/*    */ import net.minecraft.class_2165;
/*    */ import net.minecraft.class_3350;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_3350.class})
/*    */ public abstract class RconConsoleSourceMixin
/*    */   implements RenderableAudience, ForwardingAudience.Single, ControlledAudience
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private StringBuffer field_14404;
/*    */   @Shadow
/*    */   @Final
/*    */   private MinecraftServer field_14405;
/*    */   private volatile Pointers adventure$pointers;
/* 55 */   private final Map<FabricAudiencesInternal, Audience> adventure$renderers = (new MapMaker()).weakKeys().makeMap();
/*    */ 
/*    */   
/*    */   public Audience renderUsing(FabricServerAudiencesImpl controller) {
/* 59 */     return this.adventure$renderers.computeIfAbsent(controller, ctrl -> {
/*    */           Objects.requireNonNull(this.field_14404);
/*    */           return (Audience)new PlainAudience(ctrl, (Pointered)this, this.field_14404::append);
/*    */         }); } @NotNull
/*    */   public Audience audience() {
/* 64 */     return FabricServerAudiences.of(this.field_14405).audience((class_2165)this);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Pointers pointers() {
/* 69 */     if (this.adventure$pointers == null) {
/* 70 */       synchronized (this) {
/* 71 */         if (this.adventure$pointers == null) {
/* 72 */           return this
/*    */ 
/*    */             
/* 75 */             .adventure$pointers = (Pointers)Pointers.builder().withStatic(Identity.NAME, "Server").withStatic(PermissionChecker.POINTER, perm -> TriState.TRUE).build();
/*    */         }
/*    */       } 
/*    */     }
/* 79 */     return this.adventure$pointers;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public FabricAudiencesInternal controller() {
/* 84 */     return (FabricAudiencesInternal)FabricServerAudiences.of(this.field_14405);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\server\rcon\RconConsoleSourceMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */