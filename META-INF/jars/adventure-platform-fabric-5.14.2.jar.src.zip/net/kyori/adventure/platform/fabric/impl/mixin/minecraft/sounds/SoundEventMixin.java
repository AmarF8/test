/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.sounds;
/*    */ 
/*    */ import net.kyori.adventure.key.Key;
/*    */ import net.kyori.adventure.sound.Sound;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_3414;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_3414.class})
/*    */ public class SoundEventMixin
/*    */   implements Sound.Type
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private class_2960 field_14533;
/*    */   
/*    */   @NotNull
/*    */   public Key key() {
/* 43 */     return (Key)this.field_14533;
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\sounds\SoundEventMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */