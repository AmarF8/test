/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.world.entity;
/*    */ 
/*    */ import java.util.function.UnaryOperator;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import net.kyori.adventure.platform.fabric.EntityHoverEventSource;
/*    */ import net.kyori.adventure.sound.Sound;
/*    */ import net.kyori.adventure.text.event.HoverEvent;
/*    */ import net.minecraft.class_1275;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1299;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_5568;
/*    */ import net.minecraft.class_7924;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_1297.class})
/*    */ public abstract class EntityMixin
/*    */   implements Sound.Emitter, EntityHoverEventSource, class_1275, class_5568
/*    */ {
/*    */   @Shadow
/*    */   private class_1937 field_6002;
/*    */   
/*    */   @Shadow
/*    */   public abstract class_1299<?> shadow$method_5864();
/*    */   
/*    */   @NotNull
/*    */   public HoverEvent<HoverEvent.ShowEntity> asHoverEvent(@NotNull UnaryOperator<HoverEvent.ShowEntity> op) {
/* 54 */     class_2960 class_2960 = this.field_6002.method_30349().method_30530(class_7924.field_41266).method_10221(shadow$method_5864());
/*    */     
/* 56 */     HoverEvent.ShowEntity data = HoverEvent.ShowEntity.showEntity((Key)class_2960, method_5667(), method_5477().asComponent());
/* 57 */     return HoverEvent.showEntity(op.apply(data));
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\world\entity\EntityMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */