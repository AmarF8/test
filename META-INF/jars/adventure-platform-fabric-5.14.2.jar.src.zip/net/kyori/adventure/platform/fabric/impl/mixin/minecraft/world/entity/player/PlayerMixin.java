/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.world.entity.player;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import net.kyori.adventure.identity.Identity;
/*    */ import net.kyori.adventure.platform.fabric.CollectPointersCallback;
/*    */ import net.kyori.adventure.platform.fabric.IdentifiedAtRuntime;
/*    */ import net.kyori.adventure.platform.fabric.impl.PointerProviderBridge;
/*    */ import net.kyori.adventure.pointer.Pointered;
/*    */ import net.kyori.adventure.pointer.Pointers;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.minecraft.class_1299;
/*    */ import net.minecraft.class_1309;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1937;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_1657.class})
/*    */ public abstract class PlayerMixin
/*    */   extends class_1309
/*    */   implements IdentifiedAtRuntime, PointerProviderBridge
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private GameProfile field_7507;
/*    */   private Pointers adventure$pointers;
/*    */   
/*    */   protected PlayerMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
/* 53 */     super(entityType, level);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Identity identity() {
/* 58 */     return (Identity)this.field_7507;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Pointers adventure$pointers() {
/* 63 */     Pointers pointers = this.adventure$pointers;
/* 64 */     if (pointers == null) {
/* 65 */       synchronized (this) {
/* 66 */         if (this.adventure$pointers != null) {
/* 67 */           return this.adventure$pointers;
/*    */         }
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 73 */         Pointers.Builder builder = Pointers.builder().withDynamic(Identity.NAME, () -> shadow$method_7334().getName()).withDynamic(Identity.UUID, this::method_5667).withDynamic(Identity.DISPLAY_NAME, () -> method_5476().asComponent());
/*    */ 
/*    */         
/* 76 */         PlayerMixin playerMixin = this; if (playerMixin instanceof Pointered) { Pointered p = (Pointered)playerMixin;
/* 77 */           ((CollectPointersCallback)CollectPointersCallback.EVENT.invoker()).registerPointers(p, builder); }
/*    */ 
/*    */         
/* 80 */         this.adventure$pointers = pointers = (Pointers)builder.build();
/*    */       } 
/*    */     }
/*    */     
/* 84 */     return pointers;
/*    */   }
/*    */   
/*    */   @Shadow
/*    */   public abstract GameProfile shadow$method_7334();
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\world\entity\player\PlayerMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */