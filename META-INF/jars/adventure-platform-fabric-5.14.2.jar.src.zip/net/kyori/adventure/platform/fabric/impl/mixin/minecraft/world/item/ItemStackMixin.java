/*    */ package net.kyori.adventure.platform.fabric.impl.mixin.minecraft.world.item;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ import java.util.function.UnaryOperator;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import net.kyori.adventure.key.Keyed;
/*    */ import net.kyori.adventure.platform.fabric.impl.nbt.FabricDataComponentValue;
/*    */ import net.kyori.adventure.text.event.DataComponentValue;
/*    */ import net.kyori.adventure.text.event.HoverEvent;
/*    */ import net.kyori.adventure.text.event.HoverEventSource;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_7923;
/*    */ import net.minecraft.class_9326;
/*    */ import net.minecraft.class_9331;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_1799.class})
/*    */ public abstract class ItemStackMixin
/*    */   implements HoverEventSource<HoverEvent.ShowItem>
/*    */ {
/*    */   @Shadow
/*    */   public abstract int shadow$method_7947();
/*    */   
/*    */   @Shadow
/*    */   public abstract class_1792 shadow$method_7909();
/*    */   
/*    */   @Shadow
/*    */   public abstract class_9326 shadow$method_57380();
/*    */   
/*    */   @NotNull
/*    */   public HoverEvent<HoverEvent.ShowItem> asHoverEvent(@NotNull UnaryOperator<HoverEvent.ShowItem> op) {
/*    */     Map<Key, DataComponentValue> components;
/* 55 */     class_2960 class_2960 = class_7923.field_41178.method_10221(shadow$method_7909());
/*    */     
/* 57 */     class_9326 patch = shadow$method_57380();
/* 58 */     if (patch.method_57848()) {
/* 59 */       components = Collections.emptyMap();
/*    */     } else {
/* 61 */       components = new HashMap<>();
/* 62 */       for (Map.Entry<class_9331<?>, Optional<?>> entry : (Iterable<Map.Entry<class_9331<?>, Optional<?>>>)patch.method_57846()) {
/* 63 */         if (((class_9331)entry.getKey()).method_57877())
/*    */           continue; 
/* 65 */         class_2960 class_29601 = class_7923.field_49658.method_10221(entry.getKey());
/* 66 */         if (((Optional)entry.getValue()).isEmpty()) {
/* 67 */           components.put(class_29601, FabricDataComponentValue.Removed.INSTANCE); continue;
/*    */         } 
/* 69 */         FabricDataComponentValue.Present<?> holder = new FabricDataComponentValue.Present(((Optional)entry.getValue()).orElse(null), ((class_9331)entry.getKey()).method_57876());
/* 70 */         components.put(class_29601, holder);
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 75 */     HoverEvent.ShowItem item = HoverEvent.ShowItem.showItem((Keyed)class_2960, shadow$method_7947(), components);
/* 76 */     return HoverEvent.showItem(op.apply(item));
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\mixin\minecraft\world\item\ItemStackMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */