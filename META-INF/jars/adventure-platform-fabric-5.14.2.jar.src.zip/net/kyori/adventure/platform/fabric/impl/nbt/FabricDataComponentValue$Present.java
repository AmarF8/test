/*    */ package net.kyori.adventure.platform.fabric.impl.nbt;
/*    */ 
/*    */ import com.mojang.serialization.Codec;
/*    */ import com.mojang.serialization.DynamicOps;
/*    */ import java.util.function.Function;
/*    */ import net.kyori.adventure.nbt.api.BinaryTagHolder;
/*    */ import net.kyori.adventure.text.event.DataComponentValue;
/*    */ import net.minecraft.class_2509;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Present<T>
/*    */   extends Record
/*    */   implements FabricDataComponentValue, DataComponentValue.TagSerializable
/*    */ {
/*    */   @NotNull
/*    */   private final T value;
/*    */   @NotNull
/*    */   private final Codec<T> codec;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #42	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present;
/*    */     // Local variable type table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present<TT;>;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #42	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present;
/*    */     // Local variable type table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present<TT;>;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #42	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */     // Local variable type table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present<TT;>;
/*    */   }
/*    */   
/*    */   public Present(@NotNull T value, @NotNull Codec<T> codec) {
/* 42 */     this.value = value; this.codec = codec; } @NotNull public T value() { return this.value; } @NotNull public Codec<T> codec() { return this.codec; }
/*    */    @NotNull
/*    */   public BinaryTagHolder asBinaryTag() {
/* 45 */     return BinaryTagHolder.encode(this.codec
/* 46 */         .encodeStart((DynamicOps)class_2509.field_11560, this.value).getOrThrow(IllegalArgumentException::new), SNBT_CODEC);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\nbt\FabricDataComponentValue$Present.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */