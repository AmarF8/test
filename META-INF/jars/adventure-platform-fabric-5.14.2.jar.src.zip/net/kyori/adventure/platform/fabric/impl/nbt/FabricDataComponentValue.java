/*    */ package net.kyori.adventure.platform.fabric.impl.nbt;
/*    */ 
/*    */ import com.mojang.brigadier.StringReader;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import com.mojang.serialization.Codec;
/*    */ import com.mojang.serialization.DynamicOps;
/*    */ import java.util.function.Function;
/*    */ import net.kyori.adventure.nbt.api.BinaryTagHolder;
/*    */ import net.kyori.adventure.text.event.DataComponentValue;
/*    */ import net.kyori.adventure.util.Codec;
/*    */ import net.minecraft.class_2509;
/*    */ import net.minecraft.class_2520;
/*    */ import net.minecraft.class_2522;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface FabricDataComponentValue
/*    */   extends DataComponentValue
/*    */ {
/*    */   public static final Codec<class_2520, String, CommandSyntaxException, RuntimeException> SNBT_CODEC;
/*    */   
/*    */   static {
/* 37 */     SNBT_CODEC = Codec.codec(s -> (new class_2522(new StringReader(s))).method_10723(), class_2520::toString);
/*    */   }
/*    */   public static final class Present<T> extends Record implements FabricDataComponentValue, DataComponentValue.TagSerializable { @NotNull
/*    */     private final T value; @NotNull
/*    */     private final Codec<T> codec;
/* 42 */     public Present(@NotNull T value, @NotNull Codec<T> codec) { this.value = value; this.codec = codec; } public final String toString() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #42	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present;
/*    */       // Local variable type table:
/*    */       //   start	length	slot	name	signature
/* 42 */       //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present<TT;>; } @NotNull public T value() { return this.value; } public final int hashCode() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #42	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present;
/*    */       // Local variable type table:
/*    */       //   start	length	slot	name	signature
/*    */       //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present<TT;>; } public final boolean equals(Object o) { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #42	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present;
/*    */       //   0	8	1	o	Ljava/lang/Object;
/*    */       // Local variable type table:
/*    */       //   start	length	slot	name	signature
/* 42 */       //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/nbt/FabricDataComponentValue$Present<TT;>; } @NotNull public Codec<T> codec() { return this.codec; }
/*    */      @NotNull
/*    */     public BinaryTagHolder asBinaryTag() {
/* 45 */       return BinaryTagHolder.encode(this.codec
/* 46 */           .encodeStart((DynamicOps)class_2509.field_11560, this.value).getOrThrow(IllegalArgumentException::new), SNBT_CODEC);
/*    */     } }
/*    */ 
/*    */   
/*    */   public enum Removed
/*    */     implements FabricDataComponentValue, DataComponentValue.Removed
/*    */   {
/* 53 */     INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\nbt\FabricDataComponentValue.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */