/*     */ package net.kyori.adventure.platform.fabric.impl.nbt;
/*     */ 
/*     */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*     */ import java.io.IOException;
/*     */ import java.util.UUID;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.nbt.api.BinaryTagHolder;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.event.HoverEvent;
/*     */ import net.kyori.adventure.text.serializer.json.LegacyHoverEventSerializer;
/*     */ import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
/*     */ import net.kyori.adventure.util.Codec;
/*     */ import net.minecraft.class_2487;
/*     */ import net.minecraft.class_2520;
/*     */ import net.minecraft.class_2522;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NBTLegacyHoverEventSerializer
/*     */   implements LegacyHoverEventSerializer
/*     */ {
/*  42 */   public static final NBTLegacyHoverEventSerializer INSTANCE = new NBTLegacyHoverEventSerializer();
/*  43 */   private static final Codec<class_2487, String, CommandSyntaxException, RuntimeException> SNBT_CODEC = Codec.codec(class_2522::method_10718, class_2520::toString);
/*     */   
/*     */   static final String ITEM_TYPE = "id";
/*     */   
/*     */   static final String ITEM_COUNT = "Count";
/*     */   
/*     */   static final String ITEM_TAG = "tag";
/*     */   
/*     */   static final String ENTITY_NAME = "name";
/*     */   
/*     */   static final String ENTITY_TYPE = "type";
/*     */   
/*     */   static final String ENTITY_ID = "id";
/*     */   
/*     */   public HoverEvent.ShowItem deserializeShowItem(@NotNull Component input) throws IOException {
/*  58 */     String raw = PlainTextComponentSerializer.plainText().serialize(input);
/*     */     try {
/*  60 */       class_2487 contents = (class_2487)SNBT_CODEC.decode(raw);
/*  61 */       class_2487 tag = contents.method_10562("tag");
/*  62 */       return HoverEvent.ShowItem.showItem(
/*  63 */           Key.key(contents.method_10558("id")), 
/*  64 */           contents.method_10545("Count") ? contents.method_10571("Count") : 1, 
/*  65 */           tag.method_33133() ? null : BinaryTagHolder.encode(tag, SNBT_CODEC));
/*     */     }
/*  67 */     catch (CommandSyntaxException ex) {
/*  68 */       throw new IOException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public HoverEvent.ShowEntity deserializeShowEntity(@NotNull Component input, Codec.Decoder<Component, String, ? extends RuntimeException> componentCodec) throws IOException {
/*  74 */     String raw = PlainTextComponentSerializer.plainText().serialize(input);
/*     */     try {
/*  76 */       class_2487 contents = (class_2487)SNBT_CODEC.decode(raw);
/*  77 */       return HoverEvent.ShowEntity.showEntity(
/*  78 */           Key.key(contents.method_10558("type")), 
/*  79 */           UUID.fromString(contents.method_10558("id")), (Component)componentCodec
/*  80 */           .decode(contents.method_10558("name")));
/*     */     }
/*  82 */     catch (CommandSyntaxException ex) {
/*  83 */       throw new IOException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Component serializeShowItem(HoverEvent.ShowItem input) throws IOException {
/*  89 */     class_2487 tag = new class_2487();
/*  90 */     tag.method_10582("id", input.item().asString());
/*  91 */     tag.method_10567("Count", (byte)input.count());
/*  92 */     if (input.nbt() != null) {
/*     */       try {
/*  94 */         tag.method_10566("tag", (class_2520)input.nbt().get(SNBT_CODEC));
/*  95 */       } catch (CommandSyntaxException ex) {
/*  96 */         throw new IOException(ex);
/*     */       } 
/*     */     }
/*     */     
/* 100 */     return (Component)Component.text((String)SNBT_CODEC.encode(tag));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Component serializeShowEntity(HoverEvent.ShowEntity input, Codec.Encoder<Component, String, ? extends RuntimeException> componentCodec) throws IOException {
/* 105 */     class_2487 tag = new class_2487();
/* 106 */     tag.method_10582("id", input.id().toString());
/* 107 */     tag.method_10582("type", input.type().asString());
/* 108 */     if (input.name() != null) {
/* 109 */       tag.method_10582("name", (String)componentCodec.encode(input.name()));
/*     */     }
/* 111 */     return (Component)Component.text((String)SNBT_CODEC.encode(tag));
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\nbt\NBTLegacyHoverEventSerializer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */