/*    */ package net.kyori.adventure.platform.fabric.impl.server;
/*    */ 
/*    */ import net.kyori.adventure.audience.MessageType;
/*    */ import net.kyori.adventure.chat.ChatType;
/*    */ import net.kyori.adventure.chat.SignedMessage;
/*    */ import net.kyori.adventure.identity.Identity;
/*    */ import net.kyori.adventure.platform.fabric.impl.AdventureCommon;
/*    */ import net.kyori.adventure.platform.fabric.impl.ControlledAudience;
/*    */ import net.kyori.adventure.platform.fabric.impl.FabricAudiencesInternal;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.minecraft.class_2165;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class CommandSourceAudience
/*    */   implements ControlledAudience
/*    */ {
/*    */   private final class_2165 output;
/*    */   private final FabricAudiencesInternal serializer;
/*    */   
/*    */   CommandSourceAudience(class_2165 output, FabricAudiencesInternal serializer) {
/* 45 */     this.output = output;
/* 46 */     this.serializer = serializer;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public FabricAudiencesInternal controller() {
/* 51 */     return this.serializer;
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendMessage(@NotNull Component message) {
/* 56 */     this.output.method_43496(this.serializer.toNative(message));
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendMessage(@NotNull Component message, ChatType.Bound boundChatType) {
/* 61 */     this.output.method_43496(AdventureCommon.chatTypeToNative(boundChatType, this.serializer).method_44837(this.serializer.toNative(message)));
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendMessage(@NotNull SignedMessage signedMessage, ChatType.Bound boundChatType) {
/* 66 */     Component message = (signedMessage.unsignedContent() != null) ? signedMessage.unsignedContent() : (Component)Component.text(signedMessage.message());
/* 67 */     this.output.method_43496(AdventureCommon.chatTypeToNative(boundChatType, this.serializer).method_44837(this.serializer.toNative(message)));
/*    */   }
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public void sendMessage(Identity source, Component text, MessageType type) {
/* 73 */     this.output.method_43496(this.serializer.toNative(text));
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendActionBar(@NotNull Component message) {
/* 78 */     sendMessage(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\server\CommandSourceAudience.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */