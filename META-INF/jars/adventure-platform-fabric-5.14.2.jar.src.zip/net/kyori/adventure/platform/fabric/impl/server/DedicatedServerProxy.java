/*    */ package net.kyori.adventure.platform.fabric.impl.server;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import net.kyori.adventure.platform.fabric.impl.NonWrappingComponentSerializer;
/*    */ import net.kyori.adventure.platform.fabric.impl.SidedProxy;
/*    */ import net.kyori.adventure.platform.fabric.impl.WrappedComponent;
/*    */ import net.kyori.adventure.pointer.Pointered;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.kyori.adventure.text.flattener.ComponentFlattener;
/*    */ import net.kyori.adventure.text.renderer.ComponentRenderer;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DedicatedServerProxy
/*    */   implements SidedProxy
/*    */ {
/*    */   public void contributeFlattenerElements(ComponentFlattener.Builder flattenerBuilder) {}
/*    */   
/*    */   @NotNull
/*    */   public WrappedComponent createWrappedComponent(@NotNull Component wrapped, @Nullable Function<Pointered, ?> partition, @Nullable ComponentRenderer<Pointered> renderer, @Nullable NonWrappingComponentSerializer nonWrappingSerializer) {
/* 50 */     return new WrappedComponent(wrapped, partition, renderer, nonWrappingSerializer);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\server\DedicatedServerProxy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */