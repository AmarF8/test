/*     */ package net.kyori.adventure.platform.fabric.impl.server;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import net.kyori.adventure.platform.AudienceProvider;
/*     */ import net.kyori.adventure.platform.fabric.FabricServerAudiences;
/*     */ import net.kyori.adventure.platform.fabric.impl.AdventureCommon;
/*     */ import net.kyori.adventure.pointer.Pointered;
/*     */ import net.kyori.adventure.text.renderer.ComponentRenderer;
/*     */ import net.kyori.adventure.translation.GlobalTranslator;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Builder
/*     */   implements FabricServerAudiences.Builder
/*     */ {
/*     */   private final MinecraftServer server;
/*     */   private Function<Pointered, ?> partition;
/*     */   private ComponentRenderer<Pointered> renderer;
/*     */   
/*     */   public Builder(MinecraftServer server) {
/* 212 */     this.server = server;
/* 213 */     componentRenderer(AdventureCommon.localePartition(), (ComponentRenderer)GlobalTranslator.renderer());
/*     */   }
/*     */ 
/*     */   
/*     */   public FabricServerAudiences.Builder componentRenderer(@NotNull ComponentRenderer<Pointered> componentRenderer) {
/* 218 */     this.renderer = Objects.<ComponentRenderer<Pointered>>requireNonNull(componentRenderer, "componentRenderer");
/* 219 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FabricServerAudiences.Builder partition(@NotNull Function<Pointered, ?> partitionFunction) {
/* 224 */     this.partition = Objects.<Function<Pointered, ?>>requireNonNull(partitionFunction, "partitionFunction");
/* 225 */     return this;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public FabricServerAudiencesImpl build() {
/* 230 */     return new FabricServerAudiencesImpl(this.server, this.partition, this.renderer);
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\server\FabricServerAudiencesImpl$Builder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */