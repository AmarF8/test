/*     */ package net.kyori.adventure.platform.fabric.impl.server;
/*     */ 
/*     */ import com.google.common.collect.Iterables;
/*     */ import java.util.Collections;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import net.kyori.adventure.audience.Audience;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.platform.AudienceProvider;
/*     */ import net.kyori.adventure.platform.fabric.AdventureCommandSourceStack;
/*     */ import net.kyori.adventure.platform.fabric.FabricAudiences;
/*     */ import net.kyori.adventure.platform.fabric.FabricServerAudiences;
/*     */ import net.kyori.adventure.platform.fabric.impl.AdventureCommandSourceStackInternal;
/*     */ import net.kyori.adventure.platform.fabric.impl.AdventureCommon;
/*     */ import net.kyori.adventure.platform.fabric.impl.FabricAudiencesInternal;
/*     */ import net.kyori.adventure.platform.fabric.impl.NonWrappingComponentSerializer;
/*     */ import net.kyori.adventure.pointer.Pointered;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.flattener.ComponentFlattener;
/*     */ import net.kyori.adventure.text.renderer.ComponentRenderer;
/*     */ import net.kyori.adventure.translation.GlobalTranslator;
/*     */ import net.minecraft.class_2165;
/*     */ import net.minecraft.class_2168;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_3218;
/*     */ import net.minecraft.class_3222;
/*     */ import net.minecraft.class_5321;
/*     */ import net.minecraft.class_5455;
/*     */ import net.minecraft.class_7924;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FabricServerAudiencesImpl
/*     */   implements FabricServerAudiences, FabricAudiencesInternal
/*     */ {
/*  64 */   private static final Set<FabricServerAudiencesImpl> INSTANCES = Collections.newSetFromMap(new WeakHashMap<>());
/*     */   private final MinecraftServer server;
/*     */   private final NonWrappingComponentSerializer nonWrappingSerializer;
/*     */   private final Function<Pointered, ?> partition;
/*     */   private final ComponentRenderer<Pointered> renderer;
/*     */   final ServerBossBarListener bossBars;
/*     */   
/*     */   public static void forEachInstance(Consumer<FabricServerAudiencesImpl> actor) {
/*  72 */     synchronized (INSTANCES) {
/*  73 */       for (FabricServerAudiencesImpl instance : INSTANCES) {
/*  74 */         actor.accept(instance);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FabricServerAudiencesImpl(MinecraftServer server, Function<Pointered, ?> partition, ComponentRenderer<Pointered> renderer) {
/*  86 */     this.server = server;
/*  87 */     this.nonWrappingSerializer = new NonWrappingComponentSerializer(this::registryAccess);
/*  88 */     this.partition = partition;
/*  89 */     this.renderer = renderer;
/*  90 */     this.bossBars = new ServerBossBarListener((FabricAudiences)this);
/*  91 */     synchronized (INSTANCES) {
/*  92 */       INSTANCES.add(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public MinecraftServer server() {
/*  97 */     return this.server;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Audience all() {
/* 102 */     return Audience.audience(new Audience[] { console(), players() });
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Audience console() {
/* 107 */     return audience((class_2165)this.server);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Audience players() {
/* 112 */     return (Audience)Audience.audience(audiences(this.server.method_3760().method_14571()));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Audience player(@NotNull UUID playerId) {
/* 117 */     class_3222 player = this.server.method_3760().method_14602(playerId);
/* 118 */     return (player != null) ? audience((class_2165)player) : Audience.empty();
/*     */   }
/*     */   
/*     */   private Iterable<Audience> audiences(Iterable<? extends class_3222> players) {
/* 122 */     return Iterables.transform(players, this::audience);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Audience permission(@NotNull String permission) {
/* 127 */     return Audience.empty();
/*     */   }
/*     */   @NotNull
/*     */   public AdventureCommandSourceStack audience(@NotNull class_2168 source) {
/*     */     AdventureCommandSourceStackInternal internal;
/* 132 */     if (source instanceof AdventureCommandSourceStackInternal) { internal = (AdventureCommandSourceStackInternal)source; }
/* 133 */     else { throw new IllegalArgumentException("The AdventureCommandSource mixin failed!"); }
/*     */ 
/*     */     
/* 136 */     return internal.adventure$audience(audience(internal.adventure$source()), this);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Audience audience(@NotNull class_2165 source) {
/* 141 */     if (source instanceof RenderableAudience) { RenderableAudience renderable = (RenderableAudience)source;
/* 142 */       return renderable.renderUsing(this); }
/* 143 */      if (source instanceof Audience) { Audience audience = (Audience)source;
/*     */       
/* 145 */       return audience; }
/*     */     
/* 147 */     return (Audience)new CommandSourceAudience(source, this);
/*     */   }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public Audience audience(@NotNull Iterable<class_3222> players) {
/* 153 */     return (Audience)Audience.audience(audiences(players));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Audience world(@NotNull Key worldId) {
/* 158 */     class_3218 level = this.server.method_3847(class_5321.method_29179(class_7924.field_41223, 
/* 159 */           FabricAudiences.toNative(Objects.<Key>requireNonNull(worldId, "worldId"))));
/* 160 */     if (level != null) {
/* 161 */       return audience(level.method_18456());
/*     */     }
/* 163 */     return Audience.empty();
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Audience server(@NotNull String serverName) {
/* 168 */     return Audience.empty();
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public ComponentFlattener flattener() {
/* 173 */     return AdventureCommon.FLATTENER;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public ComponentRenderer<Pointered> renderer() {
/* 178 */     return this.renderer;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_2561 toNative(@NotNull Component adventure) {
/* 183 */     if (adventure == Component.empty()) return (class_2561)class_2561.method_43473();
/*     */     
/* 185 */     return (class_2561)AdventureCommon.SIDE_PROXY.createWrappedComponent(Objects.<Component>requireNonNull(adventure, "adventure"), this.partition, this.renderer, this.nonWrappingSerializer);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Component toAdventure(class_2561 vanilla) {
/* 190 */     return this.nonWrappingSerializer.deserialize(vanilla);
/*     */   }
/*     */   
/*     */   public ServerBossBarListener bossBars() {
/* 194 */     return this.bossBars;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public class_5455 registryAccess() {
/* 203 */     return (class_5455)this.server.method_30611();
/*     */   }
/*     */   
/*     */   public static final class Builder implements FabricServerAudiences.Builder {
/*     */     private final MinecraftServer server;
/*     */     private Function<Pointered, ?> partition;
/*     */     private ComponentRenderer<Pointered> renderer;
/*     */     
/*     */     public Builder(MinecraftServer server) {
/* 212 */       this.server = server;
/* 213 */       componentRenderer(AdventureCommon.localePartition(), (ComponentRenderer)GlobalTranslator.renderer());
/*     */     }
/*     */ 
/*     */     
/*     */     public FabricServerAudiences.Builder componentRenderer(@NotNull ComponentRenderer<Pointered> componentRenderer) {
/* 218 */       this.renderer = Objects.<ComponentRenderer<Pointered>>requireNonNull(componentRenderer, "componentRenderer");
/* 219 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public FabricServerAudiences.Builder partition(@NotNull Function<Pointered, ?> partitionFunction) {
/* 224 */       this.partition = Objects.<Function<Pointered, ?>>requireNonNull(partitionFunction, "partitionFunction");
/* 225 */       return this;
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public FabricServerAudiencesImpl build() {
/* 230 */       return new FabricServerAudiencesImpl(this.server, this.partition, this.renderer);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\server\FabricServerAudiencesImpl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */