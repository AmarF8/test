package net.kyori.adventure.platform.fabric.impl.server;

import net.kyori.adventure.pointer.Pointered;
import org.jetbrains.annotations.Nullable;

public interface FriendlyByteBufBridge {
  void adventure$data(@Nullable Pointered paramPointered);
  
  Pointered adventure$data();
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\server\FriendlyByteBufBridge.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */