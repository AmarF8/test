package net.kyori.adventure.platform.fabric.impl.server;

import net.kyori.adventure.platform.fabric.FabricServerAudiences;

public interface MinecraftServerBridge {
  FabricServerAudiences adventure$globalProvider();
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\server\MinecraftServerBridge.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */