/*    */ package net.kyori.adventure.platform.fabric.impl.server;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import net.kyori.adventure.audience.MessageType;
/*    */ import net.kyori.adventure.chat.ChatType;
/*    */ import net.kyori.adventure.identity.Identity;
/*    */ import net.kyori.adventure.platform.fabric.impl.AdventureCommon;
/*    */ import net.kyori.adventure.platform.fabric.impl.ControlledAudience;
/*    */ import net.kyori.adventure.platform.fabric.impl.FabricAudiencesInternal;
/*    */ import net.kyori.adventure.pointer.Pointered;
/*    */ import net.kyori.adventure.pointer.Pointers;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PlainAudience
/*    */   implements ControlledAudience
/*    */ {
/*    */   private final FabricAudiencesInternal controller;
/*    */   private final Pointered source;
/*    */   private final Consumer<String> plainOutput;
/*    */   
/*    */   public PlainAudience(FabricAudiencesInternal controller, Pointered source, Consumer<String> plainOutput) {
/* 45 */     this.controller = controller;
/* 46 */     this.source = source;
/* 47 */     this.plainOutput = plainOutput;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public FabricAudiencesInternal controller() {
/* 52 */     return this.controller;
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendMessage(@NotNull Component message) {
/* 57 */     this.plainOutput.accept(PlainTextComponentSerializer.plainText().serialize(message));
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendMessage(@NotNull Component message, ChatType.Bound boundChatType) {
/* 62 */     this.plainOutput.accept(AdventureCommon.chatTypeToNative(boundChatType, this.controller).method_44837(this.controller.toNative(message)).getString());
/*    */   }
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public void sendMessage(Identity source, Component text, MessageType type) {
/* 68 */     sendMessage(text);
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendActionBar(@NotNull Component message) {
/* 73 */     sendMessage(message);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Pointers pointers() {
/* 78 */     return this.source.pointers();
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\server\PlainAudience.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */