package net.kyori.adventure.platform.fabric.impl.server;

import net.kyori.adventure.audience.Audience;

public interface RenderableAudience extends Audience {
  Audience renderUsing(FabricServerAudiencesImpl paramFabricServerAudiencesImpl);
  
  void refresh();
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\server\RenderableAudience.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */