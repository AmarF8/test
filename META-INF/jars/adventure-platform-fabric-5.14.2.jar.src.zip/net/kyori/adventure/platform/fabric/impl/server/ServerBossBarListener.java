/*     */ package net.kyori.adventure.platform.fabric.impl.server;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import net.kyori.adventure.bossbar.BossBar;
/*     */ import net.kyori.adventure.platform.fabric.FabricAudiences;
/*     */ import net.kyori.adventure.platform.fabric.impl.AbstractBossBarListener;
/*     */ import net.minecraft.class_1259;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2629;
/*     */ import net.minecraft.class_3213;
/*     */ import net.minecraft.class_3222;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerBossBarListener
/*     */   extends AbstractBossBarListener<class_3213>
/*     */ {
/*     */   public ServerBossBarListener(FabricAudiences controller) {
/*  42 */     super(controller);
/*     */   }
/*     */   
/*     */   public void subscribe(class_3222 player, BossBar bar) {
/*  46 */     ((class_3213)minecraftCreating(Objects.<BossBar>requireNonNull(bar, "bar"))).method_14088(Objects.<class_3222>requireNonNull(player, "player"));
/*     */   }
/*     */   
/*     */   public void subscribeAll(Collection<class_3222> players, BossBar bar) {
/*  50 */     ((ServerBossEventBridge)minecraftCreating(Objects.<BossBar>requireNonNull(bar, "bar"))).adventure$addAll(players);
/*     */   }
/*     */   
/*     */   public void unsubscribe(class_3222 player, BossBar bar) {
/*  54 */     this.bars.computeIfPresent(bar, (key, old) -> {
/*     */           old.method_14089(player);
/*     */           if (old.method_14092().isEmpty()) {
/*     */             key.removeListener((BossBar.Listener)this);
/*     */             return null;
/*     */           } 
/*     */           return old;
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void unsubscribeAll(Collection<class_3222> players, BossBar bar) {
/*  66 */     this.bars.computeIfPresent(bar, (key, old) -> {
/*     */           ((ServerBossEventBridge)old).adventure$removeAll(players);
/*     */           if (old.method_14092().isEmpty()) {
/*     */             key.removeListener((BossBar.Listener)this);
/*     */             return null;
/*     */           } 
/*     */           return old;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replacePlayer(class_3222 old, class_3222 newPlayer) {
/*  87 */     for (class_3213 bar : this.bars.values()) {
/*  88 */       ((ServerBossEventBridge)bar).adventure$replaceSubscriber(old, newPlayer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refreshTitles(class_3222 player) {
/*  98 */     for (class_3213 bar : this.bars.values()) {
/*  99 */       if (bar.method_14092().contains(player)) {
/* 100 */         player.field_13987.method_14364((class_2596)class_2629.method_34096((class_1259)bar));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsubscribeFromAll(class_3222 player) {
/* 111 */     for (Iterator<Map.Entry<BossBar, class_3213>> it = this.bars.entrySet().iterator(); it.hasNext(); ) {
/* 112 */       class_3213 bar = (class_3213)((Map.Entry)it.next()).getValue();
/* 113 */       if (bar.method_14092().contains(player)) {
/* 114 */         bar.method_14089(player);
/* 115 */         if (bar.method_14092().isEmpty()) {
/* 116 */           it.remove();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class_3213 newBar(@NotNull class_2561 title, class_1259.class_1260 color, class_1259.class_1261 style, float progress) {
/* 129 */     class_3213 event = new class_3213(title, color, style);
/* 130 */     event.method_5408(progress);
/* 131 */     return event;
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\server\ServerBossBarListener.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */