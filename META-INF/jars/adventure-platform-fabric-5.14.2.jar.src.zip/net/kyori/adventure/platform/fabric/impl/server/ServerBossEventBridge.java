package net.kyori.adventure.platform.fabric.impl.server;

import java.util.Collection;
import net.minecraft.class_3222;

public interface ServerBossEventBridge {
  void adventure$addAll(Collection<class_3222> paramCollection);
  
  void adventure$removeAll(Collection<class_3222> paramCollection);
  
  void adventure$replaceSubscriber(class_3222 paramclass_32221, class_3222 paramclass_32222);
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\server\ServerBossEventBridge.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */