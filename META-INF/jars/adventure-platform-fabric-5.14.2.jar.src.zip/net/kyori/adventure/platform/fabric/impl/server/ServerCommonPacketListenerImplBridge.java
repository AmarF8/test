/*    */ package net.kyori.adventure.platform.fabric.impl.server;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.kyori.adventure.resource.ResourcePackCallback;
/*    */ import net.minecraft.class_2535;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public interface ServerCommonPacketListenerImplBridge {
/*    */   void adventure$bridge$registerPackCallback(@NotNull UUID paramUUID, @NotNull FabricServerAudiencesImpl paramFabricServerAudiencesImpl, @NotNull ResourcePackCallback paramResourcePackCallback);
/*    */   
/*    */   class_2535 adventure$connection();
/*    */   
/*    */   public static final class PackCallbackState extends Record {
/*    */     @NotNull
/*    */     private final FabricServerAudiencesImpl controller;
/*    */     @NotNull
/*    */     private final ResourcePackCallback cb;
/*    */     
/*    */     public final String toString() {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Lnet/kyori/adventure/platform/fabric/impl/server/ServerCommonPacketListenerImplBridge$PackCallbackState;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #33	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/server/ServerCommonPacketListenerImplBridge$PackCallbackState;
/*    */     }
/*    */     
/*    */     public final int hashCode() {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Lnet/kyori/adventure/platform/fabric/impl/server/ServerCommonPacketListenerImplBridge$PackCallbackState;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #33	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lnet/kyori/adventure/platform/fabric/impl/server/ServerCommonPacketListenerImplBridge$PackCallbackState;
/*    */     }
/*    */     
/*    */     public final boolean equals(Object o) {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Lnet/kyori/adventure/platform/fabric/impl/server/ServerCommonPacketListenerImplBridge$PackCallbackState;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #33	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Lnet/kyori/adventure/platform/fabric/impl/server/ServerCommonPacketListenerImplBridge$PackCallbackState;
/*    */       //   0	8	1	o	Ljava/lang/Object;
/*    */     }
/*    */     
/*    */     public PackCallbackState(@NotNull FabricServerAudiencesImpl controller, @NotNull ResourcePackCallback cb)
/*    */     {
/* 33 */       this.controller = controller; this.cb = cb; } @NotNull public FabricServerAudiencesImpl controller() { return this.controller; } @NotNull public ResourcePackCallback cb() { return this.cb; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\server\ServerCommonPacketListenerImplBridge.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */