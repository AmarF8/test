/*     */ package net.kyori.adventure.platform.fabric.impl.server;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.UUID;
/*     */ import net.kyori.adventure.audience.MessageType;
/*     */ import net.kyori.adventure.bossbar.BossBar;
/*     */ import net.kyori.adventure.chat.ChatType;
/*     */ import net.kyori.adventure.chat.SignedMessage;
/*     */ import net.kyori.adventure.identity.Identity;
/*     */ import net.kyori.adventure.inventory.Book;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.platform.fabric.FabricAudiences;
/*     */ import net.kyori.adventure.platform.fabric.impl.AdventureCommon;
/*     */ import net.kyori.adventure.platform.fabric.impl.ControlledAudience;
/*     */ import net.kyori.adventure.platform.fabric.impl.FabricAudiencesInternal;
/*     */ import net.kyori.adventure.platform.fabric.impl.GameEnums;
/*     */ import net.kyori.adventure.platform.fabric.impl.PointerProviderBridge;
/*     */ import net.kyori.adventure.platform.fabric.impl.accessor.minecraft.network.ServerGamePacketListenerImplAccess;
/*     */ import net.kyori.adventure.platform.fabric.impl.accessor.minecraft.world.level.LevelAccess;
/*     */ import net.kyori.adventure.pointer.Pointers;
/*     */ import net.kyori.adventure.resource.ResourcePackCallback;
/*     */ import net.kyori.adventure.resource.ResourcePackInfo;
/*     */ import net.kyori.adventure.resource.ResourcePackRequest;
/*     */ import net.kyori.adventure.sound.Sound;
/*     */ import net.kyori.adventure.sound.SoundStop;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
/*     */ import net.kyori.adventure.title.Title;
/*     */ import net.kyori.adventure.title.TitlePart;
/*     */ import net.kyori.adventure.util.MonkeyBars;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1659;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1935;
/*     */ import net.minecraft.class_2378;
/*     */ import net.minecraft.class_2556;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2653;
/*     */ import net.minecraft.class_2720;
/*     */ import net.minecraft.class_2765;
/*     */ import net.minecraft.class_2767;
/*     */ import net.minecraft.class_2770;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_3222;
/*     */ import net.minecraft.class_3414;
/*     */ import net.minecraft.class_3419;
/*     */ import net.minecraft.class_5321;
/*     */ import net.minecraft.class_5888;
/*     */ import net.minecraft.class_5903;
/*     */ import net.minecraft.class_5904;
/*     */ import net.minecraft.class_5905;
/*     */ import net.minecraft.class_6880;
/*     */ import net.minecraft.class_7469;
/*     */ import net.minecraft.class_7471;
/*     */ import net.minecraft.class_7604;
/*     */ import net.minecraft.class_7617;
/*     */ import net.minecraft.class_7924;
/*     */ import net.minecraft.class_8042;
/*     */ import net.minecraft.class_8705;
/*     */ import net.minecraft.class_9053;
/*     */ import net.minecraft.class_9262;
/*     */ import net.minecraft.class_9302;
/*     */ import net.minecraft.class_9326;
/*     */ import net.minecraft.class_9334;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ServerPlayerAudience
/*     */   implements ControlledAudience
/*     */ {
/*     */   private final class_3222 player;
/*     */   private final FabricServerAudiencesImpl controller;
/*     */   
/*     */   public ServerPlayerAudience(class_3222 player, FabricServerAudiencesImpl controller) {
/* 101 */     this.player = player;
/* 102 */     this.controller = controller;
/*     */   }
/*     */   
/*     */   void sendPacket(class_2596<? extends class_8705> packet) {
/* 106 */     this.player.field_13987.method_14364(packet);
/*     */   }
/*     */ 
/*     */   
/*     */   void sendBundle(List<? extends class_2596<? extends class_8705>> packet) {
/* 111 */     this.player.field_13987.method_14364((class_2596)new class_8042(packet));
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendMessage(@NotNull Component message) {
/* 116 */     this.player.method_43496(this.controller.toNative(message));
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void sendMessage(Identity source, Component text, MessageType type) {
/* 122 */     switch (this.player.method_14238()) { default: throw new MatchException(null, null);
/*     */       case field_7538: 
/* 124 */       case field_7539: if (type == MessageType.SYSTEM);
/* 125 */       case field_7536: break; }  boolean shouldSend = false;
/*     */ 
/*     */     
/* 128 */     if (shouldSend) {
/* 129 */       this.player.method_43496(this.controller.toNative(text));
/*     */     }
/*     */   }
/*     */   
/*     */   private class_2556.class_7602 toMc(ChatType.Bound adv) {
/* 134 */     return AdventureCommon.chatTypeToNative(adv, this.controller);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendMessage(@NotNull Component message, ChatType.Bound boundChatType) {
/* 140 */     class_7604.class_7606 class_7606 = new class_7604.class_7606(this.controller.toNative(message));
/*     */     
/* 142 */     this.player.method_43505((class_7604)class_7606, false, toMc(boundChatType));
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendMessage(@NotNull SignedMessage signedMessage, ChatType.Bound boundChatType) {
/* 147 */     SignedMessage signedMessage1 = signedMessage; if (signedMessage1 instanceof class_7471) { class_7471 pcm = (class_7471)signedMessage1;
/* 148 */       if (pcm.method_46293()) {
/* 149 */         this.player.method_43505((class_7604)new class_7604.class_7606(pcm.method_46291()), false, toMc(boundChatType));
/*     */       } else {
/* 151 */         this.player.method_43505((class_7604)new class_7604.class_7607(pcm), false, toMc(boundChatType));
/*     */       }  }
/*     */     else
/* 154 */     { sendMessage((Component)Objects.requireNonNullElse(signedMessage.unsignedContent(), Component.text(signedMessage.message())), boundChatType); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteMessage(SignedMessage.Signature signature) {
/* 160 */     sendPacket((class_2596<? extends class_8705>)new class_7617(((class_7469)signature).method_46277(((ServerGamePacketListenerImplAccess)this.player.field_13987).accessor$messageSignatureCache())));
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendActionBar(@NotNull Component message) {
/* 165 */     this.player.method_43502(this.controller.toNative(message), true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void showBossBar(@NotNull BossBar bar) {
/* 170 */     FabricServerAudiencesImpl.forEachInstance(controller -> {
/*     */           if (controller != this.controller) {
/*     */             controller.bossBars.unsubscribe(this.player, bar);
/*     */           }
/*     */         });
/* 175 */     this.controller.bossBars.subscribe(this.player, bar);
/*     */   }
/*     */ 
/*     */   
/*     */   public void hideBossBar(@NotNull BossBar bar) {
/* 180 */     FabricServerAudiencesImpl.forEachInstance(controller -> controller.bossBars.unsubscribe(this.player, bar));
/*     */   }
/*     */   
/*     */   private long seed(@NotNull Sound sound) {
/* 184 */     if (sound.seed().isPresent()) {
/* 185 */       return sound.seed().getAsLong();
/*     */     }
/* 187 */     return ((LevelAccess)this.player.method_37908()).accessor$threadSafeRandom().method_43055();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class_6880<class_3414> eventHolder(@NotNull Sound sound) {
/* 193 */     class_2378<class_3414> soundEventRegistry = this.controller.registryAccess().method_30530(class_7924.field_41225);
/* 194 */     class_2960 soundKey = FabricAudiences.toNative(sound.name());
/*     */     
/* 196 */     Optional<class_6880.class_6883<class_3414>> eventOptional = soundEventRegistry.method_40264(class_5321.method_29179(class_7924.field_41225, soundKey));
/* 197 */     return eventOptional.isPresent() ? (class_6880<class_3414>)eventOptional.get() : class_6880.method_40223(class_3414.method_47908(soundKey));
/*     */   }
/*     */ 
/*     */   
/*     */   public void playSound(@NotNull Sound sound) {
/* 202 */     playSound(sound, this.player.method_23317(), this.player.method_23318(), this.player.method_23321());
/*     */   }
/*     */ 
/*     */   
/*     */   public void playSound(@NotNull Sound sound, double x, double y, double z) {
/* 207 */     sendPacket((class_2596<? extends class_8705>)new class_2767(
/* 208 */           eventHolder(sound), (class_3419)GameEnums.SOUND_SOURCE
/* 209 */           .toMinecraft(sound.source()), x, y, z, sound
/*     */ 
/*     */ 
/*     */           
/* 213 */           .volume(), sound
/* 214 */           .pitch(), 
/* 215 */           seed(sound)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void playSound(@NotNull Sound sound, Sound.Emitter emitter) {
/*     */     class_1297 targetEntity;
/* 222 */     if (emitter == Sound.Emitter.self()) {
/* 223 */       class_3222 class_32221 = this.player;
/* 224 */     } else if (emitter instanceof class_1297) {
/* 225 */       targetEntity = (class_1297)emitter;
/*     */     } else {
/* 227 */       throw new IllegalArgumentException("Provided emitter '" + String.valueOf(emitter) + "' was not Sound.Emitter.self() or an Entity");
/*     */     } 
/*     */     
/* 230 */     if (!this.player.method_37908().equals(targetEntity.method_37908())) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 235 */     sendPacket((class_2596<? extends class_8705>)new class_2765(
/* 236 */           eventHolder(sound), (class_3419)GameEnums.SOUND_SOURCE
/* 237 */           .toMinecraft(sound.source()), targetEntity, sound
/*     */           
/* 239 */           .volume(), sound
/* 240 */           .pitch(), 
/* 241 */           seed(sound)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopSound(@NotNull SoundStop stop) {
/* 247 */     Key sound = stop.sound();
/* 248 */     Sound.Source src = stop.source();
/* 249 */     class_3419 cat = (src == null) ? null : (class_3419)GameEnums.SOUND_SOURCE.toMinecraft(src);
/* 250 */     sendPacket((class_2596<? extends class_8705>)new class_2770((sound == null) ? null : FabricAudiences.toNative(sound), cat));
/*     */   }
/*     */ 
/*     */   
/*     */   public void openBook(@NotNull Book book) {
/* 255 */     if (book.pages().size() > 100) {
/* 256 */       throw new IllegalArgumentException("Book provided had " + book.pages().size() + " pages, but is only allowed a maximum of 100");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     Objects.requireNonNull(this.controller);
/*     */     
/* 265 */     class_9302 content = new class_9302(class_9262.method_57137(validateField(adventure$plain(book.title()), 32, "title")), adventure$plain(book.author()), 0, book.pages().stream().map(this.controller::toNative).map(class_9262::method_57137).toList(), true);
/*     */ 
/*     */ 
/*     */     
/* 269 */     class_1799 bookStack = new class_1799((class_1935)class_1802.field_8360, 1);
/* 270 */     bookStack.method_57366(
/* 271 */         class_9326.method_57841()
/* 272 */         .method_57854(class_9334.field_49606, content)
/* 273 */         .method_57852());
/*     */ 
/*     */     
/* 276 */     class_1799 previous = this.player.method_31548().method_7391();
/* 277 */     sendPacket((class_2596<? extends class_8705>)new class_2653(-2, this.player.field_7512.method_37421(), (this.player.method_31548()).field_7545, bookStack));
/* 278 */     this.player.method_7315(bookStack, class_1268.field_5808);
/* 279 */     sendPacket((class_2596<? extends class_8705>)new class_2653(-2, this.player.field_7512.method_37421(), (this.player.method_31548()).field_7545, previous));
/*     */   }
/*     */   
/*     */   private static String validateField(String content, int length, String name) {
/* 283 */     if (content == null) {
/* 284 */       return content;
/*     */     }
/*     */     
/* 287 */     int actual = content.length();
/* 288 */     if (actual > length) {
/* 289 */       throw new IllegalArgumentException("Field '" + name + "' has a maximum length of " + length + " but was passed '" + content + "', which was " + actual + " characters long.");
/*     */     }
/* 291 */     return content;
/*     */   }
/*     */   
/*     */   private String adventure$plain(@NotNull Component component) {
/* 295 */     return PlainTextComponentSerializer.plainText().serialize(this.controller.renderer().render(component, this));
/*     */   }
/*     */ 
/*     */   
/*     */   public void showTitle(@NotNull Title title) {
/* 300 */     if (title.subtitle() != Component.empty()) {
/* 301 */       sendPacket((class_2596<? extends class_8705>)new class_5903(this.controller.toNative(title.subtitle())));
/*     */     }
/*     */     
/* 304 */     Title.Times times = title.times();
/* 305 */     if (times != null) {
/* 306 */       int fadeIn = ticks(times.fadeIn());
/* 307 */       int fadeOut = ticks(times.fadeOut());
/* 308 */       int dwell = ticks(times.stay());
/* 309 */       if (fadeIn != -1 || fadeOut != -1 || dwell != -1) {
/* 310 */         sendPacket((class_2596<? extends class_8705>)new class_5905(fadeIn, dwell, fadeOut));
/*     */       }
/*     */     } 
/*     */     
/* 314 */     if (title.title() != Component.empty()) {
/* 315 */       sendPacket((class_2596<? extends class_8705>)new class_5904(this.controller.toNative(title.title())));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> void sendTitlePart(@NotNull TitlePart<T> part, @NotNull T value) {
/* 321 */     Objects.requireNonNull(value, "value");
/* 322 */     if (part == TitlePart.TITLE) {
/* 323 */       sendPacket((class_2596<? extends class_8705>)new class_5904(this.controller.toNative((Component)value)));
/* 324 */     } else if (part == TitlePart.SUBTITLE) {
/* 325 */       sendPacket((class_2596<? extends class_8705>)new class_5903(this.controller.toNative((Component)value)));
/* 326 */     } else if (part == TitlePart.TIMES) {
/* 327 */       Title.Times times = (Title.Times)value;
/* 328 */       int fadeIn = ticks(times.fadeIn());
/* 329 */       int fadeOut = ticks(times.fadeOut());
/* 330 */       int dwell = ticks(times.stay());
/* 331 */       if (fadeIn != -1 || fadeOut != -1 || dwell != -1) {
/* 332 */         sendPacket((class_2596<? extends class_8705>)new class_5905(fadeIn, dwell, fadeOut));
/*     */       }
/*     */     } else {
/* 335 */       throw new IllegalArgumentException("Unknown TitlePart '" + String.valueOf(part) + "'");
/*     */     } 
/*     */   }
/*     */   
/*     */   static int ticks(@NotNull Duration duration) {
/* 340 */     return (duration.getSeconds() == -1L) ? -1 : (int)(duration.toMillis() / 50L);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearTitle() {
/* 345 */     sendPacket((class_2596<? extends class_8705>)new class_5888(false));
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetTitle() {
/* 350 */     sendPacket((class_2596<? extends class_8705>)new class_5888(true));
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendPlayerListHeader(@NotNull Component header) {
/* 355 */     Objects.requireNonNull(header, "header");
/* 356 */     ((ServerPlayerBridge)this.player).bridge$updateTabList(this.controller.toNative(header), null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendPlayerListFooter(@NotNull Component footer) {
/* 361 */     Objects.requireNonNull(footer, "footer");
/* 362 */     ((ServerPlayerBridge)this.player).bridge$updateTabList(null, this.controller.toNative(footer));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendPlayerListHeaderAndFooter(@NotNull Component header, @NotNull Component footer) {
/* 368 */     ((ServerPlayerBridge)this.player).bridge$updateTabList(this.controller
/* 369 */         .toNative(Objects.<Component>requireNonNull(header, "header")), this.controller
/* 370 */         .toNative(Objects.<Component>requireNonNull(footer, "footer")));
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendResourcePacks(@NotNull ResourcePackRequest request) {
/* 375 */     List<class_2596<class_8705>> packets = new ArrayList<>(request.packs().size());
/* 376 */     if (request.replace()) {
/* 377 */       packets.add(new class_9053(Optional.empty()));
/*     */     }
/*     */     
/* 380 */     class_2561 prompt = toNativeNullable(request.prompt());
/* 381 */     for (Iterator<ResourcePackInfo> it = request.packs().iterator(); it.hasNext(); ) {
/* 382 */       ResourcePackInfo pack = it.next();
/* 383 */       packets.add(new class_2720(pack
/* 384 */             .id(), pack
/* 385 */             .uri().toASCIIString(), pack
/* 386 */             .hash(), request
/* 387 */             .required(), 
/* 388 */             it.hasNext() ? Optional.empty() : Optional.<class_2561>of(prompt)));
/*     */ 
/*     */       
/* 391 */       if (request.callback() != ResourcePackCallback.noOp()) {
/* 392 */         ((ServerCommonPacketListenerImplBridge)this.player.field_13987).adventure$bridge$registerPackCallback(pack.id(), this.controller, request.callback());
/*     */       }
/*     */     } 
/*     */     
/* 396 */     sendBundle(packets);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeResourcePacks(@NotNull UUID id, @NotNull UUID... others) {
/* 401 */     sendBundle(
/* 402 */         MonkeyBars.nonEmptyArrayToList(pack -> new class_9053(Optional.of(pack)), id, (Object[])others));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearResourcePacks() {
/* 408 */     sendPacket((class_2596<? extends class_8705>)new class_9053(Optional.empty()));
/*     */   }
/*     */   
/*     */   private class_2561 toNativeNullable(@Nullable Component comp) {
/* 412 */     return (comp == null) ? null : this.controller.toNative(comp);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Pointers pointers() {
/* 417 */     return ((PointerProviderBridge)this.player).adventure$pointers();
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public FabricAudiencesInternal controller() {
/* 422 */     return this.controller;
/*     */   }
/*     */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\server\ServerPlayerAudience.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */