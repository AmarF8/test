package net.kyori.adventure.platform.fabric.impl.server;

import java.util.Set;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public interface ServerPlayerBridge {
  void bridge$updateTabList(@Nullable class_2561 paramclass_25611, @Nullable class_2561 paramclass_25612);
  
  Set<class_2960> bridge$knownArguments();
  
  void bridge$knownArguments(Set<class_2960> paramSet);
}


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\server\ServerPlayerBridge.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */