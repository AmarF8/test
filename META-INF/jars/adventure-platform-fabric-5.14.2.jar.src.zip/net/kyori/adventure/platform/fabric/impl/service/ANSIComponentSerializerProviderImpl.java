/*    */ package net.kyori.adventure.platform.fabric.impl.service;
/*    */ 
/*    */ import com.google.auto.service.AutoService;
/*    */ import java.util.function.Consumer;
/*    */ import net.kyori.adventure.platform.fabric.impl.AdventureCommon;
/*    */ import net.kyori.adventure.text.serializer.ansi.ANSIComponentSerializer;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoService({ANSIComponentSerializer.Provider.class})
/*    */ public final class ANSIComponentSerializerProviderImpl
/*    */   implements ANSIComponentSerializer.Provider
/*    */ {
/*    */   @NotNull
/*    */   public ANSIComponentSerializer ansi() {
/* 36 */     return ANSIComponentSerializer.builder().flattener(AdventureCommon.FLATTENER).build();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Consumer<ANSIComponentSerializer.Builder> builder() {
/* 41 */     return builder -> builder.flattener(AdventureCommon.FLATTENER);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\service\ANSIComponentSerializerProviderImpl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */