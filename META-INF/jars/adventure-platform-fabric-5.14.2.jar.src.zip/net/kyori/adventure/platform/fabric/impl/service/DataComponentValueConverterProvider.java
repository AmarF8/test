/*    */ package net.kyori.adventure.platform.fabric.impl.service;
/*    */ 
/*    */ import com.google.auto.service.AutoService;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import com.mojang.serialization.DynamicOps;
/*    */ import com.mojang.serialization.JsonOps;
/*    */ import java.util.List;
/*    */ import java.util.function.Function;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import net.kyori.adventure.platform.fabric.FabricAudiences;
/*    */ import net.kyori.adventure.platform.fabric.impl.AdventureCommon;
/*    */ import net.kyori.adventure.platform.fabric.impl.nbt.FabricDataComponentValue;
/*    */ import net.kyori.adventure.text.event.DataComponentValue;
/*    */ import net.kyori.adventure.text.event.DataComponentValueConverterRegistry;
/*    */ import net.kyori.adventure.text.serializer.gson.GsonDataComponentValue;
/*    */ import net.minecraft.class_2509;
/*    */ import net.minecraft.class_2520;
/*    */ import net.minecraft.class_7923;
/*    */ import net.minecraft.class_9331;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoService({DataComponentValueConverterRegistry.Provider.class})
/*    */ public final class DataComponentValueConverterProvider
/*    */   implements DataComponentValueConverterRegistry.Provider
/*    */ {
/* 46 */   private static final Key ID = (Key)AdventureCommon.res("platform/fabric");
/*    */   
/*    */   @NotNull
/*    */   public Key id() {
/* 50 */     return ID;
/*    */   }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public Iterable<DataComponentValueConverterRegistry.Conversion<?, ?>> conversions() {
/* 56 */     return List.of(
/* 57 */         DataComponentValueConverterRegistry.Conversion.convert(FabricDataComponentValue.Present.class, GsonDataComponentValue.class, (k, codec) -> GsonDataComponentValue.gsonDataComponentValue((JsonElement)codec.codec().encodeStart((DynamicOps)JsonOps.INSTANCE, codec.value()).getOrThrow())), 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 62 */         DataComponentValueConverterRegistry.Conversion.convert(GsonDataComponentValue.class, FabricDataComponentValue.class, (k, gson) -> {
/*    */             class_9331<?> type = resolveComponentType(k);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */             
/*    */             return (FabricDataComponentValue)new FabricDataComponentValue.Present(type.method_57876().parse((DynamicOps)JsonOps.INSTANCE, gson.element()).getOrThrow(RuntimeException::new), type.method_57876());
/* 70 */           }), DataComponentValueConverterRegistry.Conversion.convert(DataComponentValue.TagSerializable.class, FabricDataComponentValue.class, (k, tagSerializable) -> {
/*    */             class_2520 decodedSnbt;
/*    */ 
/*    */             
/*    */             class_9331<?> type = resolveComponentType(k);
/*    */             
/*    */             try {
/*    */               decodedSnbt = (class_2520)tagSerializable.asBinaryTag().get(FabricDataComponentValue.SNBT_CODEC);
/* 78 */             } catch (CommandSyntaxException ex) {
/*    */               throw new IllegalArgumentException("Unable to parse SNBT value", ex);
/*    */             } 
/*    */ 
/*    */ 
/*    */             
/*    */             return (FabricDataComponentValue)new FabricDataComponentValue.Present(type.method_57876().parse((DynamicOps)class_2509.field_11560, decodedSnbt).getOrThrow(RuntimeException::new), type.method_57876());
/* 85 */           }), DataComponentValueConverterRegistry.Conversion.convert(DataComponentValue.Removed.class, FabricDataComponentValue.class, (k, $) -> FabricDataComponentValue.Removed.INSTANCE));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static class_9331<?> resolveComponentType(Key key) {
/* 94 */     class_9331<?> type = (class_9331)class_7923.field_49658.method_10223(FabricAudiences.toNative(key));
/* 95 */     if (type == null) {
/* 96 */       throw new IllegalArgumentException("Unknown data component type " + key.asString());
/*    */     }
/*    */     
/* 99 */     return type;
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\service\DataComponentValueConverterProvider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */