/*    */ package net.kyori.adventure.platform.fabric.impl.service;
/*    */ 
/*    */ import com.google.auto.service.AutoService;
/*    */ import net.kyori.adventure.audience.Audience;
/*    */ import net.kyori.adventure.platform.fabric.impl.ClickCallbackRegistry;
/*    */ import net.kyori.adventure.text.event.ClickCallback;
/*    */ import net.kyori.adventure.text.event.ClickEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoService({ClickCallback.Provider.class})
/*    */ public final class FabricClickCallbackProviderImpl
/*    */   implements ClickCallback.Provider
/*    */ {
/*    */   @NotNull
/*    */   public ClickEvent create(@NotNull ClickCallback<Audience> callback, ClickCallback.Options options) {
/* 37 */     return ClickEvent.runCommand(ClickCallbackRegistry.INSTANCE.register(callback, options));
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\service\FabricClickCallbackProviderImpl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */