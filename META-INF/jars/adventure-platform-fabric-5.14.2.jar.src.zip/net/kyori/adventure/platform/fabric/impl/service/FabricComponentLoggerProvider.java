/*    */ package net.kyori.adventure.platform.fabric.impl.service;
/*    */ 
/*    */ import com.google.auto.service.AutoService;
/*    */ import java.util.Locale;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.kyori.adventure.text.logger.slf4j.ComponentLogger;
/*    */ import net.kyori.adventure.text.logger.slf4j.ComponentLoggerProvider;
/*    */ import net.kyori.adventure.text.serializer.ansi.ANSIComponentSerializer;
/*    */ import net.kyori.adventure.translation.GlobalTranslator;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoService({ComponentLoggerProvider.class})
/*    */ public final class FabricComponentLoggerProvider
/*    */   implements ComponentLoggerProvider
/*    */ {
/*    */   @NotNull
/*    */   public ComponentLogger logger(@NotNull ComponentLoggerProvider.LoggerHelper helper, @NotNull String name) {
/* 40 */     return helper.delegating(LoggerFactory.getLogger(name), this::serialize);
/*    */   }
/*    */   
/*    */   private String serialize(Component message) {
/* 44 */     Component rendered = GlobalTranslator.render(message, Locale.getDefault());
/* 45 */     return (String)ANSIComponentSerializer.ansi().serialize(rendered);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\service\FabricComponentLoggerProvider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */