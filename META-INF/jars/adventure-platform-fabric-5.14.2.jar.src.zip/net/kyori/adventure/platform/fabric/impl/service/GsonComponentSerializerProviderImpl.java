/*    */ package net.kyori.adventure.platform.fabric.impl.service;
/*    */ 
/*    */ import com.google.auto.service.AutoService;
/*    */ import java.util.function.Consumer;
/*    */ import net.kyori.adventure.platform.fabric.impl.nbt.NBTLegacyHoverEventSerializer;
/*    */ import net.kyori.adventure.text.serializer.gson.GsonComponentSerializer;
/*    */ import net.kyori.adventure.text.serializer.json.JSONOptions;
/*    */ import net.kyori.adventure.text.serializer.json.LegacyHoverEventSerializer;
/*    */ import net.kyori.option.OptionState;
/*    */ import net.minecraft.class_155;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoService({GsonComponentSerializer.Provider.class})
/*    */ public final class GsonComponentSerializerProviderImpl
/*    */   implements GsonComponentSerializer.Provider
/*    */ {
/*    */   @NotNull
/*    */   public GsonComponentSerializer gson() {
/* 38 */     return GsonComponentSerializer.builder()
/* 39 */       .legacyHoverEventSerializer((LegacyHoverEventSerializer)NBTLegacyHoverEventSerializer.INSTANCE)
/* 40 */       .build();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public GsonComponentSerializer gsonLegacy() {
/* 45 */     return GsonComponentSerializer.builder()
/* 46 */       .legacyHoverEventSerializer((LegacyHoverEventSerializer)NBTLegacyHoverEventSerializer.INSTANCE)
/* 47 */       .editOptions(b -> b.value(JSONOptions.EMIT_RGB, Boolean.valueOf(false)).value(JSONOptions.EMIT_HOVER_EVENT_TYPE, JSONOptions.HoverEventValueMode.BOTH))
/*    */ 
/*    */ 
/*    */       
/* 51 */       .build();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Consumer<GsonComponentSerializer.Builder> builder() {
/* 56 */     return builder -> builder.legacyHoverEventSerializer((LegacyHoverEventSerializer)NBTLegacyHoverEventSerializer.INSTANCE).options((OptionState)JSONOptions.byDataVersion().at(class_155.method_16673().method_37912().method_38494()));
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-common-fabric-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\service\GsonComponentSerializerProviderImpl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */