/*    */ package net.kyori.adventure.platform.fabric.impl.service;
/*    */ 
/*    */ import com.google.auto.service.AutoService;
/*    */ import java.util.function.Consumer;
/*    */ import net.kyori.adventure.platform.fabric.impl.AdventureCommon;
/*    */ import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoService({PlainTextComponentSerializer.Provider.class})
/*    */ public final class PlainTextComponentSerializerProviderImpl
/*    */   implements PlainTextComponentSerializer.Provider
/*    */ {
/*    */   @NotNull
/*    */   public PlainTextComponentSerializer plainTextSimple() {
/* 36 */     return (PlainTextComponentSerializer)PlainTextComponentSerializer.builder().flattener(AdventureCommon.FLATTENER).build();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Consumer<PlainTextComponentSerializer.Builder> plainText() {
/* 41 */     return builder -> builder.flattener(AdventureCommon.FLATTENER);
/*    */   }
/*    */ }


/* Location:              C:\Users\amarf\AppData\Roaming\ModrinthApp\profiles\Cobblemon.gg - Ultimate Pokemon Experience\mods\atlas-client-1.2.0.jar!\META-INF\jars\adventure-platform-fabric-5.14.2.jar!\net\kyori\adventure\platform\fabric\impl\service\PlainTextComponentSerializerProviderImpl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */